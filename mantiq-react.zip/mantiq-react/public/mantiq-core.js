// ─── CONSTANTS ────────────────────────────────────────────────────────────────
const MODULES = { LANDING:'landing', CRM:'crm', SALES:'sales', HR:'hr', FINANCE:'finance', ACADEMY:'academy' };

const UI = {
    en: {
        subtitle:"For Business Services Demos",
        description:"All Systems can be customized based on your Budget, Needs, Operation of your Department, Users and your data size.",
        launch:"Demo",dashboard:"Dashboard",controlCenter:"Control Center",
        active:"Active",growth:"Growth",volume:"Volume",assets:"Assets",status:"Status",
        verified:"Verified",demoEnv:"Demo Environment",search:"Global search...",
        export:"Export",addRecord:"Add Record",cancel:"Cancel",confirm:"Confirm",
        syncing:"Syncing",returnHome:"Return Home",restricted:"Security: Restricted action.",
        blocked:"Security Protocol: Developer Access Blocked.",role:"Super Admin",
        action:"Action",submit:"Submit Data",analytics:"Analytics",overview:"Overview",trends:"Trends"
    },
    ar: {
        subtitle:"لخدمات الأعمال",
        description:"انظمة لادارة اقسام شركتك بدقة وكفاءة عالية.",
        launch:"لرؤية عينة",dashboard:"لوحة القيادة",controlCenter:"مركز التحكم",
        active:"نشط",growth:"النمو",volume:"الحجم",assets:"الأصول",status:"الحالة",
        verified:"تم التحقق",demoEnv:"بيئة العرض",search:"بحث شامل...",
        export:"سحب البيانات",addRecord:"إضافة سجل",cancel:"إلغاء",confirm:"تأكيد",
        syncing:"جاري المزامنة",returnHome:"العودة للرئيسية",restricted:"أمن: إجراء مقيد.",
        blocked:"بروتوكول أمن: تم حظر وصول المطورين.",role:"مدير نظام",
        action:"الإجراء",submit:"إرسال البيانات",analytics:"التحليلات",overview:"نظرة عامة",trends:"الاتجاهات"
    }
};

// ─── SYSTEM MAP ───────────────────────────────────────────────────────────────
const SYSTEM_MAP = {
    [MODULES.CRM]: {
        title:{ en:"CRM Tracker", ar:"متتبع العملاء" },
        description:{ en:"Optimize customer relationships, track leads from prospect to deal, and visualize your sales pipeline with precision.", ar:"حسّن علاقات العملاء، وتتبع العملاء المحتملين من البداية حتى إغلاق الصفقة." },
        icon: 'users',
        color: '#38bdf8',
        kpis: {
            en: [
                { label:'Total Leads', value:'1,240', delta:'+12%', icon:'user-plus', color:'blue' },
                { label:'Active Deals', value:'84', delta:'+5%', icon:'briefcase', color:'green' },
                { label:'Win Rate', value:'62%', delta:'+3%', icon:'trophy', color:'amber' },
                { label:'Pipeline Value', value:'4.2M EGP', delta:'+18%', icon:'trending-up', color:'green' }
            ],
            ar: [
                { label:'إجمالي العملاء المحتملين', value:'1,240', delta:'+12%', icon:'user-plus', color:'blue' },
                { label:'الصفقات النشطة', value:'84', delta:'+5%', icon:'briefcase', color:'green' },
                { label:'معدل الفوز', value:'62%', delta:'+3%', icon:'trophy', color:'amber' },
                { label:'قيمة المسار', value:'4.2M ج.م', delta:'+18%', icon:'trending-up', color:'green' }
            ]
        },
        charts: {
            pipeline: { labels:['Discovery','Proposal','Negotiation','Closed Won','Closed Lost'], data:[28,19,14,18,5] },
            monthly: { labels:['Oct','Nov','Dec','Jan','Feb','Mar'], data:[320,410,390,480,520,610] },
            sources: { labels:['Website','Referral','Cold Call','Social','Event'], data:[35,25,15,18,7] }
        },
        nav:[
            { id:'dashboard', label:{en:'Dashboard',ar:'لوحة القيادة'}, icon:'layout-dashboard' },
            { id:'analytics', label:{en:'Analytics',ar:'التحليلات'}, icon:'bar-chart-3', isAnalytics:true },
            { id:'leads', label:{en:'Leads',ar:'العملاء المحتملون'}, icon:'user-plus',
              tour:{en:'Track every lead from first contact to closed deal. Use the Kanban board to drag leads across stages.',ar:'تتبع كل عميل من أول تواصل حتى إغلاق الصفقة. استخدم لوحة كانبان للتنقل بين المراحل.'},
              tableCols:{ en:['Lead ID','Name','Company','Phone','Source','Stage','Score','Status'], ar:['المعرف','الاسم','الشركة','الهاتف','المصدر','المرحلة','النقاط','الحالة'] } },
            { id:'customers', label:{en:'Customers',ar:'العملاء'}, icon:'users',
              tour:{en:'Your converted accounts. View lifetime value, segment, and relationship history per customer.',ar:'عملاؤك المحوّلون. اعرض القيمة العمرية والشريحة وتاريخ العلاقة لكل عميل.'},
              tableCols:{ en:['Customer ID','Company','Industry','Email','Segment','LTV','Status'], ar:['المعرف','الشركة','الصناعة','البريد','الشريحة','القيمة','الحالة'] } },
            { id:'contacts', label:{en:'Contacts',ar:'جهات الاتصال'}, icon:'phone',
              tour:{en:'All people linked to your accounts. Call, email or schedule meetings directly from here.',ar:'جميع الأشخاص المرتبطين بحساباتك. اتصل أو أرسل بريدًا أو جدول اجتماعات مباشرة.'},
              tableCols:{ en:['Contact ID','Name','Job Title','Company','Mobile','Last Contact'], ar:['المعرف','الاسم','المنصب','الشركة','الهاتف','آخر تواصل'] } },
            { id:'deals', label:{en:'Deals',ar:'الصفقات'}, icon:'briefcase',
              tour:{en:'Monitor open deals, their value, probability, and expected close dates. Update stage as negotiations progress.',ar:'راقب الصفقات المفتوحة وقيمتها واحتمالية الإغلاق. حدّث المرحلة مع تقدم المفاوضات.'},
              tableCols:{ en:['Deal ID','Deal Name','Account','Value','Stage','Probability','Close Date'], ar:['المعرف','العنوان','الحساب','القيمة','المرحلة','الاحتمالية','الإغلاق'] } },
            { id:'activities', label:{en:'Activities',ar:'الأنشطة'}, icon:'clipboard-list',
              tour:{en:'Log every call, meeting, email and task. Set priorities and due dates so nothing slips through.',ar:'سجّل كل مكالمة واجتماع وبريد ومهمة. حدد الأولويات والمواعيد حتى لا يفوتك شيء.'},
              tableCols:{ en:['Activity ID','Type','Subject','Assigned To','Due Date','Priority','Status'], ar:['المعرف','النوع','الموضوع','المسؤول','الموعد','الأولوية','الحالة'] } },
            { id:'communication', label:{en:'Communication Log',ar:'سجل التواصل'}, icon:'mail',
              tour:{en:'Full email and call history per account. Use filters to find any interaction instantly.',ar:'سجل كامل للبريد والمكالمات لكل حساب. استخدم الفلاتر للعثور على أي تفاعل فورًا.'},
              tableCols:{ en:['Log ID','Type','From/To','Subject','Duration','Date'], ar:['المعرف','النوع','من/إلى','الموضوع','المدة','التاريخ'] } },
            { id:'reports', label:{en:'Reports',ar:'التقارير'}, icon:'file-text',
              tour:{en:'Generate win/loss, pipeline, and activity reports. Export to PDF or Excel for management reviews.',ar:'أنشئ تقارير الفوز والخسارة والمسار والأنشطة. صدّرها PDF أو Excel للاستعراضات الإدارية.'},
              tableCols:{ en:['Report Type','Period','Value','Growth %','Generated By'], ar:['نوع التقرير','الفترة','القيمة','النمو','المنشئ'] } },
            { id:'settings', label:{en:'User Roles',ar:'أدوار المستخدمين'}, icon:'settings',
              tour:{en:'Define who can see and edit what. Assign roles from Admin to Read-Only per module.',ar:'حدد من يمكنه رؤية وتعديل ماذا. عيّن أدوارًا من المدير إلى القراءة فقط لكل وحدة.'},
              tableCols:{ en:['User Name','Email','Role','Module Access','Status'], ar:['الاسم','البريد','الدور','صلاحية الوحدات','الحالة'] } }
        ]
    },

    [MODULES.HR]: {
        title:{ en:"HR System", ar:"نظام الموارد البشرية" },
        description:{ en:"Complete HR solution for employee management, payroll, attendance, and performance reviews.", ar:"حل شامل للموارد البشرية لإدارة الموظفين والرواتب والحضور." },
        icon: 'users-round',
        color: '#a78bfa',
        kpis: {
            en: [
                { label:'Total Employees', value:'248', delta:'+4', icon:'users', color:'blue' },
                { label:'On Leave Today', value:'12', delta:'-2', icon:'calendar', color:'amber' },
                { label:'Payroll (Month)', value:'1.8M EGP', delta:'+2%', icon:'wallet', color:'green' },
                { label:'Avg Performance', value:'4.1/5', delta:'+0.2', icon:'trending-up', color:'green' }
            ],
            ar: [
                { label:'إجمالي الموظفين', value:'248', delta:'+4', icon:'users', color:'blue' },
                { label:'في إجازة اليوم', value:'12', delta:'-2', icon:'calendar', color:'amber' },
                { label:'الرواتب (شهري)', value:'1.8M ج.م', delta:'+2%', icon:'wallet', color:'green' },
                { label:'متوسط الأداء', value:'4.1/5', delta:'+0.2', icon:'trending-up', color:'green' }
            ]
        },
        charts: {
            headcount: { labels:['Oct','Nov','Dec','Jan','Feb','Mar'], data:[230,235,238,242,245,248] },
            departments: { labels:['Engineering','Sales','Finance','HR','Operations','Marketing'], data:[42,55,28,18,65,40] },
            attendance: { labels:['Mon','Tue','Wed','Thu','Sun'], data:[96,94,97,91,89] }
        },
        nav:[
            { id:'dashboard', label:{en:'Dashboard',ar:'لوحة القيادة'}, icon:'layout-dashboard' },
            { id:'analytics', label:{en:'Analytics',ar:'التحليلات'}, icon:'bar-chart-3', isAnalytics:true },
            { id:'directory', label:{en:'Employees',ar:'دليل الموظفين'}, icon:'users',
              tour:{en:'Your full employee directory. Click any row to view complete profile, documents and history.',ar:'دليل موظفيك الكامل. انقر على أي صف لعرض الملف الشخصي الكامل والمستندات والتاريخ.'},
              tableCols:{ en:['E-ID','Full Name','Job Title','Dept','Hire Date','Contract','Status'], ar:['المعرف','الاسم','المنصب','القسم','تاريخ التعيين','العقد','الحالة'] } },
            { id:'attendance', label:{en:'Attendance',ar:'الحضور والانصراف'}, icon:'clock',
              tour:{en:'Daily punch-in/out records. Late arrivals and overtime are auto-flagged. Filter by department or date range.',ar:'سجلات الحضور والانصراف اليومية. يتم تمييز التأخر والعمل الإضافي تلقائيًا.'},
              tableCols:{ en:['Date','Employee','Dept','In','Out','Hours','Overtime','Status'], ar:['التاريخ','الموظف','القسم','دخول','خروج','ساعات','إضافي','الحالة'] } },
            { id:'leaves', label:{en:'Leaves',ar:'الإجازات'}, icon:'calendar',
              tour:{en:'Submit and approve leave requests. Balance is auto-deducted. Annual, sick, and emergency types supported.',ar:'تقديم واعتماد طلبات الإجازة. يتم خصم الرصيد تلقائيًا. يدعم الإجازات السنوية والمرضية والطارئة.'},
              tableCols:{ en:['Leave ID','Employee','Type','Balance','Start','End','Days','Status'], ar:['المعرف','الموظف','النوع','الرصيد','البداية','النهاية','الأيام','الحالة'] } },
            { id:'payroll', label:{en:'Payroll',ar:'الرواتب'}, icon:'wallet',
              tour:{en:'Monthly payroll with auto-calculated allowances, deductions, and income tax. One-click payslip generation.',ar:'الرواتب الشهرية مع حساب تلقائي للبدلات والخصومات وضريبة الدخل. إنشاء قسيمة راتب بنقرة واحدة.'},
              tableCols:{ en:['Month','Employee','Base Salary','Allowances','Deductions','Tax','Net','Status'], ar:['الشهر','الموظف','الأساسي','البدلات','الخصومات','الضريبة','الصافي','الحالة'] } },
            { id:'contracts', label:{en:'Contracts',ar:'العقود'}, icon:'file-text',
              tour:{en:'Track contract types and expiry dates. Get alerts 30 days before renewal is due.',ar:'تتبع أنواع العقود وتواريخ انتهائها. تلقّ تنبيهات قبل 30 يومًا من موعد التجديد.'},
              tableCols:{ en:['Contract ID','Employee','Type','Start','End','Notice Period','Status'], ar:['المعرف','الموظف','النوع','البداية','النهاية','فترة الإشعار','الحالة'] } },
            { id:'recruitment', label:{en:'Recruitment',ar:'التوظيف'}, icon:'user-plus',
              tour:{en:'Post jobs, track applicants through interview stages, and convert directly to employee records on hire.',ar:'انشر وظائف وتتبع المتقدمين عبر مراحل المقابلات وحوّلهم مباشرة إلى سجلات موظفين عند التعيين.'},
              tableCols:{ en:['Job Title','Department','Applicants','Shortlisted','Interviews','Stage','Status'], ar:['المنصب','القسم','المتقدمين','المختارين','المقابلات','المرحلة','الحالة'] } },
            { id:'performance', label:{en:'Performance',ar:'تقييم الأداء'}, icon:'trending-up',
              tour:{en:'Quarterly and annual KPI reviews. Scores feed directly into promotion and salary adjustment workflows.',ar:'مراجعات مؤشرات الأداء الفصلية والسنوية. تُغذّي النتائج سير عمل الترقية وتعديل الراتب مباشرة.'},
              tableCols:{ en:['Employee','Dept','Reviewer','KPI Score','Behaviour','Overall (1-5)','Period'], ar:['الموظف','القسم','المقيم','مؤشرات الأداء','السلوك','الإجمالي','الفترة'] } },
            { id:'training', label:{en:'Training',ar:'التدريب'}, icon:'graduation-cap',
              tour:{en:'Assign courses, track completion rates, and log certifications. Link training to performance gaps.',ar:'عيّن دورات وتتبع معدلات الإتمام وسجّل الشهادات. اربط التدريب بفجوات الأداء.'},
              tableCols:{ en:['Training Name','Provider','Type','Enrollees','Duration','Completion %','Cost'], ar:['الدورة','المزود','النوع','المسجلين','المدة','الإتمام','التكلفة'] } },
            { id:'reports', label:{en:'HR Reports',ar:'تقارير الموارد'}, icon:'bar-chart-3',
              tour:{en:'Turnover, headcount, payroll cost, and attendance summary reports. Export for board presentations.',ar:'تقارير معدل الدوران والقوى العاملة وتكلفة الرواتب والحضور. صدّرها لعروض مجلس الإدارة.'},
              tableCols:{ en:['Metric','Current Value','Target','Variance','Status'], ar:['المؤشر','القيمة','المستهدف','الفرق','الحالة'] } },
            { id:'settings', label:{en:'HR Settings',ar:'إعدادات الموارد'}, icon:'settings',
              tour:{en:'Configure leave policies, working hours, overtime rules, and approval hierarchies for your organization.',ar:'اضبط سياسات الإجازات وساعات العمل وقواعد العمل الإضافي وتسلسل الموافقات لمؤسستك.'},
              tableCols:{ en:['Rule Name','Category','Value','Applies To','Last Updated'], ar:['القاعدة','الفئة','القيمة','تطبق على','آخر تحديث'] } }
        ]
    },

    [MODULES.FINANCE]: {
        title:{ en:"Finance Tracker", ar:"المالية" },
        description:{ en:"Advanced financial management for income, expenses, invoices, and cash flow with full EGP tax compliance.", ar:"إدارة مالية متقدمة لتتبع الإيرادات والمصاريف والفواتير مع الامتثال الضريبي الكامل." },
        icon: 'trending-up',
        color: '#34d399',
        kpis: {
            en: [
                { label:'Total Revenue (MTD)', value:'3.6M EGP', delta:'+22%', icon:'arrow-up-right', color:'green' },
                { label:'Total Expenses (MTD)', value:'1.9M EGP', delta:'+8%', icon:'arrow-down-right', color:'red' },
                { label:'Net Profit', value:'1.7M EGP', delta:'+38%', icon:'bar-chart-2', color:'green' },
                { label:'Outstanding Invoices', value:'420K EGP', delta:'-5%', icon:'file-signature', color:'amber' }
            ],
            ar: [
                { label:'الإيرادات (الشهر)', value:'3.6M ج.م', delta:'+22%', icon:'arrow-up-right', color:'green' },
                { label:'المصاريف (الشهر)', value:'1.9M ج.م', delta:'+8%', icon:'arrow-down-right', color:'red' },
                { label:'صافي الربح', value:'1.7M ج.م', delta:'+38%', icon:'bar-chart-2', color:'green' },
                { label:'فواتير معلقة', value:'420K ج.م', delta:'-5%', icon:'file-signature', color:'amber' }
            ]
        },
        charts: {
            cashflow: { labels:['Oct','Nov','Dec','Jan','Feb','Mar'], inflow:[2800,3100,2950,3400,3600,3800], outflow:[1700,1850,1780,1900,1850,1950] },
            expenses: { labels:['Salaries','Rent','Marketing','Utilities','Logistics','Other'], data:[45,15,12,8,10,10] },
            revenue: { labels:['Oct','Nov','Dec','Jan','Feb','Mar'], data:[2800,3100,2950,3400,3600,3800] }
        },
        nav:[
            { id:'dashboard', label:{en:'Dashboard',ar:'لوحة القيادة'}, icon:'layout-dashboard' },
            { id:'analytics', label:{en:'Analytics',ar:'التحليلات'}, icon:'bar-chart-3', isAnalytics:true },
            { id:'income', label:{en:'Income',ar:'الإيرادات'}, icon:'arrow-up-right',
              tour:{en:'Record every revenue entry with category, client, VAT, and net amount. Linked to invoices automatically.',ar:'سجّل كل إيراد بالفئة والعميل وضريبة القيمة المضافة والصافي. مرتبط بالفواتير تلقائيًا.'},
              tableCols:{ en:['Income ID','Category','Source','Client','Amount','Tax','Net','Date','Status'], ar:['المعرف','الفئة','المصدر','العميل','المبلغ','الضريبة','الصافي','التاريخ','الحالة'] } },
            { id:'expenses', label:{en:'Expenses',ar:'المصاريف'}, icon:'arrow-down-right',
              tour:{en:'Log and approve all outgoing payments. Attach receipts, categorize by cost center, and track VAT.',ar:'سجّل واعتمد جميع المدفوعات الصادرة. أرفق الإيصالات وصنّف حسب مركز التكلفة وتتبع الضريبة.'},
              tableCols:{ en:['Expense ID','Vendor','Category','Amount','VAT','Method','Approved By','Status'], ar:['المعرف','المورد','الفئة','المبلغ','ضريبة','الطريقة','المعتمد','الحالة'] } },
            { id:'invoices', label:{en:'Invoices',ar:'الفواتير'}, icon:'file-signature',
              tour:{en:'Create and send tax-compliant invoices. VAT 14% auto-calculated. Track paid vs outstanding per client.',ar:'أنشئ وأرسل فواتير متوافقة ضريبيًا. ضريبة 14% تُحسب تلقائيًا. تتبع المدفوع والمعلق لكل عميل.'},
              tableCols:{ en:['Inv #','Client','Issue Date','Due Date','Subtotal','VAT 14%','Total','Paid','Status'], ar:['رقم الفاتورة','العميل','الإصدار','الموعد','الأساسي','ضريبة 14%','الإجمالي','المدفوع','الحالة'] } },
            { id:'bills', label:{en:'Bills Payable',ar:'الفواتير المستحقة'}, icon:'receipt',
              tour:{en:'Track what you owe vendors. Get alerts on upcoming due dates to avoid late payment penalties.',ar:'تتبع ما تدين به للموردين. تلقّ تنبيهات قبل مواعيد الاستحقاق لتجنب غرامات التأخير.'},
              tableCols:{ en:['Bill #','Vendor','Category','Issue Date','Due Date','Amount','Status'], ar:['رقم الفاتورة','المورد','الفئة','الإصدار','الموعد','المبلغ','الحالة'] } },
            { id:'payments', label:{en:'Payments',ar:'المدفوعات'}, icon:'credit-card',
              tour:{en:'Full payment log — bank transfers, cash, checks and digital wallets. Auto-reconciles with invoices and bills.',ar:'سجل مدفوعات كامل — تحويلات بنكية ونقد وشيكات ومحافظ رقمية. تسوية تلقائية مع الفواتير.'},
              tableCols:{ en:['Payment ID','Type','Payer/Payee','Amount','Method','Reference','Date'], ar:['المعرف','النوع','المرسل/المستلم','المبلغ','الطريقة','المرجع','التاريخ'] } },
            { id:'wallets', label:{en:'Accounts & Wallets',ar:'الحسابات والمحافظ'}, icon:'wallet',
              tour:{en:'View real-time balances across all your bank accounts and digital wallets. Supports multi-currency.',ar:'اعرض الأرصدة الفورية لجميع حساباتك البنكية ومحافظك الرقمية. يدعم العملات المتعددة.'},
              tableCols:{ en:['Account Name','Bank','Type','Currency','Balance','Last Txn'], ar:['اسم الحساب','البنك','النوع','العملة','الرصيد','آخر معاملة'] } },
            { id:'budgeting', label:{en:'Budgeting',ar:'الميزانية'}, icon:'pie-chart',
              tour:{en:'Set annual budgets per category and track actual spend in real-time. Alerts fire when 80% is consumed.',ar:'ضع ميزانيات سنوية لكل فئة وتتبع الإنفاق الفعلي فورًا. تنبيهات عند استهلاك 80%.'},
              tableCols:{ en:['Category','Annual Budget','Q1 Budget','Actual Spent','Variance','Usage %'], ar:['الفئة','الميزانية السنوية','ميزانية ر.1','المنفق','الفرق','الاستخدام'] } },
            { id:'taxes', label:{en:'Tax Filing',ar:'الضرائب'}, icon:'shield-check',
              tour:{en:'Track VAT, income tax, and withholding. Filing deadlines are highlighted. Export e-filing data directly.',ar:'تتبع ضريبة القيمة المضافة وضريبة الدخل والخصم عند المنبع. مواعيد التقديم مُبرزة. صدّر بيانات التقديم الإلكتروني مباشرة.'},
              tableCols:{ en:['Period','Tax Type','Base Amount','Rate','Tax Amount','Filed Date','Status'], ar:['الفترة','النوع','الأساس','النسبة','المبلغ','تاريخ التقديم','الحالة'] } },
            { id:'profitloss', label:{en:'P&L Statement',ar:'الأرباح والخسائر'}, icon:'bar-chart-2',
              tour:{en:'Live profit & loss with period-over-period comparison. Drill down into any line item for transaction details.',ar:'بيان أرباح وخسائر حي مع مقارنة فترة بفترة. انقر على أي بند للتفاصيل.'},
              tableCols:{ en:['Label','This Period','Last Period','Variance','Variance %'], ar:['البند','الفترة الحالية','الفترة الماضية','الفرق','النسبة'] } },
            { id:'settings', label:{en:'Finance Settings',ar:'الإعدادات'}, icon:'settings',
              tour:{en:'Set base currency, fiscal year, tax rates, payment terms, and approval thresholds for your finance team.',ar:'اضبط العملة الأساسية والسنة المالية ومعدلات الضريبة وشروط الدفع وحدود الموافقة.'},
              tableCols:{ en:['Option','Category','Value','Currency','Last Updated'], ar:['الخيار','الفئة','القيمة','العملة','آخر تحديث'] } }
        ]
    },

    [MODULES.SALES]: {
        title:{ en:"Sales Tracker", ar:"المبيعات" },
        description:{ en:"Boost your sales performance with opportunity management, quotations, orders, and sales targets.", ar:"عزز أداء مبيعاتك باستخدام أدوات قوية لإدارة الفرص وعروض الأسعار والأهداف." },
        icon: 'shopping-cart',
        color: '#fb923c',
        kpis: {
            en: [
                { label:'Revenue (MTD)', value:'2.1M EGP', delta:'+16%', icon:'trending-up', color:'green' },
                { label:'Orders Closed', value:'138', delta:'+9%', icon:'package', color:'blue' },
                { label:'Quota Attainment', value:'78%', delta:'+4%', icon:'target', color:'amber' },
                { label:'Avg Deal Size', value:'52K EGP', delta:'+7%', icon:'dollar-sign', color:'green' }
            ],
            ar: [
                { label:'الإيراد (الشهر)', value:'2.1M ج.م', delta:'+16%', icon:'trending-up', color:'green' },
                { label:'الطلبات المغلقة', value:'138', delta:'+9%', icon:'package', color:'blue' },
                { label:'تحقيق الحصة', value:'78%', delta:'+4%', icon:'target', color:'amber' },
                { label:'متوسط حجم الصفقة', value:'52K ج.م', delta:'+7%', icon:'dollar-sign', color:'green' }
            ]
        },
        charts: {
            revenue: { labels:['Oct','Nov','Dec','Jan','Feb','Mar'], data:[1600,1800,1700,1950,2000,2100] },
            reps: { labels:['Ahmed','Sara','Kareem','Mona','Omar'], data:[420,380,510,290,390] },
            products: { labels:['Software','Hardware','Services','Consulting','Support'], data:[38,22,20,12,8] }
        },
        nav:[
            { id:'dashboard', label:{en:'Dashboard',ar:'لوحة القيادة'}, icon:'layout-dashboard' },
            { id:'analytics', label:{en:'Analytics',ar:'التحليلات'}, icon:'bar-chart-3', isAnalytics:true },
            { id:'leads', label:{en:'Leads',ar:'العملاء المهتمون'}, icon:'user-plus',
              tour:{en:'Incoming leads with scores and source tracking. Use the Kanban pipeline to move them toward a deal.',ar:'العملاء الواردون مع نقاط ومصادر. استخدم لوحة كانبان لتحريكهم نحو الصفقة.'},
              tableCols:{ en:['Name','Phone','Source','Assigned To','Score','Stage','Status'], ar:['الاسم','الهاتف','المصدر','المسؤول','النقاط','المرحلة','الحالة'] } },
            { id:'opportunities', label:{en:'Opportunities',ar:'الفرص'}, icon:'briefcase',
              tour:{en:'High-value prospects with win probability. Weighted pipeline gives an accurate forecast of likely revenue.',ar:'عملاء محتملون بقيمة عالية مع احتمالية الفوز. المسار الموزون يعطي توقعات دقيقة للإيراد المحتمل.'},
              tableCols:{ en:['Project','Client','Value','Prob %','Rep','Close Date','Status'], ar:['المشروع','العميل','القيمة','الاحتمالية','المندوب','تاريخ الإغلاق','الحالة'] } },
            { id:'quotations', label:{en:'Quotations',ar:'عروض الأسعار'}, icon:'file-text',
              tour:{en:'Build and send professional quotations with line items, discounts, and validity dates. One-click convert to order.',ar:'أنشئ وأرسل عروض أسعار احترافية بالبنود والخصومات وتواريخ الصلاحية. تحويل للطلب بنقرة واحدة.'},
              tableCols:{ en:['Quote ID','Client','Items','Subtotal','Discount','Grand Total','Valid Until','Status'], ar:['المعرف','العميل','العناصر','الأساسي','الخصم','الإجمالي','صلاحية','الحالة'] } },
            { id:'orders', label:{en:'Orders',ar:'الطلبات'}, icon:'package',
              tour:{en:'Confirmed sales orders with delivery scheduling. Status auto-updates from Processing → Shipped → Delivered.',ar:'طلبات المبيعات المؤكدة مع جدولة التسليم. الحالة تتحدث تلقائيًا من معالجة إلى شحن إلى تسليم.'},
              tableCols:{ en:['Order ID','Customer','Items','Total','Payment','Delivery Date','Status'], ar:['المعرف','العميل','العناصر','الإجمالي','الدفع','موعد التوصيل','الحالة'] } },
            { id:'products', label:{en:'Products & Services',ar:'المنتجات والخدمات'}, icon:'layers',
              tour:{en:'Your full catalog with live stock levels, unit cost, and margin %. Flag items as active or discontinued.',ar:'كتالوجك الكامل مع مستويات المخزون الحية وسعر التكلفة ونسبة الهامش. صنّف العناصر نشطة أو موقوفة.'},
              tableCols:{ en:['Name','SKU','Category','Stock','Unit Price','Cost','Margin %'], ar:['الاسم','SKU','الفئة','المخزون','سعر البيع','التكلفة','الهامش'] } },
            { id:'targets', label:{en:'Sales Targets',ar:'الأهداف'}, icon:'target',
              tour:{en:'Set monthly and quarterly targets per rep. Achievement % updates in real-time as orders close.',ar:'حدد أهدافًا شهرية وفصلية لكل مندوب. نسبة الإنجاز تتحدث فوريًا مع إغلاق الطلبات.'},
              tableCols:{ en:['Sales Rep','Period','Target Revenue','Achieved','Variance','% Achieved','Status'], ar:['المندوب','الفترة','المستهدف','المحقق','الفرق','النسبة','الحالة'] } },
            { id:'commissions', label:{en:'Commissions',ar:'العمولات'}, icon:'dollar-sign',
              tour:{en:'Auto-calculate rep commissions based on closed revenue and rate tiers. Mark as paid once processed.',ar:'احسب عمولات المندوبين تلقائيًا بناءً على الإيراد المغلق وشرائح النسب. سجّلها مدفوعة بعد المعالجة.'},
              tableCols:{ en:['Rep Name','Month','Revenue','Rate %','Gross Comm','Adjustments','Net Comm','Status'], ar:['المندوب','الشهر','الإيراد','النسبة','الإجمالي','التعديلات','الصافي','الحالة'] } },
            { id:'customers', label:{en:'Customers',ar:'العملاء'}, icon:'users',
              tour:{en:'Full customer history — total orders, lifetime value, and region. Use segments to personalize outreach.',ar:'تاريخ العميل الكامل — إجمالي الطلبات والقيمة العمرية والمنطقة. استخدم الشرائح لتخصيص التواصل.'},
              tableCols:{ en:['Company','Contact','Segment','Region','Since','Lifetime Value','Status'], ar:['الشركة','المسؤول','الشريحة','المنطقة','منذ','القيمة الإجمالية','الحالة'] } },
            { id:'reports', label:{en:'Sales Reports',ar:'تقارير المبيعات'}, icon:'bar-chart-3',
              tour:{en:'KPI scorecards with attainment vs target. Share with management as PDF or present live from this screen.',ar:'بطاقات أداء مع الإنجاز مقابل الهدف. شاركها مع الإدارة كـ PDF أو اعرضها مباشرة من هذه الشاشة.'},
              tableCols:{ en:['KPI Indicator','Current Value','Target','Attainment %','Trend'], ar:['المؤشر','القيمة','المستهدف','النسبة','الاتجاه'] } },
            { id:'settings', label:{en:'Sales Settings',ar:'الإعدادات'}, icon:'settings',
              tour:{en:'Configure sales regions, rep territories, commission rules, and approval flows for your sales operation.',ar:'اضبط مناطق المبيعات وأقاليم المندوبين وقواعد العمولة وتدفقات الموافقة لعمليتك البيعية.'},
              tableCols:{ en:['Configuration Key','Value','Category','Last Sync'], ar:['مفتاح الإعداد','القيمة','الفئة','آخر مزامنة'] } }
        ]
    },

    [MODULES.ACADEMY]: {
        title:{ en:"Academy System", ar:"نظام المراكز التعليمية" },
        description:{ en:"Complete management for educational centers — students, teachers, schedules, attendance, income, and expenses in one place.", ar:"إدارة شاملة للمراكز التعليمية — الطلاب والمعلمون والجداول والحضور والإيرادات والمصاريف في مكان واحد." },
        icon: 'graduation-cap',
        color: '#a78bfa',
        kpis: {
            en: [
                { label:'Total Students', value:'312', delta:'+18', icon:'users', color:'blue' },
                { label:'Teachers', value:'24', delta:'+2', icon:'user-cog', color:'green' },
                { label:'Monthly Revenue', value:'186K EGP', delta:'+14%', icon:'trending-up', color:'green' },
                { label:'Attendance Rate', value:'91%', delta:'+3%', icon:'clipboard-check', color:'amber' }
            ],
            ar: [
                { label:'إجمالي الطلاب', value:'312', delta:'+18', icon:'users', color:'blue' },
                { label:'المعلمون', value:'24', delta:'+2', icon:'user-cog', color:'green' },
                { label:'الإيرادات الشهرية', value:'186K ج.م', delta:'+14%', icon:'trending-up', color:'green' },
                { label:'معدل الحضور', value:'91%', delta:'+3%', icon:'clipboard-check', color:'amber' }
            ]
        },
        charts: {
            enrollment: { labels:['Oct','Nov','Dec','Jan','Feb','Mar'], data:[260,275,285,295,305,312] },
            revenue:    { labels:['Oct','Nov','Dec','Jan','Feb','Mar'], data:[142,155,148,168,175,186] },
            grades:     { labels:['Year 1','Year 2','Year 3','Year 4','Year 5','Year 6'], data:[58,62,55,48,50,39] },
            attendance: { labels:['Mon','Tue','Wed','Thu','Sun'], data:[93,91,95,89,88] }
        },
        nav:[
            { id:'dashboard',      label:{en:'Dashboard',ar:'لوحة القيادة'},            icon:'layout-dashboard' },
            { id:'analytics',      label:{en:'Analytics',ar:'التحليلات'},               icon:'bar-chart-3', isAnalytics:true },
            { id:'edu_students',   label:{en:'Students',ar:'الطلاب'},                   icon:'users',
              tour:{en:'Full student roster with grade, age, contact info, and status. Click any row to open the student\'s complete profile and attendance history.',ar:'قائمة الطلاب الكاملة بالمستوى والعمر وبيانات التواصل والحالة. انقر على أي صف لفتح الملف الكامل وسجل الحضور.'},
              tableCols:{ en:['Stu-ID','Student Name','Age','Phone','Grade','Status'], ar:['رقم الطالب','اسم الطالب','العمر','الهاتف','المستوى','الحالة'] } },
            { id:'edu_teachers',   label:{en:'Teachers',ar:'المعلمون'},                 icon:'user-cog',
              tour:{en:'Teacher profiles with their assigned subjects, weekly schedule, and attendance history. Click a card to view their full timeline.',ar:'ملفات المعلمين مع موادهم المسندة والجدول الأسبوعي وسجل الحضور. انقر على بطاقة لعرض جدولهم الكامل.'},
              tableCols:{ en:['Teacher ID','Full Name','Subject','Grade','Phone','Hire Date','Status'], ar:['المعرف','الاسم الكامل','المادة','المستوى','الهاتف','تاريخ التعيين','الحالة'] } },
            { id:'edu_schedule',   label:{en:'Schedule',ar:'الجدول الدراسي'},           icon:'calendar-clock',
              tour:{en:'Weekly class timetable per grade. Each row shows subject, teacher, day, room, and start time. Today\'s lectures appear on the dashboard.',ar:'الجدول الأسبوعي لكل مستوى. كل صف يظهر المادة والمعلم واليوم والقاعة ووقت البدء. محاضرات اليوم تظهر على لوحة القيادة.'},
              tableCols:{ en:['Grade','Subject','Teacher','Day','Room','Start Time','Duration'], ar:['المستوى','المادة','المعلم','اليوم','القاعة','وقت البدء','المدة'] } },
            { id:'edu_attendance', label:{en:'Attendance',ar:'الحضور والانصراف'},       icon:'clipboard-check',
              tour:{en:'Take daily attendance for students or teachers per lecture. Mark present/absent, add notes for absences, and save with one click.',ar:'سجّل الحضور اليومي للطلاب أو المعلمين لكل محاضرة. حدد حاضر/غائب وأضف ملاحظات للغياب واحفظ بنقرة واحدة.'} },
            { id:'edu_income',     label:{en:'Income',ar:'الإيرادات'},                  icon:'trending-up',
              tour:{en:'All tuition fees and other income entries per student. Category and subcategory let you track what each payment is for.',ar:'جميع رسوم التعليم وإيرادات أخرى لكل طالب. الفئة والفئة الفرعية تتيح تتبع ما يخص كل دفعة.'},
              tableCols:{ en:['Stu-ID','Student Name','Category','Subcategory','Amount','Date'], ar:['رقم الطالب','اسم الطالب','الفئة','الفئة الفرعية','المبلغ','التاريخ'] } },
            { id:'edu_expenses',   label:{en:'Expenses',ar:'المصاريف'},                 icon:'trending-down',
              tour:{en:'Every outgoing cost — salaries, rent, supplies, and more. Categorized so you can see exactly where your budget goes.',ar:'كل تكلفة صادرة — رواتب وإيجار ومستلزمات وغيرها. مصنّفة لترى بالضبط أين يذهب ميزانيتك.'},
              tableCols:{ en:['Exp-ID','Title','Category','Subcategory','Amount','Date'], ar:['المعرف','العنوان','الفئة','الفئة الفرعية','المبلغ','التاريخ'] } },
            { id:'edu_cashflow',   label:{en:'Cash Flow',ar:'التدفق المالي'},            icon:'arrow-left-right',
              tour:{en:'Combined view of all income and expenses sorted by date. Filter by type (inflow/outflow) or category to spot any financial trend.',ar:'عرض موحد لجميع الإيرادات والمصاريف مرتبة بالتاريخ. فلتر بالنوع أو الفئة لرصد أي اتجاه مالي.'},
              tableCols:{ en:['Type','Label','Category','Amount','Date'], ar:['النوع','البيان','الفئة','المبلغ','التاريخ'] } },
            { id:'edu_config',     label:{en:'Settings',ar:'الإعدادات'},                icon:'settings-2',
              tour:{en:'Define teachers, grade levels with their fees, and income/expense categories with subcategories. All forms use these settings dynamically.',ar:'عرّف المعلمين والمستويات الدراسية برسومها وفئات الإيرادات والمصاريف. جميع النماذج تستخدم هذه الإعدادات تلقائيًا.'},
              tableCols:{ en:['Entity','Detail','Value'], ar:['الكيان','التفاصيل','القيمة'] } }
        ]
    }
};

// ─── LEAD PIPELINE STAGES ─────────────────────────────────────────────────────
const LEAD_STAGES = [
    { id:'new',       label:{en:'New',ar:'جديد'},             color:'#38bdf8', bg:'rgba(56,189,248,0.1)',  darkBg:'rgba(56,189,248,0.08)',  icon:'inbox',       next:'contacted', prev:null },
    { id:'contacted', label:{en:'Contacted',ar:'تم التواصل'}, color:'#818cf8', bg:'rgba(129,140,248,0.1)', darkBg:'rgba(129,140,248,0.08)', icon:'phone-call',  next:'qualified', prev:'new' },
    { id:'qualified', label:{en:'Qualified',ar:'مؤهل'},       color:'#fb923c', bg:'rgba(251,146,60,0.1)',  darkBg:'rgba(251,146,60,0.08)',  icon:'check-circle',next:'proposal',  prev:'contacted' },
    { id:'proposal',  label:{en:'Proposal',ar:'عرض سعر'},     color:'#f472b6', bg:'rgba(244,114,182,0.1)', darkBg:'rgba(244,114,182,0.08)', icon:'file-text',   next:'won',       prev:'qualified' },
    { id:'won',       label:{en:'Won ✓',ar:'تم الفوز ✓'},     color:'#34d399', bg:'rgba(52,211,153,0.1)',  darkBg:'rgba(52,211,153,0.08)',  icon:'trophy',      next:null,        prev:'proposal' },
    { id:'lost',      label:{en:'Lost',ar:'خسارة'},            color:'#f87171', bg:'rgba(248,113,113,0.1)', darkBg:'rgba(248,113,113,0.08)', icon:'x-circle',    next:null,        prev:'proposal' }
];

// ─── STATE ────────────────────────────────────────────────────────────────────
let state = {
    module: MODULES.LANDING,
    page: 'dashboard',
    darkMode: false,
    language: 'en',
    isModalOpen: false,
    isMobileMenuOpen: false,
    analyticsTab: 'overview',
    leadsView: 'pipeline',
    showTourInvite: false,
    data: {},
    leads: { crm: [], sales: [] },
    // ── Academy state ──
    edu: {
        viewingStudentId: null,
        viewingTeacherId: null,
        attDate: new Date().toISOString().split('T')[0],
        attType: 'Students',
        attLecture: 'General',
        tempAttendance: {},
        cfTypeFilter: 'All',
        cfCatFilter: 'All',
        searchQuery: '',
        gradeFilter: 'All',
        config: {
            teachers: ['Ahmed Hassan','Sara Mostafa','Kareem Nour','Mona Adel','Youssef Fathy'],
            gradeFees: { 'Year 1':1800, 'Year 2':2000, 'Year 3':2200, 'Year 4':2400, 'Year 5':2600, 'Year 6':2800 },
            incomeCategories: [
                { name:'Tuition Fees', subs:['Monthly','Quarterly','Annual'] },
                { name:'Registration', subs:['New Student','Re-enrollment'] },
                { name:'Activities', subs:['Trip','Event','Workshop'] }
            ],
            expenseCategories: [
                { name:'Salaries', subs:['Teacher','Admin','Security'] },
                { name:'Facilities', subs:['Rent','Utilities','Maintenance'] },
                { name:'Supplies', subs:['Stationery','Books','Equipment'] }
            ]
        }
    },
    // ── HR System state ──
    openEmployeeId: null,
    openSlipId: null,
    hr: {
        directoryView: 'table',
        directoryFilter: 'All',
        directorySearch: '',
        directoryDept: 'All',
        attendanceDate: new Date().toISOString().split('T')[0],
        attendanceDept: 'All',
        attendanceTab: 'log',
        leaveFilter: 'All',
        leaveTab: 'requests',
        payrollMonth: 'March 2025',
        payrollTab: 'summary',
        payrollSelected: [],
        contractFilter: 'All',
        contractSearch: '',
        recruitStageFilter: 'all',
        performancePeriod: 'Q1 2025',
        performanceTab: 'reviews',
        performanceSelected: null,
        trainingTab: 'courses',
        reportTab: 'overview',
        settingsTab: 'policies',
        leaveFormEmployee: '',
        leaveFormType: 'Annual',
        leaveFormStart: '',
        leaveFormEnd: '',
        leaveFormReason: '',
    }
};

const _t = (en, ar) => state.language === 'en' ? en : ar;
const ut = (key) => UI[state.language][key];

// ─── DATA INIT ────────────────────────────────────────────────────────────────
function initData() {
    const NAMES   = ["Ahmed Sharaf","Mona Zaki","Kareem Abdelaziz","Sara El-Gohary","Youssef El-Shamy","Omar Khairat","Layla Eloui","Tarek El-Sheikh","Hana Mustafa","Ramy Saleh"];
    const FIRSTNAMES = ["Ahmed","Mona","Kareem","Sara","Youssef","Omar","Layla","Tarek","Hana","Ramy"];
    const COMPANIES= ["Cairo Tech Solutions","Giza Systems","Nile Logistics","Delta Foods","Alexandria Steel","Suez Canal Energy","Red Sea Tourism","PetroJet","EgyInvest","Smart Build Co."];
    const BANKS    = ["CIB Bank","National Bank of Egypt","Banque Misr","QNB Al Ahli","HSBC Egypt","Arab African Bank","Faisal Islamic Bank","Al Baraka Egypt"];
    const INDUSTRIES= ["Technology","Logistics","Food & Beverage","Manufacturing","Energy","Tourism","Finance","Construction","Retail","Healthcare"];
    const SEGMENTS = ["Enterprise","SMB","Startup","Government","Non-Profit"];
    const REGIONS  = ["Cairo","Giza","Alexandria","Suez","Mansoura","Aswan","Luxor","Port Said"];
    const DEPTS    = ["Engineering","Sales","Finance","HR","Operations","Marketing","Legal","Customer Success"];
    const JOBS     = ["Software Engineer","Sales Manager","Financial Analyst","HR Specialist","Operations Director","Marketing Lead","Legal Counsel","Customer Success Manager","CTO","CFO","CEO","Data Analyst"];
    const CONTRACT_TYPES = ["Full-Time","Part-Time","Contractor","Internship"];
    const LEAVE_TYPES    = ["Annual","Sick","Emergency","Unpaid","Maternity"];
    const ACTIVITY_TYPES = ["Call","Email","Meeting","Demo","Follow-up","Proposal Sent"];
    const DEAL_NAMES     = ["Digital Transformation","ERP Implementation","Cloud Migration","IT Infrastructure","Supply Chain Upgrade","CRM Rollout","Mobile App Dev","Data Analytics Platform","Security Audit","Network Overhaul"];
    const INCOME_CATS    = ["Service Revenue","Product Sales","Consulting","License Fee","Maintenance","Support Contract"];
    const EXPENSE_CATS   = ["Salaries","Rent","Marketing","Utilities","Travel","Software Subscriptions","Office Supplies","Legal Fees"];
    const PAY_METHODS    = ["Bank Transfer","Cash","Credit Card","Check","Digital Wallet"];
    const TAX_TYPES      = ["VAT 14%","Income Tax","Withholding Tax","Stamp Duty","Social Insurance"];
    const PNL_LABELS     = ["Gross Revenue","Cost of Goods Sold","Gross Profit","Operating Expenses","EBITDA","Depreciation","Net Profit Before Tax","Income Tax","Net Profit"];
    const METRICS        = ["Turnover Rate","Headcount","Avg Salary","Training Hours","Absenteeism Rate","Time-to-Hire","Offer Acceptance Rate","Retention Rate"];
    const KPI_NAMES      = ["Monthly Revenue","Win Rate","Lead Conversion","Avg Deal Size","Customer Acquisition Cost","Customer Lifetime Value","Quota Attainment","Pipeline Coverage"];
    const TRAINING_NAMES = ["Leadership Development","Excel Advanced","Project Management","ISO 9001 Awareness","Sales Excellence","Python for Data","Cybersecurity Basics","Customer Service"];
    const PROVIDERS      = ["Coursera","LinkedIn Learning","Dale Carnegie","PwC Academy","McKinsey Academy","Internal L&D","ESLSCA","AUC Executive Ed"];
    const REPORT_TYPES   = ["Win/Loss Analysis","Pipeline Summary","Activity Report","Revenue by Region","Customer Churn Report","Forecast Accuracy","Lead Source ROI","Deal Velocity"];
    const SKU_PREFIXES   = ["SKU-PRD","SKU-SRV","SKU-LIC","SKU-SUP","SKU-HW"];
    const PRODUCT_NAMES  = ["MANTIQ CRM Pro","Cloud Storage 1TB","Data Analytics Suite","Support Package Gold","Hardware Bundle","API Integration License","Training Credits","Security Module","Mobile App Access","Custom Report Builder"];
    const SEVERITY       = ["Low","Medium","High","Critical"];
    const CHANNELS       = ["Email","SMS","WhatsApp","In-App","Phone"];
    const PRIORITIES     = ["Low","Medium","High","Urgent"];
    const ROLES          = ["Super Admin","Admin","Manager","Analyst","Sales Rep","HR Officer","Finance Controller","Read Only"];
    const RULE_NAMES     = ["Working Hours","Annual Leave Days","Overtime Rate","Probation Period","Notice Period","Social Insurance %","Income Tax Band","Max Sick Days"];
    const RULE_CATS      = ["Attendance","Leave","Compensation","Tax","Compliance"];
    const CONF_KEYS      = ["base_currency","fiscal_year_start","vat_rate","payment_terms_days","invoice_prefix","auto_reminder_days","approval_threshold","reporting_timezone"];
    const CONF_VALS      = ["EGP","January","14%","30","INV-","7","50,000 EGP","Africa/Cairo"];
    const STAGES_LIST    = ["Discovery","Proposal","Negotiation","Closed Won","Closed Lost"];
    const STATUSES_ALL   = ["Active","Pending","Completed","Paid","Approved","In Review","Rejected","On Hold"];
    const ACCT_TYPES     = ["Current Account","Savings Account","Petty Cash","Digital Wallet","Investment Account"];
    const CURRENCIES     = ["EGP","USD","EUR","GBP","SAR"];

    const rnd  = (arr) => arr[Math.floor(Math.random()*arr.length)];
    const rndN = (min,max) => Math.floor(Math.random()*(max-min+1))+min;
    const money= (min=10,max=150) => (rndN(min,max)*1000).toLocaleString() + ' EGP';
    const pct  = (min=40,max=99) => rndN(min,max) + '%';
    const date = (monthOffset=0) => { const d=new Date(2025,monthOffset+Math.floor(Math.random()*3),rndN(1,28)); return d.toISOString().slice(0,10); };
    const hours= () => rndN(7,9) + ':' + String(rndN(0,3)*10||'00').padStart(2,'0') + ' AM';
    const hout = () => rndN(4,6) + ':' + String(rndN(0,5)*10||'00').padStart(2,'0') + ' PM';

    Object.keys(SYSTEM_MAP).forEach(mod => {
        state.data[mod] = {};
        SYSTEM_MAP[mod].nav.forEach(page => {
            if (page.id === 'dashboard' || page.isAnalytics || !page.tableCols) return;
            state.data[mod][page.id] = [];
            for (let i = 0; i < 6; i++) {
                const row = {};
                const ni = (i*3+7) % NAMES.length;
                const ci = (i*2+1) % COMPANIES.length;
                (page.tableCols.en).forEach(col => {
                    const c = col.toLowerCase();
                    let v = '';
                    // ── IDs ──
                    if      (c==='e-id')                       v = 'EMP-' + (1000+i);
                    else if (c==='paid')                       v = money(5,30);
                    else if (c.includes('id') || c==='inv #' || c==='bill #' || c==='quote id' || c==='order id' || c==='invoice id' || c==='payment id' || c==='expense id' || c==='income id' || c==='leave id' || c==='contract id' || c==='record id' || c==='log id' || c==='activity id' || c==='reminder id' || c==='note id' || c==='customer id' || c==='contact id' || c==='lead id')
                                                                v = '#' + (1024+i);
                    // ── Names / People ──
                    else if (c==='full name' || c==='employee' || c==='payer/payee' || c==='from/to' || c==='user name' || c==='assigned to' || c==='reviewer' || c==='issued by' || c==='generated by' || c==='approved by' || c==='created by')
                                                                v = NAMES[ni];
                    else if (c==='rep name' || c==='sales rep' || c==='rep')
                                                                v = FIRSTNAMES[(i+2)%FIRSTNAMES.length];
                    else if (c==='name' && !c.includes('plan') && !c.includes('training') && !c.includes('rule'))
                                                                v = NAMES[ni];
                    else if (c==='contact')                     v = NAMES[(ni+4)%NAMES.length];
                    // ── Companies / Organisations ──
                    else if (c==='company'||c==='client'||c==='vendor'||c==='account'||c==='customer'||c==='payer/payee'||c==='source'&&mod===MODULES.FINANCE)
                                                                v = COMPANIES[ci];
                    // ── Contact info ──
                    else if (c==='phone'||c==='mobile')        v = '010' + rndN(10000000,99999999);
                    else if (c==='email')                       v = NAMES[ni].toLowerCase().replace(' ','.') + '@example.com';
                    // ── Money ──
                    else if (['amount','salary','base salary','revenue','value','total','budget','balance','ltv','lifetime value','gross comm','net comm','cost','achieved','target revenue','variance'].includes(c))
                                                                v = money(10,180);
                    else if (c==='allowances')                  v = money(1,8);
                    else if (c==='deductions')                  v = money(1,5);
                    else if (c==='tax')                         v = money(1,4);
                    else if (c==='net' || c==='net comm')       v = money(8,160);
                    else if (c==='subtotal')                    v = money(20,200);
                    else if (c==='vat'||c==='vat 14%')          v = money(1,8);
                    else if (c==='discount')                    v = ['5%','10%','15%','0%','20%'][i%5];
                    else if (c==='grand total' || c==='paid')   v = money(5,30);
                    else if (c==='unit price'||c==='rate')      v = money(1,20);
                    else if (c==='opening balance'||c==='closing balance'||c==='inflow'||c==='outflow'||c==='net flow')
                                                                v = money(100,500);
                    else if (c==='annual budget'||c==='q1 budget')  v = money(200,1000);
                    else if (c==='actual spent')                v = money(100,800);
                    else if (c==='base amount'||c==='tax amount')   v = money(50,300);
                    else if (c==='this period'||c==='last period')  v = money(200,2000);
                    else if (c==='adjustments')                 v = money(0,5);
                    // ── Percentages ──
                    else if (['prob %','probability','% achieved','attainment %','completion %','margin %','usage %','variance %','rate %','discount %'].includes(c))
                                                                v = pct(30,95);
                    else if (c==='overall (1-5)'||c==='kpi score') v = (rndN(30,50)/10).toFixed(1);
                    else if (c==='behaviour')                   v = (rndN(35,50)/10).toFixed(1);
                    else if (c==='score')                       v = rndN(55,98);
                    else if (c==='rate')                        v = ['14%','20%','25%','10%'][i%4];
                    else if (c==='balance')                     v = money(50,500);
                    // ── Dates ──
                    else if (c==='hire date'||c==='start'||c==='issue date'||c==='valid from'||c==='created at')
                                                                v = date(0);
                    else if (c==='end'||c==='due date'||c==='close date'||c==='valid until'||c==='valid to'||c==='expiry'||c==='filed date')
                                                                v = date(2);
                    else if (c==='delivery date')               v = date(1);
                    else if (c==='date'||c==='last contact'||c==='last updated'||c==='last sync'||c==='last txn')
                                                                v = date(0);
                    else if (c==='month'||c==='period')         v = ['Mar 2025','Feb 2025','Jan 2025','Q1 2025','Q4 2024'][i%5];
                    // ── Time ──
                    else if (c==='in')                          v = hours();
                    else if (c==='out')                         v = hout();
                    else if (c==='time')                        v = ['09:00 AM','10:30 AM','02:00 PM','04:15 PM'][i%4];
                    else if (c==='duration')                    v = ['15 min','30 min','1 hr','45 min','2 hr'][i%5];
                    else if (c==='hours')                       v = rndN(7,10) + 'h';
                    else if (c==='overtime')                    v = ['0h','1h','2h','0h','1.5h'][i%5];
                    else if (c==='days')                        v = rndN(1,14);
                    else if (c==='notice period')               v = ['30 days','60 days','90 days','14 days'][i%4];
                    else if (c==='duration'&&mod===MODULES.HR) v = rndN(1,5) + ' days';
                    // ── Enumerations ──
                    else if (c==='status')                      v = STATUSES_ALL[i%STATUSES_ALL.length];
                    else if (c==='stage'||c==='pipeline')       v = STAGES_LIST[i%STAGES_LIST.length];
                    else if (c==='source')                      v = ['Website','Referral','Cold Call','Social Media','Exhibition'][i%5];
                    else if (c==='type'&&(mod===MODULES.HR||c.includes('contract')))   v = rnd(CONTRACT_TYPES);
                    else if (c==='type'&&mod===MODULES.FINANCE) v = ['Inbound','Outbound','Internal Transfer'][i%3];
                    else if (c==='type')                        v = rnd(ACTIVITY_TYPES);
                    else if (c==='leave type'||c==='type'&&page.id==='leaves') v = rnd(LEAVE_TYPES);
                    else if (c==='tax type')                    v = TAX_TYPES[i%TAX_TYPES.length];
                    else if (c==='method'||c==='payment')       v = PAY_METHODS[i%PAY_METHODS.length];
                    else if (c==='channel')                     v = CHANNELS[i%CHANNELS.length];
                    else if (c==='priority')                    v = PRIORITIES[i%PRIORITIES.length];
                    else if (c==='severity')                    v = SEVERITY[i%SEVERITY.length];
                    else if (c==='role')                        v = ROLES[i%ROLES.length];
                    else if (c==='segment')                     v = SEGMENTS[i%SEGMENTS.length];
                    else if (c==='region')                      v = REGIONS[i%REGIONS.length];
                    else if (c==='industry')                    v = INDUSTRIES[i%INDUSTRIES.length];
                    else if (c==='currency')                    v = CURRENCIES[i%CURRENCIES.length];
                    else if (c==='dept'||c==='department')      v = DEPTS[i%DEPTS.length];
                    else if (c==='job title'||c==='title')      v = JOBS[i%JOBS.length];
                    else if (c==='contract'||c==='contract type')  v = rnd(CONTRACT_TYPES);
                    else if (c==='bank')                        v = BANKS[i%BANKS.length];
                    else if (c==='account name')                v = COMPANIES[ci] + ' – Main';
                    else if (c==='acct type'||c==='type'&&page.id==='wallets') v = ACCT_TYPES[i%ACCT_TYPES.length];
                    // ── Specific page values ──
                    else if (c==='deal name'||c==='project')    v = DEAL_NAMES[i%DEAL_NAMES.length];
                    else if (c==='subject')                     v = DEAL_NAMES[(i+2)%DEAL_NAMES.length];
                    else if (c==='category'&&mod===MODULES.FINANCE&&page.id==='income')  v = INCOME_CATS[i%INCOME_CATS.length];
                    else if (c==='category'&&mod===MODULES.FINANCE)                       v = EXPENSE_CATS[i%EXPENSE_CATS.length];
                    else if (c==='category')                    v = ['Software','Hardware','Services','Training','Infrastructure'][i%5];
                    else if (c==='training name'||c==='name'&&page.id==='training')      v = TRAINING_NAMES[i%TRAINING_NAMES.length];
                    else if (c==='provider')                    v = PROVIDERS[i%PROVIDERS.length];
                    else if (c==='enrollees'||c==='applicants'||c==='shortlisted'||c==='interviews') v = rndN(4,40);
                    else if (c==='items')                       v = rndN(1,8) + ' items';
                    else if (c==='sku')                         v = SKU_PREFIXES[i%SKU_PREFIXES.length] + '-' + rndN(1000,9999);
                    else if (c==='name'&&page.id==='products')  v = PRODUCT_NAMES[i%PRODUCT_NAMES.length];
                    else if (c==='stock')                       v = rndN(10,500) + ' units';
                    else if (c==='balance'&&page.id==='leaves') v = rndN(5,30) + ' days';
                    else if (c==='report type'||c==='kpi indicator'||c==='metric') v = (page.id==='reports'&&mod===MODULES.HR) ? METRICS[i%METRICS.length] : (page.id==='reports'&&mod===MODULES.SALES) ? KPI_NAMES[i%KPI_NAMES.length] : REPORT_TYPES[i%REPORT_TYPES.length];
                    else if (c==='label')                       v = PNL_LABELS[i%PNL_LABELS.length];
                    else if (c==='target'||c==='current value') v = money(50,300);
                    else if (c==='trend')                       v = ['↑ Up','↑ Up','↓ Down','→ Flat','↑ Up'][i%5];
                    else if (c==='growth %')                    v = ['+14%','+8%','-3%','+22%','+5%','+11%'][i%6];
                    else if (c==='reason')                      v = ['Policy violation','Performance issue','Attendance','Project delay','Budget overrun'][i%5];
                    else if (c==='clearance')                   v = ['Cleared','Pending','In Progress'][i%3];
                    else if (c==='eosp')                        v = money(30,120);
                    else if (c==='module access')               v = ['All Modules','CRM + Sales','HR Only','Finance Only','Read All'][i%5];
                    else if (c==='linked to')                   v = COMPANIES[ci];
                    else if (c==='tags')                        v = ['#hot-lead','#follow-up','#vip','#renewal','#upsell'][i%5];
                    else if (c==='rule name')                   v = RULE_NAMES[i%RULE_NAMES.length];
                    else if (c==='applies to'||c==='category'&&page.id==='settings'&&mod===MODULES.HR)  v = RULE_CATS[i%RULE_CATS.length];
                    else if (c==='configuration key'||c==='option') v = CONF_KEYS[i%CONF_KEYS.length];
                    else if (c==='value'&&(page.id==='settings'))    v = CONF_VALS[i%CONF_VALS.length];
                    else if (c==='reference')                   v = 'REF-' + rndN(10000,99999);
                    else if (c==='order' || c==='order ref')    v = 'ORD-' + (2000+i);
                    else if (c==='since')                       v = date(0);
                    else if (c==='format')                      v = ['PDF','Excel','CSV','PowerPoint'][i%4];
                    else if (c==='size')                        v = rndN(50,4000) + ' KB';
                    else if (c==='generated date')              v = date(0);
                    else                                        v = '—';
                    row[col] = v;
                });
                state.data[mod][page.id].push(row);
            }
        });
    });

    // ── Seed lead pipeline data for CRM & Sales ──
    const seedLeads = () => {
        const LNAMES = ["Ahmed Sharaf","Mona Zaki","Kareem Abdelaziz","Sara El-Gohary","Youssef El-Shamy","Omar Khairat","Layla Eloui","Tarek El-Sheikh","Hana Mustafa","Ramy Saleh"];
        const LCOMPANIES = ["Cairo Tech Solutions","Giza Systems","Nile Logistics","Delta Foods","Alexandria Steel","Suez Canal Energy","Red Sea Tourism","PetroJet","EgyInvest","Smart Build Co."];
        const LSOURCES = ["Website","Referral","Cold Call","Social Media","Exhibition"];
        const stageIds = LEAD_STAGES.map(s=>s.id);
        const leads = [];
        let id = 2001;
        stageIds.forEach((stageId, si) => {
            const count = [4, 3, 3, 2, 2, 1][si] || 2;
            for (let i = 0; i < count; i++) {
                const ni = (id + i) % LNAMES.length;
                const ci = (id + i + 2) % LCOMPANIES.length;
                leads.push({
                    id: '#L-' + id++,
                    name: LNAMES[ni],
                    company: LCOMPANIES[ci],
                    phone: '010' + Math.floor(10000000 + Math.random()*90000000),
                    source: LSOURCES[(si+i) % LSOURCES.length],
                    value: (Math.floor(Math.random()*90)+10) + ',000 EGP',
                    score: Math.floor(Math.random()*40)+60,
                    assignedTo: LNAMES[(ni+3) % LNAMES.length].split(' ')[0],
                    stage: stageId,
                    createdAt: '2025-0' + (Math.floor(i/3)+1) + '-' + (10+i)
                });
            }
        });
        return leads;
    };
    state.leads.crm = seedLeads();
    state.leads.sales = seedLeads();

    // ── Seed Academy data ──
    const STU_NAMES = [
        'Ahmed Mostafa','Sara Ahmed','Kareem Nabil','Layla Hassan','Omar Samir','Hana Youssef','Tarek Adel','Mona Essam',
        'Ramy Fawzy','Dina Kamal','Youssef Samy','Noha Adel','Amira Hossam','Islam Raafat','Rana Magdy','Bassem Atef',
        'Nour El-Din','Salma Khaled','Ziad Mostafa','Mariam Sherif','Hassan Abdalla','Fatma Ibrahim','Sherif Gaber','Asmaa Lotfy',
        'Mahmoud Tarek','Enas Saad','Walid Nour','Ghada Riad','Alaa Hassan','Rania Tawfik'
    ];
    const GRADES = Object.keys(state.edu.config.gradeFees);
    const DAYS = ['Sunday','Monday','Tuesday','Wednesday','Thursday'];
    const SUBJECTS = ['Mathematics','Arabic Language','English','Science','Social Studies','Religion','Computer','Art','Physical Education','French'];
    const ROOMS = ['Room A1','Room A2','Room B1','Room B2','Hall 1','Lab 1','Library'];
    const TIMES = ['08:00','09:00','10:00','11:00','12:00','13:00','14:00'];
    const TEACHERS = state.edu.config.teachers;
    const INC_CATS = state.edu.config.incomeCategories;
    const EXP_CATS = state.edu.config.expenseCategories;
    const EXP_TITLES = ['Teacher Salary','Admin Salary','Monthly Rent','Electricity Bill','Stationery Purchase','Book Bundle','Security Salary','Maintenance Work','Equipment Repair','Internet Bill'];

    // Students (30)
    state.data[MODULES.ACADEMY] = {};
    state.data[MODULES.ACADEMY].edu_students = STU_NAMES.map((name,i) => ({
        'Stu-ID':    'STU-' + String(1001+i).padStart(4,'0'),
        'Student Name': name,
        'Age':       String(rndN(6,18)),
        'Phone':     '010' + rndN(10000000,99999999),
        'Grade':     GRADES[i % GRADES.length],
        'Status':    i % 7 === 0 ? 'Inactive' : 'Active'
    }));

    // Teachers (seeded via config already; table view)
    state.data[MODULES.ACADEMY].edu_teachers = TEACHERS.map((name,i) => ({
        'Teacher ID':  'TCH-' + String(101+i).padStart(3,'0'),
        'Full Name':   name,
        'Subject':     SUBJECTS[i % SUBJECTS.length],
        'Grade':       GRADES[i % GRADES.length],
        'Phone':       '011' + rndN(10000000,99999999),
        'Hire Date':   '2023-0' + String((i%9)+1).padStart(2,'0') + '-01',
        'Status':      'Active'
    }));

    // Schedule (one entry per teacher per day)
    state.data[MODULES.ACADEMY].edu_schedule = TEACHERS.flatMap((teacher, ti) =>
        DAYS.slice(0,3).map((day, di) => ({
            'Grade':      GRADES[(ti+di) % GRADES.length],
            'Subject':    SUBJECTS[(ti*2+di) % SUBJECTS.length],
            'Teacher':    teacher,
            'Day':        day,
            'Room':       ROOMS[(ti+di) % ROOMS.length],
            'Start Time': TIMES[(ti+di) % TIMES.length],
            'Duration':   ['45 min','60 min','90 min'][(ti+di)%3]
        }))
    );

    // Income (one per student, spread months)
    state.data[MODULES.ACADEMY].edu_income = state.data[MODULES.ACADEMY].edu_students.map((stu,i) => {
        const cat = INC_CATS[i % INC_CATS.length];
        const sub = cat.subs[i % cat.subs.length];
        const fee = state.edu.config.gradeFees[stu.Grade] || 2000;
        return {
            'Stu-ID':       stu['Stu-ID'],
            'Student Name': stu['Student Name'],
            'Category':     cat.name,
            'Subcategory':  sub,
            'Amount':       String(fee),
            'Date':         '2025-' + String((i%3)+1).padStart(2,'0') + '-' + String(rndN(1,28)).padStart(2,'0')
        };
    });

    // Expenses (10)
    state.data[MODULES.ACADEMY].edu_expenses = EXP_TITLES.map((title,i) => {
        const cat = EXP_CATS[i % EXP_CATS.length];
        const sub = cat.subs[i % cat.subs.length];
        return {
            'Exp-ID':      'EXP-' + String(1001+i).padStart(4,'0'),
            'Title':       title,
            'Category':    cat.name,
            'Subcategory': sub,
            'Amount':      String(rndN(2,30) * 1000),
            'Date':        '2025-0' + String(rndN(1,3)).padStart(2,'0') + '-' + String(rndN(1,28)).padStart(2,'0')
        };
    });

    // Attendance records (sample)
    state.data[MODULES.ACADEMY].edu_attendance = state.data[MODULES.ACADEMY].edu_students.slice(0,10).map((stu,i) => ({
        'Date':     '2025-03-10',
        'Type':     'Students',
        'Lecture':  SUBJECTS[i % SUBJECTS.length],
        'TargetID': stu['Stu-ID'],
        'Label':    stu['Student Name'],
        'Status':   i % 5 === 0 ? 'Absent' : 'Present',
        'Note':     i % 5 === 0 ? 'Sick leave' : '',
        'Grade':    stu.Grade
    }));

    // Cash flow (combined view — built dynamically)
    state.data[MODULES.ACADEMY].edu_cashflow = [];
    // Config placeholder for settings page
    state.data[MODULES.ACADEMY].edu_config = [];
}

// ─── HELPERS ──────────────────────────────────────────────────────────────────
function pushNotify(msg) {
    const c = document.getElementById('notification-container');
    const t = document.createElement('div');
    t.className = 'toast-note bg-mantiq-navy dark:bg-white text-white dark:text-mantiq-navy px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 border-l-4 border-mantiq-cyan fade-in';
    t.innerHTML = `<i data-lucide="shield-check" class="text-mantiq-cyan w-4 h-4 flex-shrink-0"></i><span class="text-sm font-bold">${msg}</span>`;
    c.appendChild(t);
    lucide.createIcons();
    // After 3 seconds, add hiding class then remove
    setTimeout(() => {
        t.classList.add('hiding');
        setTimeout(() => t.remove(), 520);
    }, 3000);
}

// ─── LEAD DETAIL DRAWER ───────────────────────────────────────────────────────
function openLeadDetail(leadId) {
    state.openLeadId = leadId;
    render();
    // Don't scroll — drawer overlays
}

function closeLeadDetail() {
    state.openLeadId = null;
    render();
}

function renderLeadDrawer() {
    const store = getLeadStore();
    const lead = store.find(l => l.id === state.openLeadId);
    if (!lead) return '';

    const stage = LEAD_STAGES.find(s => s.id === lead.stage) || LEAD_STAGES[0];
    const scoreColor = lead.score >= 80 ? '#34d399' : lead.score >= 60 ? '#fb923c' : '#f87171';
    const nextStage = LEAD_STAGES.find(s => s.id === stage.next);
    const prevStage = LEAD_STAGES.find(s => s.id === stage.prev);

    // Fake contacts tied to the lead
    const contacts = [
        { name: lead.name, role: _t('Primary Contact','جهة الاتصال الرئيسية'), phone: lead.phone, email: lead.name.toLowerCase().replace(' ','.') + '@' + lead.company.toLowerCase().replace(/ /g,'') + '.com', avatar: lead.name.slice(0,2).toUpperCase() },
        { name: lead.assignedTo, role: _t('Assigned Rep','المندوب المسؤول'), phone: '0100' + Math.floor(1000000 + (lead.score * 12345) % 9000000), email: lead.assignedTo.toLowerCase() + '@mantiq.io', avatar: lead.assignedTo.slice(0,2).toUpperCase() }
    ];

    // Activity timeline
    const activities = [
        { icon:'mail',        color:'#38bdf8', label:_t('Email sent','تم إرسال بريد'),           time:_t('2 days ago','منذ يومين'),   note: _t('Introduction email sent to '+lead.name, 'تم إرسال بريد تعريفي لـ '+lead.name) },
        { icon:'phone-call',  color:'#818cf8', label:_t('Call made','مكالمة هاتفية'),             time:_t('1 day ago','منذ يوم'),      note: _t('Discussed requirements, high interest shown.','تمت المناقشة، أبدى اهتماماً كبيراً.') },
        { icon:'file-text',   color:'#fb923c', label:_t('Note added','ملاحظة مضافة'),             time:_t('5 hrs ago','منذ 5 ساعات'), note: _t('Budget confirmed: ' + lead.value, 'الميزانية المؤكدة: ' + lead.value) },
        { icon:'user-check',  color:'#34d399', label:_t('Stage updated','تحديث المرحلة'),         time:_t('Just now','الآن'),          note: _t('Moved to ' + stage.label.en, 'نُقل إلى ' + stage.label.ar) }
    ];

    const infoRows = [
        { label:_t('Lead ID','المعرف'),          val: lead.id },
        { label:_t('Company','الشركة'),           val: lead.company },
        { label:_t('Source','المصدر'),             val: lead.source },
        { label:_t('Deal Value','قيمة الصفقة'),   val: lead.value },
        { label:_t('Lead Score','نقاط العميل'),   val: `<span style="color:${scoreColor};font-weight:900">${lead.score}/100</span>` },
        { label:_t('Created','تاريخ الإنشاء'),    val: lead.createdAt },
        { label:_t('Assigned To','المسؤول'),      val: lead.assignedTo }
    ];

    return `
        <div class="lead-drawer-overlay" onclick="closeLeadDetail()"></div>
        <div class="lead-drawer custom-scrollbar" onclick="event.stopPropagation()">
            <!-- Header -->
            <div class="sticky top-0 z-10 bg-white dark:bg-slate-900/95 backdrop-blur-sm border-b border-slate-100 dark:border-slate-800 px-8 py-6 flex items-center justify-between">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-2xl flex items-center justify-center text-white text-sm font-black" style="background:${stage.color}">${lead.name.slice(0,2).toUpperCase()}</div>
                    <div>
                        <p class="font-black text-mantiq-navy dark:text-white text-base leading-tight">${lead.name}</p>
                        <p class="text-xs text-slate-400 font-bold">${lead.company}</p>
                    </div>
                </div>
                <button onclick="closeLeadDetail()" class="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-rose-500 transition-colors">
                    <i data-lucide="x" size="20"></i>
                </button>
            </div>

            <div class="p-8 space-y-8">
                <!-- Stage badge + transfer -->
                <div>
                    <p class="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3">${_t('Current Stage','المرحلة الحالية')}</p>
                    <div class="flex flex-wrap items-center gap-2 mb-4">
                        <span class="flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-black text-white" style="background:${stage.color}">
                            <i data-lucide="${stage.icon}" size="14"></i>${_t(stage.label.en, stage.label.ar)}
                        </span>
                    </div>
                    <!-- Stage progress bar -->
                    <div class="flex items-center gap-1 mb-4">
                        ${LEAD_STAGES.filter(s=>!['won','lost'].includes(s.id)).map(s => {
                            const stageIdx = LEAD_STAGES.filter(x=>!['won','lost'].includes(x.id)).findIndex(x=>x.id===s.id);
                            const currentIdx = LEAD_STAGES.filter(x=>!['won','lost'].includes(x.id)).findIndex(x=>x.id===lead.stage);
                            const isPast = stageIdx <= currentIdx;
                            return `<div class="flex-1 h-2 rounded-full transition-all" style="background:${isPast ? s.color : (state.darkMode?'#1e293b':'#e2e8f0')}"></div>`;
                        }).join('<div class="w-1"></div>')}
                    </div>
                    <!-- Transfer buttons -->
                    <div class="flex flex-wrap gap-2">
                        ${prevStage ? `<button onclick="transferLead('${lead.id}','${prevStage.id}'); state.openLeadId='${lead.id}';" class="transfer-btn text-white text-xs px-4 py-2" style="background:${prevStage.color}88">← ${_t(prevStage.label.en,prevStage.label.ar)}</button>` : ''}
                        ${nextStage ? `<button onclick="transferLead('${lead.id}','${nextStage.id}'); state.openLeadId='${lead.id}';" class="transfer-btn text-white text-xs px-4 py-2" style="background:${nextStage.color}">${_t(nextStage.label.en,nextStage.label.ar)} →</button>` : ''}
                        ${stage.id === 'proposal' ? `<button onclick="transferLead('${lead.id}','lost'); state.openLeadId='${lead.id}';" class="transfer-btn text-white text-xs px-4 py-2" style="background:#f87171">✕ ${_t('Mark Lost','تسجيل خسارة')}</button>` : ''}
                    </div>
                </div>

                <!-- Lead Info -->
                <div>
                    <p class="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4">${_t('Lead Details','تفاصيل العميل')}</p>
                    <div class="bg-slate-50 dark:bg-slate-800/50 rounded-2xl overflow-hidden divide-y divide-slate-100 dark:divide-slate-800">
                        ${infoRows.map(r=>`
                            <div class="flex justify-between items-center px-5 py-3.5">
                                <span class="text-xs font-bold text-slate-400 uppercase tracking-wide">${r.label}</span>
                                <span class="text-sm font-black text-mantiq-navy dark:text-white text-right">${r.val}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <!-- Contacts -->
                <div>
                    <p class="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4">${_t('Contacts','جهات الاتصال')}</p>
                    <div class="space-y-3">
                        ${contacts.map(c=>`
                            <div class="flex items-center gap-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl px-5 py-4">
                                <div class="w-10 h-10 rounded-xl bg-mantiq-navy dark:bg-white text-white dark:text-mantiq-navy flex items-center justify-center font-black text-xs flex-shrink-0">${c.avatar}</div>
                                <div class="flex-1 min-w-0">
                                    <p class="text-sm font-black text-mantiq-navy dark:text-white">${c.name}</p>
                                    <p class="text-[11px] text-slate-400 font-bold">${c.role}</p>
                                    <p class="text-[11px] text-mantiq-cyan font-bold truncate">${c.email}</p>
                                </div>
                                <div class="flex gap-2 flex-shrink-0">
                                    <button onclick="pushNotify('${_t('Calling','جاري الاتصال')} ${c.phone}')" class="p-2 rounded-xl hover:bg-white dark:hover:bg-slate-700 text-slate-400 hover:text-mantiq-cyan transition-colors">
                                        <i data-lucide="phone" size="15"></i>
                                    </button>
                                    <button onclick="pushNotify('${_t('Opening email for','فتح بريد')} ${c.name}')" class="p-2 rounded-xl hover:bg-white dark:hover:bg-slate-700 text-slate-400 hover:text-mantiq-cyan transition-colors">
                                        <i data-lucide="mail" size="15"></i>
                                    </button>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <!-- Activity Timeline -->
                <div>
                    <p class="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-4">${_t('Activity Timeline','سجل النشاط')}</p>
                    <div class="space-y-0">
                        ${activities.map((a, idx) => `
                            <div class="flex gap-4">
                                <div class="flex flex-col items-center">
                                    <div class="timeline-dot" style="background:${a.color}"></div>
                                    ${idx < activities.length-1 ? '<div class="timeline-line"></div>' : ''}
                                </div>
                                <div class="pb-5 flex-1 min-w-0">
                                    <div class="flex items-center justify-between mb-1">
                                        <div class="flex items-center gap-1.5">
                                            <i data-lucide="${a.icon}" size="13" style="color:${a.color}"></i>
                                            <span class="text-xs font-black text-mantiq-navy dark:text-white">${a.label}</span>
                                        </div>
                                        <span class="text-[10px] text-slate-400 font-bold whitespace-nowrap">${a.time}</span>
                                    </div>
                                    <p class="text-[11px] text-slate-500 leading-relaxed">${a.note}</p>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <!-- Actions -->
                <div class="flex gap-3 pb-4">
                    <button onclick="pushNotify('${_t('Opening task creator...','فتح منشئ المهام...')}')" class="flex-1 flex items-center justify-center gap-2 py-4 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-black text-xs uppercase">
                        <i data-lucide="clipboard-list" size="14"></i>${_t('Add Task','إضافة مهمة')}
                    </button>
                    <button onclick="pushNotify('${_t('Opening note editor...','فتح محرر الملاحظات...')}')" class="flex-1 flex items-center justify-center gap-2 py-4 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-black text-xs uppercase">
                        <i data-lucide="sticky-note" size="14"></i>${_t('Add Note','إضافة ملاحظة')}
                    </button>
                    <button onclick="deleteLeadFromPipeline('${lead.id}'); closeLeadDetail();" class="py-4 px-4 rounded-2xl bg-red-50 dark:bg-red-950/40 text-rose-500 font-black">
                        <i data-lucide="trash-2" size="16"></i>
                    </button>
                </div>
            </div>
        </div>
    `;
}

function badgeHtml(val) {
    const v = (val || '').toLowerCase();
    let cls = 'badge-blue';
    if (['active','paid','approved','completed','closed won','verified'].some(s=>v.includes(s))) cls='badge-green';
    else if (['pending','in review','proposal','discovery'].some(s=>v.includes(s))) cls='badge-amber';
    else if (['closed lost','terminated','rejected','failed'].some(s=>v.includes(s))) cls='badge-red';
    return `<span class="badge ${cls}">${val}</span>`;
}

function isStatusCol(col) {
    return ['status','stage','clearance'].some(s=>col.toLowerCase().includes(s));
}

// ─── ACTIONS ──────────────────────────────────────────────────────────────────
function setLanguage(l) { state.language=l; document.body.dir=l==='ar'?'rtl':'ltr'; render(); }
function setModule(m) {
    state.module=m; state.page='dashboard'; state.isMobileMenuOpen=false;
    state.addLeadMode=false; state.openLeadId=null;
    state.showTourInvite = (m !== MODULES.LANDING);
    tourState = { active:false, stepIndex:0, mod:m };
    // Reset Academy sub-state
    if (state.edu) { state.edu.viewingStudentId=null; state.edu.viewingTeacherId=null; state.edu.searchQuery=''; state.edu.gradeFilter='All'; state.edu.cfTypeFilter='All'; state.edu.cfCatFilter='All'; state.edu.tempAttendance={}; }
    render(); window.scrollTo({top:0,behavior:'smooth'});
}
function setPage(p) { state.page=p; state.isMobileMenuOpen=false; state.addLeadMode=false; state.openLeadId=null; if(state.edu){state.edu.viewingStudentId=null;state.edu.viewingTeacherId=null;state.edu.searchQuery='';state.edu.gradeFilter='All';state.edu.cfTypeFilter='All';state.edu.cfCatFilter='All';state.edu.tempAttendance={};} render(); }
function toggleDarkMode() { state.darkMode=!state.darkMode; document.documentElement.classList.toggle('dark',state.darkMode); render(); }
function toggleMobileMenu() { state.isMobileMenuOpen=!state.isMobileMenuOpen; render(); }
function setAnalyticsTab(t) { state.analyticsTab=t; renderCharts(); }

function handleAddData(e) {
    if(e) e.preventDefault();
    const form = document.getElementById('add-record-form');
    const formData = new FormData(form);
    const newRecord = {};
    formData.forEach((value,key)=>{ newRecord[key]=value||"-"; });
    state.data[state.module][state.page].unshift(newRecord);
    pushNotify(_t("Data synchronized with MANTIQ successfully.","تم حفظ البيانات في مانتيك بنجاح"));
    state.isModalOpen=false;
    render();
}

function handleDelete(idx) {
    state.data[state.module][state.page].splice(idx,1);
    pushNotify(_t("Record purged from database.","تم حذف السجل من القاعدة"));
    render();
}

// ─── LEAD PIPELINE ACTIONS ────────────────────────────────────────────────────
function getLeadStore() {
    return state.module === MODULES.CRM ? state.leads.crm : state.leads.sales;
}

function transferLead(leadId, toStage) {
    const store = getLeadStore();
    const lead = store.find(l => l.id === leadId);
    if (!lead) return;
    const fromStage = LEAD_STAGES.find(s => s.id === lead.stage);
    const toStageObj = LEAD_STAGES.find(s => s.id === toStage);
    lead.stage = toStage;
    const fromLabel = _t(fromStage.label.en, fromStage.label.ar);
    const toLabel   = _t(toStageObj.label.en, toStageObj.label.ar);
    pushNotify(`${lead.name} → ${toLabel}`);
    render();
}

function addLeadFromModal(data) {
    const store = getLeadStore();
    store.unshift({
        id: '#L-' + (3000 + store.length),
        name: data.name || _t('New Lead','عميل جديد'),
        company: data.company || '-',
        phone: data.phone || '-',
        source: data.source || 'Manual',
        value: data.value || '0 EGP',
        score: parseInt(data.score) || 50,
        assignedTo: data.assignedTo || 'Unassigned',
        stage: 'new',
        createdAt: new Date().toISOString().slice(0,10)
    });
    pushNotify(_t('Lead added to pipeline ✓','تم إضافة العميل للمسار ✓'));
    state.isModalOpen = false;
    render();
}

function deleteLeadFromPipeline(leadId) {
    if (state.module === MODULES.CRM) {
        state.leads.crm = state.leads.crm.filter(l => l.id !== leadId);
    } else {
        state.leads.sales = state.leads.sales.filter(l => l.id !== leadId);
    }
    pushNotify(_t('Lead removed.','تم حذف العميل.'));
    render();
}

// ─── LEADS PIPELINE RENDER ────────────────────────────────────────────────────
function renderLeadsPipeline() {
    const store = getLeadStore();
    const isDark = state.darkMode;

    // Summary counters per stage
    const stageCounts = {};
    LEAD_STAGES.forEach(s => { stageCounts[s.id] = store.filter(l=>l.stage===s.id).length; });
    const totalValue = store.filter(l=>l.stage!=='lost').reduce((sum,l)=>{
        const n = parseInt((l.value||'').replace(/[^0-9]/g,'')) || 0;
        return sum + n;
    }, 0);

    // Top summary bar
    const summaryHtml = `
        <div class="flex flex-wrap gap-3 mb-8">
            ${LEAD_STAGES.map(s=>`
                <div class="flex items-center gap-2 px-4 py-2.5 rounded-2xl border text-xs font-black" style="border-color:${s.color}30; background:${isDark?s.darkBg:s.bg}; color:${s.color}">
                    <i data-lucide="${s.icon}" size="13"></i>
                    <span>${_t(s.label.en,s.label.ar)}</span>
                    <span class="ml-1 px-2 py-0.5 rounded-full text-white text-[10px]" style="background:${s.color}">${stageCounts[s.id]}</span>
                </div>
            `).join('')}
            <div class="ml-auto flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-mantiq-navy dark:bg-white text-white dark:text-mantiq-navy text-xs font-black">
                <i data-lucide="trending-up" size="13"></i>
                <span>${_t('Pipeline Total:','إجمالي المسار:')} ${Math.round(totalValue/1000)}K EGP</span>
            </div>
        </div>
    `;

    // Kanban columns
    const columnsHtml = LEAD_STAGES.map(stage => {
        const leads = store.filter(l => l.stage === stage.id);

        const cardsHtml = leads.map(lead => {
            const scoreColor = lead.score >= 80 ? '#34d399' : lead.score >= 60 ? '#fb923c' : '#f87171';
            const nextStage = LEAD_STAGES.find(s=>s.id===stage.next);
            const prevStage = LEAD_STAGES.find(s=>s.id===stage.prev);

            return `
                <div class="pipeline-card" onclick="openLeadDetail('${lead.id}')">
                    <div class="flex items-start justify-between mb-2">
                        <div>
                            <p class="font-black text-sm text-mantiq-navy dark:text-white leading-tight">${lead.name}</p>
                            <p class="text-[11px] text-slate-500 mt-0.5">${lead.company}</p>
                        </div>
                        <button onclick="event.stopPropagation(); deleteLeadFromPipeline('${lead.id}')" class="text-slate-300 hover:text-rose-400 transition-colors p-1 -mt-1 -mr-1">
                            <i data-lucide="x" size="13"></i>
                        </button>
                    </div>
                    <div class="flex items-center justify-between mb-1">
                        <span class="text-[10px] font-bold text-slate-400">${lead.source}</span>
                        <span class="text-[10px] font-black" style="color:${scoreColor}">${_t('Score','نقاط')}: ${lead.score}</span>
                    </div>
                    <div class="flex items-center justify-between">
                        <span class="text-xs font-black text-mantiq-navy dark:text-white">${lead.value}</span>
                        <span class="text-[10px] text-slate-400 font-bold">${lead.assignedTo}</span>
                    </div>
                    <div class="flex flex-wrap gap-1.5 mt-3 pt-3 border-t border-slate-100 dark:border-slate-800" onclick="event.stopPropagation()">
                        ${prevStage ? `
                            <button onclick="transferLead('${lead.id}','${prevStage.id}')"
                                class="transfer-btn text-white"
                                style="background:${prevStage.color}bb; font-size:9px; padding:4px 9px;">
                                ← ${_t(prevStage.label.en, prevStage.label.ar)}
                            </button>
                        ` : ''}
                        ${nextStage ? `
                            <button onclick="transferLead('${lead.id}','${nextStage.id}')"
                                class="transfer-btn text-white"
                                style="background:${nextStage.color}; font-size:9px; padding:4px 9px;">
                                ${_t(nextStage.label.en, nextStage.label.ar)} →
                            </button>
                        ` : ''}
                        ${stage.id === 'proposal' ? `
                            <button onclick="transferLead('${lead.id}','lost')"
                                class="transfer-btn text-white"
                                style="background:#f87171; font-size:9px; padding:4px 9px;">
                                ✕ ${_t('Lost','خسارة')}
                            </button>
                        ` : ''}
                    </div>
                </div>
            `;
        }).join('') || `<div class="text-center py-8 text-slate-300 dark:text-slate-700 text-xs font-bold">${_t('No leads','لا يوجد')}</div>`;

        return `
            <div class="pipeline-col">
                <div class="pipeline-col-header" style="background:${isDark?stage.darkBg:stage.bg}; color:${stage.color}">
                    <div class="flex items-center gap-2">
                        <i data-lucide="${stage.icon}" size="14"></i>
                        <span>${_t(stage.label.en, stage.label.ar)}</span>
                    </div>
                    <span class="w-6 h-6 flex items-center justify-center rounded-full text-white text-[10px] font-black" style="background:${stage.color}">${leads.length}</span>
                </div>
                ${cardsHtml}
            </div>
        `;
    }).join('');

    return `
        <div class="flex flex-col md:flex-row justify-between md:items-center gap-4 mb-6">
            <div>
                <h2 class="text-xl md:text-3xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${_t('Lead Pipeline','مسار العملاء')}</h2>
                <p class="text-slate-400 text-xs font-bold mt-1">${_t('Transfer leads across stages by clicking the stage buttons on each card','انقل العملاء بين المراحل بالضغط على أزرار المرحلة في كل بطاقة')}</p>
            </div>
            <div class="flex gap-3">
                <button onclick="state.leadsView='table'; render();" class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-5 py-3.5 rounded-2xl font-black text-xs text-slate-500 flex items-center gap-2">
                    <i data-lucide="list" size="14"></i>${_t('Table View','عرض جدول')}
                </button>
                <button onclick="state.isModalOpen=true; state.addLeadMode=true; render();" class="bg-mantiq-navy dark:bg-white text-white dark:text-mantiq-navy px-6 py-3.5 rounded-2xl font-black text-xs shadow-xl flex items-center gap-2">
                    <i data-lucide="plus" size="14"></i>${_t('Add Lead','إضافة عميل')}
                </button>
            </div>
        </div>
        ${summaryHtml}
        <div class="pipeline-board">${columnsHtml}</div>
    `;
}

function renderLeadsTable() {
    const store = getLeadStore();

    const rowsHtml = store.map((lead, idx) => {
        const stage = LEAD_STAGES.find(s=>s.id===lead.stage) || LEAD_STAGES[0];
        const scoreColor = lead.score >= 80 ? '#34d399' : lead.score >= 60 ? '#fb923c' : '#f87171';
        const nextStage = LEAD_STAGES.find(s=>s.id===stage.next);
        return `
            <tr class="group hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-all border-b border-slate-100 dark:border-slate-800 last:border-0 cursor-pointer" onclick="openLeadDetail('${lead.id}')">
                <td class="px-8 py-5 text-sm font-black text-slate-500 whitespace-nowrap">${lead.id}</td>
                <td class="px-8 py-5 whitespace-nowrap">
                    <div>
                        <p class="text-sm font-black text-mantiq-navy dark:text-white">${lead.name}</p>
                        <p class="text-xs text-slate-400">${lead.company}</p>
                    </div>
                </td>
                <td class="px-8 py-5 text-sm font-bold text-slate-600 dark:text-slate-300 whitespace-nowrap">${lead.phone}</td>
                <td class="px-8 py-5 text-sm font-bold text-slate-600 dark:text-slate-300 whitespace-nowrap">${lead.source}</td>
                <td class="px-8 py-5 whitespace-nowrap">
                    <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black text-white" style="background:${stage.color}">
                        <i data-lucide="${stage.icon}" size="10"></i>${_t(stage.label.en,stage.label.ar)}
                    </span>
                </td>
                <td class="px-8 py-5 text-sm font-bold whitespace-nowrap" style="color:${scoreColor}">${lead.score}</td>
                <td class="px-8 py-5 text-sm font-black text-mantiq-navy dark:text-white whitespace-nowrap">${lead.value}</td>
                <td class="px-8 py-5 text-sm font-bold text-slate-500 whitespace-nowrap">${lead.assignedTo}</td>
                <td class="px-8 py-5 whitespace-nowrap" onclick="event.stopPropagation()">
                    <div class="flex gap-2">
                        ${nextStage ? `<button onclick="transferLead('${lead.id}','${nextStage.id}')" class="transfer-btn text-white text-[9px]" style="background:${nextStage.color}">→ ${_t(nextStage.label.en,nextStage.label.ar)}</button>` : '<span class="text-xs text-slate-300 font-bold">—</span>'}
                        <button onclick="deleteLeadFromPipeline('${lead.id}')" class="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-slate-700 text-slate-400 hover:text-rose-500 transition-colors"><i data-lucide="trash-2" size="14"></i></button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');

    const headers = _t(
        ['ID','Name','Phone','Source','Stage','Score','Value','Assigned To','Actions'],
        ['المعرف','الاسم','الهاتف','المصدر','المرحلة','النقاط','القيمة','المسؤول','إجراءات']
    );

    return `
        <div class="flex flex-col md:flex-row justify-between md:items-center gap-4 mb-8">
            <h2 class="text-xl md:text-3xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${_t('Leads — Table View','العملاء — عرض الجدول')}</h2>
            <div class="flex gap-3">
                <button onclick="state.leadsView='pipeline'; render();" class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-5 py-3.5 rounded-2xl font-black text-xs text-slate-500 flex items-center gap-2">
                    <i data-lucide="kanban" size="14"></i>${_t('Pipeline View','عرض المسار')}
                </button>
                <button onclick="pushNotify('${_t('Exporting...','تصدير...')}')" class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-5 py-3.5 rounded-2xl font-black text-xs text-slate-500 flex items-center gap-2">
                    <i data-lucide="download" size="14"></i>${ut('export')}
                </button>
                <button onclick="state.isModalOpen=true; state.addLeadMode=true; render();" class="bg-mantiq-navy dark:bg-white text-white dark:text-mantiq-navy px-6 py-3.5 rounded-2xl font-black text-xs shadow-xl flex items-center gap-2">
                    <i data-lucide="plus" size="14"></i>${_t('Add Lead','إضافة عميل')}
                </button>
            </div>
        </div>
        <div class="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden overflow-x-auto custom-scrollbar">
            <table class="w-full text-left border-collapse" dir="${state.language==='ar'?'rtl':'ltr'}">
                <thead class="bg-slate-50/70 dark:bg-slate-800/50 text-[10px] uppercase tracking-[0.2em] font-black text-slate-500">
                    <tr>${headers.map(h=>`<th class="px-8 py-6 whitespace-nowrap">${h}</th>`).join('')}</tr>
                </thead>
                <tbody>${rowsHtml || `<tr><td colspan="9" class="p-20 text-center italic text-slate-400">${_t('No leads found','لا توجد عملاء')}</td></tr>`}</tbody>
            </table>
        </div>
    `;
}

// ─── LEAD ADD MODAL ───────────────────────────────────────────────────────────
function renderAddLeadModal() {
    const fields = [
        { key:'name',       label:{en:'Full Name',ar:'الاسم الكامل'} },
        { key:'company',    label:{en:'Company',ar:'الشركة'} },
        { key:'phone',      label:{en:'Phone',ar:'الهاتف'} },
        { key:'source',     label:{en:'Source',ar:'المصدر'} },
        { key:'value',      label:{en:'Deal Value (EGP)',ar:'قيمة الصفقة'} },
        { key:'score',      label:{en:'Lead Score (1-100)',ar:'نقاط العميل'} },
        { key:'assignedTo', label:{en:'Assigned To',ar:'المسؤول'} }
    ];
    return `
        <div class="fixed inset-0 z-[101] flex items-center justify-center p-6 modal-overlay fade-in">
            <div class="bg-white dark:bg-slate-900 w-full max-w-xl rounded-[2.5rem] p-10 border border-slate-200 dark:border-slate-800 shadow-2xl max-h-[85vh] overflow-y-auto custom-scrollbar">
                <div class="flex justify-between items-start mb-8">
                    <div>
                        <h2 class="text-2xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${_t('Add New Lead','إضافة عميل جديد')}</h2>
                        <p class="text-slate-500 text-xs mt-1 font-bold">${_t('Will be placed in New stage','سيُضاف في مرحلة الجديد')}</p>
                    </div>
                    <button onclick="state.isModalOpen=false; state.addLeadMode=false; render();" class="text-slate-400 hover:text-rose-500 p-2"><i data-lucide="x" size="24"></i></button>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                    ${fields.map(f=>`
                        <div class="flex flex-col gap-2">
                            <label class="text-[10px] font-black uppercase tracking-widest text-slate-400">${_t(f.label.en,f.label.ar)}</label>
                            <input id="lf-${f.key}" type="text" placeholder="${_t(f.label.en,f.label.ar)}" class="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl px-5 py-4 text-sm font-bold text-mantiq-navy dark:text-white outline-none focus:ring-2 focus:ring-mantiq-cyan" />
                        </div>
                    `).join('')}
                    <div class="md:col-span-2 flex gap-3 mt-4">
                        <button onclick="state.isModalOpen=false; state.addLeadMode=false; render();" class="flex-1 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 py-5 rounded-2xl font-black text-sm uppercase">${ut('cancel')}</button>
                        <button onclick="addLeadFromModal({name:document.getElementById('lf-name').value,company:document.getElementById('lf-company').value,phone:document.getElementById('lf-phone').value,source:document.getElementById('lf-source').value,value:document.getElementById('lf-value').value,score:document.getElementById('lf-score').value,assignedTo:document.getElementById('lf-assignedTo').value})" class="flex-1 bg-mantiq-navy dark:bg-white text-white dark:text-mantiq-navy py-5 rounded-2xl font-black text-sm uppercase shadow-xl">${_t('Add to Pipeline','إضافة للمسار')}</button>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// ─── CHART RENDERING ─────────────────────────────────────────────────────────
function renderCharts() {
    const config = SYSTEM_MAP[state.module];
    if (!config || !config.charts) return;
    const charts = config.charts;
    const isDark = state.darkMode;
    const gridColor = isDark ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.06)';
    const textColor = isDark ? '#94a3b8' : '#64748b';
    const mod = state.module;

    Chart.defaults.color = textColor;
    Chart.defaults.borderColor = gridColor;

    // Destroy existing charts
    Chart.helpers && Object.values(Chart.instances || {}).forEach(c => c.destroy && c.destroy());
    document.querySelectorAll('canvas[data-chart]').forEach(canvas => {
        const existing = Chart.getChart(canvas);
        if (existing) existing.destroy();
    });

    setTimeout(() => {
        if (mod === MODULES.CRM) {
            // Bar: Monthly Leads
            const c1 = document.getElementById('chart-monthly');
            if (c1) new Chart(c1, { type:'bar', data: {
                labels: charts.monthly.labels,
                datasets:[{ label:_t('Leads','العملاء'), data:charts.monthly.data, backgroundColor:'rgba(56,189,248,0.7)', borderRadius:8, borderSkipped:false }]
            }, options: { responsive:true, plugins:{legend:{display:false}}, scales:{ x:{grid:{display:false}}, y:{grid:{color:gridColor}} } }});

            // Doughnut: Lead Sources
            const c2 = document.getElementById('chart-sources');
            if (c2) new Chart(c2, { type:'doughnut', data: {
                labels: charts.sources.labels,
                datasets:[{ data:charts.sources.data, backgroundColor:['#38bdf8','#818cf8','#34d399','#fb923c','#f472b6'], borderWidth:0, hoverOffset:8 }]
            }, options:{ responsive:true, cutout:'65%', plugins:{legend:{position:'bottom',labels:{boxWidth:10,padding:16}}} }});

            // Bar: Pipeline Stages
            const c3 = document.getElementById('chart-pipeline');
            if (c3) new Chart(c3, { type:'bar', data: {
                labels: charts.pipeline.labels,
                datasets:[{ label:_t('Deals','صفقات'), data:charts.pipeline.data, backgroundColor:['#38bdf8','#818cf8','#fb923c','#34d399','#f87171'], borderRadius:8, borderSkipped:false }]
            }, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{ x:{grid:{display:false}}, y:{grid:{color:gridColor}} } }});
        }

        if (mod === MODULES.HR) {
            const c1 = document.getElementById('chart-headcount');
            if (c1) new Chart(c1, { type:'line', data:{
                labels:charts.headcount.labels,
                datasets:[{ label:_t('Headcount','عدد الموظفين'), data:charts.headcount.data, borderColor:'#a78bfa', backgroundColor:'rgba(167,139,250,0.1)', tension:0.4, fill:true, pointRadius:5, pointBackgroundColor:'#a78bfa' }]
            }, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{ x:{grid:{display:false}}, y:{grid:{color:gridColor}} } }});

            const c2 = document.getElementById('chart-departments');
            if (c2) new Chart(c2, { type:'bar', data:{
                labels:charts.departments.labels,
                datasets:[{ label:_t('Employees','موظفين'), data:charts.departments.data, backgroundColor:'rgba(167,139,250,0.7)', borderRadius:8, borderSkipped:false }]
            }, options:{ responsive:true, plugins:{legend:{display:false}}, indexAxis:'y', scales:{ x:{grid:{color:gridColor}}, y:{grid:{display:false}} } }});

            const c3 = document.getElementById('chart-attendance');
            if (c3) new Chart(c3, { type:'line', data:{
                labels:charts.attendance.labels,
                datasets:[{ label:_t('Attendance %','نسبة الحضور'), data:charts.attendance.data, borderColor:'#34d399', backgroundColor:'rgba(52,211,153,0.1)', tension:0.4, fill:true, pointRadius:5, pointBackgroundColor:'#34d399' }]
            }, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{ x:{grid:{display:false}}, y:{min:80, max:100, grid:{color:gridColor}} } }});
        }

        if (mod === MODULES.FINANCE) {
            const c1 = document.getElementById('chart-cashflow');
            if (c1) new Chart(c1, { type:'bar', data:{
                labels:charts.cashflow.labels,
                datasets:[
                    { label:_t('Inflow','وارد'), data:charts.cashflow.inflow, backgroundColor:'rgba(52,211,153,0.7)', borderRadius:8, borderSkipped:false },
                    { label:_t('Outflow','صادر'), data:charts.cashflow.outflow, backgroundColor:'rgba(251,146,60,0.7)', borderRadius:8, borderSkipped:false }
                ]
            }, options:{ responsive:true, plugins:{legend:{position:'bottom',labels:{boxWidth:10,padding:16}}}, scales:{ x:{grid:{display:false}}, y:{grid:{color:gridColor}} } }});

            const c2 = document.getElementById('chart-expenses-breakdown');
            if (c2) new Chart(c2, { type:'pie', data:{
                labels:charts.expenses.labels,
                datasets:[{ data:charts.expenses.data, backgroundColor:['#38bdf8','#818cf8','#34d399','#fb923c','#f472b6','#94a3b8'], borderWidth:0, hoverOffset:8 }]
            }, options:{ responsive:true, plugins:{legend:{position:'bottom',labels:{boxWidth:10,padding:12}}} }});

            const c3 = document.getElementById('chart-revenue');
            if (c3) new Chart(c3, { type:'line', data:{
                labels:charts.revenue.labels,
                datasets:[{ label:_t('Revenue K EGP','الإيراد ألف ج.م'), data:charts.revenue.data, borderColor:'#34d399', backgroundColor:'rgba(52,211,153,0.1)', tension:0.4, fill:true, pointRadius:5, pointBackgroundColor:'#34d399' }]
            }, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{ x:{grid:{display:false}}, y:{grid:{color:gridColor}} } }});
        }

        if (mod === MODULES.SALES) {
            const c1 = document.getElementById('chart-revenue');
            if (c1) new Chart(c1, { type:'line', data:{
                labels:charts.revenue.labels,
                datasets:[{ label:_t('Revenue K EGP','الإيراد ألف ج.م'), data:charts.revenue.data, borderColor:'#fb923c', backgroundColor:'rgba(251,146,60,0.1)', tension:0.4, fill:true, pointRadius:5, pointBackgroundColor:'#fb923c' }]
            }, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{ x:{grid:{display:false}}, y:{grid:{color:gridColor}} } }});

            const c2 = document.getElementById('chart-reps');
            if (c2) new Chart(c2, { type:'bar', data:{
                labels:charts.reps.labels,
                datasets:[{ label:_t('Revenue K EGP','الإيراد'), data:charts.reps.data, backgroundColor:'rgba(251,146,60,0.7)', borderRadius:8, borderSkipped:false }]
            }, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{ x:{grid:{display:false}}, y:{grid:{color:gridColor}} } }});

            const c3 = document.getElementById('chart-products');
            if (c3) new Chart(c3, { type:'doughnut', data:{
                labels:charts.products.labels,
                datasets:[{ data:charts.products.data, backgroundColor:['#fb923c','#38bdf8','#34d399','#818cf8','#f472b6'], borderWidth:0, hoverOffset:8 }]
            }, options:{ responsive:true, cutout:'60%', plugins:{legend:{position:'bottom',labels:{boxWidth:10,padding:14}}} }});
        }

        if (mod === MODULES.ACADEMY) {
            const c1 = document.getElementById('chart-enrollment');
            if (c1) new Chart(c1, { type:'line', data:{
                labels: charts.enrollment.labels,
                datasets:[{ label:_t('Students','الطلاب'), data:charts.enrollment.data, borderColor:'#a78bfa', backgroundColor:'rgba(167,139,250,0.12)', tension:0.4, fill:true, pointRadius:5, pointBackgroundColor:'#a78bfa' }]
            }, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{ x:{grid:{display:false}}, y:{grid:{color:gridColor}} } }});

            const c2 = document.getElementById('chart-edu-revenue');
            if (c2) new Chart(c2, { type:'bar', data:{
                labels: charts.revenue.labels,
                datasets:[{ label:_t('Revenue K EGP','الإيرادات ألف ج.م'), data:charts.revenue.data, backgroundColor:'rgba(167,139,250,0.7)', borderRadius:8, borderSkipped:false }]
            }, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{ x:{grid:{display:false}}, y:{grid:{color:gridColor}} } }});

            const c3 = document.getElementById('chart-grades');
            if (c3) new Chart(c3, { type:'bar', data:{
                labels: charts.grades.labels,
                datasets:[{ label:_t('Students','الطلاب'), data:charts.grades.data, backgroundColor:['#a78bfa','#818cf8','#38bdf8','#34d399','#fb923c','#f472b6'], borderRadius:8, borderSkipped:false }]
            }, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{ x:{grid:{display:false}}, y:{grid:{color:gridColor}} } }});

            const c4 = document.getElementById('chart-edu-attendance');
            if (c4) new Chart(c4, { type:'line', data:{
                labels: charts.attendance.labels,
                datasets:[{ label:_t('Attendance %','نسبة الحضور'), data:charts.attendance.data, borderColor:'#34d399', backgroundColor:'rgba(52,211,153,0.1)', tension:0.4, fill:true, pointRadius:5, pointBackgroundColor:'#34d399' }]
            }, options:{ responsive:true, plugins:{legend:{display:false}}, scales:{ x:{grid:{display:false}}, y:{min:80, max:100, grid:{color:gridColor}} } }});
        }
    }, 80);
}

// ─── LOGO ─────────────────────────────────────────────────────────────────────
function getLogo(cls='h-8') {
    return `<div class="flex items-center gap-1 ${cls}"><span class="text-[1.2em] font-black tracking-tight text-mantiq-navy dark:text-white uppercase">MANTIQ</span></div>`;
}

// ─── LANDING ──────────────────────────────────────────────────────────────────
function renderLanding() {
    const cards = Object.entries(SYSTEM_MAP).map(([id,cfg])=>`
        <button onclick="setModule('${id}')" class="group bg-white dark:bg-slate-900 p-8 md:p-12 rounded-[2.5rem] md:rounded-[3.5rem] border border-slate-200 dark:border-slate-800 shadow-sm card-glow transition-all text-${state.language==='ar'?'right':'left'} flex flex-col hover:-translate-y-2">
            <div class="p-4 md:p-6 rounded-2xl md:rounded-[2rem] inline-block mb-6 md:mb-10 shadow-xl group-hover:scale-110 transition-transform" style="background:${cfg.color}22; color:${cfg.color}">
                <i data-lucide="${cfg.icon}" class="w-6 h-6 md:w-9 md:h-9"></i>
            </div>
            <h3 class="text-2xl md:text-3xl font-extrabold text-mantiq-navy dark:text-white mb-2 md:mb-3 uppercase tracking-tighter leading-none">${_t(cfg.title.en,cfg.title.ar)}</h3>
            <p class="text-slate-500 dark:text-slate-400 text-xs md:text-sm mb-8 md:mb-12 flex-1 leading-relaxed">${_t(cfg.description.en,cfg.description.ar)}</p>
            <div class="flex items-center font-black text-[10px] md:text-xs uppercase tracking-widest" style="color:${cfg.color}">
                ${ut('launch')} <i data-lucide="arrow-right" class="mx-2 w-3 h-3 md:w-4 md:h-4 group-hover:translate-x-3 transition-transform ${state.language==='ar'?'rotate-180':''}"></i>
            </div>
        </button>
    `).join('');

    return `
        <div class="min-h-screen flex flex-col items-center justify-center py-20 px-6 md:p-8 fade-in bg-slate-50 dark:bg-slate-950 overflow-y-auto overflow-x-hidden">
            <div class="absolute top-6 right-6 md:top-10 md:right-10 flex gap-4 z-50">
                <button onclick="setLanguage('${state.language==='en'?'ar':'en'}')" class="px-5 py-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl font-black text-xs uppercase tracking-tighter text-mantiq-navy dark:text-white">
                    ${state.language==='en'?'Arabic':'English'}
                </button>
                <button onclick="toggleDarkMode()" class="p-3 md:p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-full shadow-xl hover:scale-110 transition-all">
                    <i data-lucide="${state.darkMode?'sun':'moon'}" class="w-6 h-6 ${state.darkMode?'text-amber-400':'text-mantiq-cyan'}"></i>
                </button>
            </div>
            <div class="text-center mb-12 md:mb-20 max-w-4xl pt-10">
                <div class="flex justify-center mb-6 md:mb-10 scale-125 md:scale-150">${getLogo("h-10 md:h-16 text-2xl md:text-5xl")}</div>
                <h1 class="text-4xl md:text-7xl font-black text-mantiq-navy dark:text-white mb-4 md:mb-6 tracking-tight leading-none uppercase">${ut('subtitle')}</h1>
                <p class="text-slate-500 dark:text-slate-400 text-sm md:text-xl font-medium px-4 md:px-12 leading-relaxed max-w-2xl mx-auto">${ut('description')}</p>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8 w-full max-w-7xl relative z-10 pb-12">${cards}</div>
        </div>
    `;
}

// ─── ANALYTICS PAGE ───────────────────────────────────────────────────────────
function renderAnalytics() {
    const config = SYSTEM_MAP[state.module];
    const kpis = state.language==='ar' ? config.kpis.ar : config.kpis.en;
    const mod = state.module;
    const color = config.color;

    const kpiCards = kpis.map(k => `
        <div class="stat-card bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
            <div class="flex items-start justify-between mb-4">
                <div class="p-3 rounded-2xl" style="background:${color}18; color:${color}">
                    <i data-lucide="${k.icon}" size="22"></i>
                </div>
                <span class="badge ${k.delta.startsWith('+')?'badge-green':'badge-red'}">${k.delta}</span>
            </div>
            <p class="text-3xl font-black text-mantiq-navy dark:text-white mb-1 count-up">${k.value}</p>
            <p class="text-slate-500 text-xs font-bold uppercase tracking-widest">${k.label}</p>
        </div>
    `).join('');

    // Performance bars
    const perfItems = {
        [MODULES.CRM]: [
            { label:_t('Lead Conversion Rate','معدل تحويل العملاء'), val:62, color:'#38bdf8' },
            { label:_t('Pipeline Coverage','تغطية المسار'), val:78, color:'#818cf8' },
            { label:_t('Activity Completion','إتمام الأنشطة'), val:85, color:'#34d399' },
            { label:_t('Customer Retention','الاحتفاظ بالعملاء'), val:91, color:'#fb923c' }
        ],
        [MODULES.HR]: [
            { label:_t('Attendance Rate','معدل الحضور'), val:94, color:'#a78bfa' },
            { label:_t('Training Completion','إتمام التدريب'), val:71, color:'#34d399' },
            { label:_t('Performance Review Coverage','تغطية تقييم الأداء'), val:88, color:'#38bdf8' },
            { label:_t('Retention Rate','معدل الاستبقاء'), val:96, color:'#fb923c' }
        ],
        [MODULES.FINANCE]: [
            { label:_t('Invoice Collection Rate','معدل تحصيل الفواتير'), val:87, color:'#34d399' },
            { label:_t('Budget Utilization','استخدام الميزانية'), val:73, color:'#38bdf8' },
            { label:_t('Tax Compliance','الامتثال الضريبي'), val:100, color:'#818cf8' },
            { label:_t('Gross Margin','هامش الربح الإجمالي'), val:47, color:'#fb923c' }
        ],
        [MODULES.SALES]: [
            { label:_t('Quota Attainment','تحقيق الحصة'), val:78, color:'#fb923c' },
            { label:_t('Win Rate','معدل الفوز'), val:62, color:'#34d399' },
            { label:_t('Lead Response Time','سرعة الاستجابة للعملاء'), val:88, color:'#38bdf8' },
            { label:_t('Customer Satisfaction','رضا العملاء'), val:92, color:'#818cf8' }
        ],
        [MODULES.ACADEMY]: [
            { label:_t('Attendance Rate','معدل الحضور'), val:91, color:'#a78bfa' },
            { label:_t('Fee Collection Rate','معدل تحصيل الرسوم'), val:84, color:'#34d399' },
            { label:_t('Teacher Retention','استبقاء المعلمين'), val:96, color:'#38bdf8' },
            { label:_t('Student Pass Rate','معدل نجاح الطلاب'), val:88, color:'#fb923c' }
        ]
    };

    const perf = (perfItems[mod]||[]).map(p=>`
        <div class="mb-5">
            <div class="flex justify-between mb-2">
                <span class="text-sm font-bold text-slate-700 dark:text-slate-200">${p.label}</span>
                <span class="text-sm font-black" style="color:${p.color}">${p.val}%</span>
            </div>
            <div class="kpi-bar"><div class="kpi-bar-fill" style="width:${p.val}%; background:linear-gradient(90deg, ${p.color}, ${p.color}aa)"></div></div>
        </div>
    `).join('');

    // Chart layout per module
    let chartGrid = '';
    if (mod === MODULES.CRM) chartGrid = `
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800">
                <h4 class="font-black text-sm uppercase tracking-widest text-slate-500 mb-6">${_t('Monthly Leads','العملاء الشهريين')}</h4>
                <div class="chart-container"><canvas id="chart-monthly" data-chart></canvas></div>
            </div>
            <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800">
                <h4 class="font-black text-sm uppercase tracking-widest text-slate-500 mb-6">${_t('Lead Sources','مصادر العملاء')}</h4>
                <div class="chart-container"><canvas id="chart-sources" data-chart></canvas></div>
            </div>
        </div>
        <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800 mb-6">
            <h4 class="font-black text-sm uppercase tracking-widest text-slate-500 mb-6">${_t('Pipeline Stage Distribution','توزيع مراحل المسار')}</h4>
            <div class="chart-container"><canvas id="chart-pipeline" data-chart></canvas></div>
        </div>
    `;

    if (mod === MODULES.HR) chartGrid = `
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800">
                <h4 class="font-black text-sm uppercase tracking-widest text-slate-500 mb-6">${_t('Headcount Growth','نمو عدد الموظفين')}</h4>
                <div class="chart-container"><canvas id="chart-headcount" data-chart></canvas></div>
            </div>
            <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800">
                <h4 class="font-black text-sm uppercase tracking-widest text-slate-500 mb-6">${_t('Weekly Attendance %','نسبة الحضور الأسبوعي')}</h4>
                <div class="chart-container"><canvas id="chart-attendance" data-chart></canvas></div>
            </div>
        </div>
        <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800 mb-6">
            <h4 class="font-black text-sm uppercase tracking-widest text-slate-500 mb-6">${_t('Employees by Department','الموظفين حسب القسم')}</h4>
            <div class="chart-container"><canvas id="chart-departments" data-chart></canvas></div>
        </div>
    `;

    if (mod === MODULES.FINANCE) chartGrid = `
        <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800 mb-6">
            <h4 class="font-black text-sm uppercase tracking-widest text-slate-500 mb-6">${_t('Cash Flow Analysis (K EGP)','تحليل التدفق النقدي (ألف ج.م)')}</h4>
            <div class="chart-container"><canvas id="chart-cashflow" data-chart></canvas></div>
        </div>
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800">
                <h4 class="font-black text-sm uppercase tracking-widest text-slate-500 mb-6">${_t('Expense Breakdown','توزيع المصاريف')}</h4>
                <div class="chart-container"><canvas id="chart-expenses-breakdown" data-chart></canvas></div>
            </div>
            <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800">
                <h4 class="font-black text-sm uppercase tracking-widest text-slate-500 mb-6">${_t('Revenue Trend (K EGP)','اتجاه الإيراد (ألف ج.م)')}</h4>
                <div class="chart-container"><canvas id="chart-revenue" data-chart></canvas></div>
            </div>
        </div>
    `;

    if (mod === MODULES.SALES) chartGrid = `
        <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800 mb-6">
            <h4 class="font-black text-sm uppercase tracking-widest text-slate-500 mb-6">${_t('Revenue Trend (K EGP)','اتجاه الإيراد (ألف ج.م)')}</h4>
            <div class="chart-container"><canvas id="chart-revenue" data-chart></canvas></div>
        </div>
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800">
                <h4 class="font-black text-sm uppercase tracking-widest text-slate-500 mb-6">${_t('Revenue by Sales Rep (K EGP)','الإيراد حسب المندوب')}</h4>
                <div class="chart-container"><canvas id="chart-reps" data-chart></canvas></div>
            </div>
            <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800">
                <h4 class="font-black text-sm uppercase tracking-widest text-slate-500 mb-6">${_t('Revenue by Product Mix','الإيراد حسب المنتج')}</h4>
                <div class="chart-container"><canvas id="chart-products" data-chart></canvas></div>
            </div>
        </div>
    `;

    if (mod === MODULES.ACADEMY) chartGrid = `
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800">
                <h4 class="font-black text-sm uppercase tracking-widest text-slate-500 mb-6">${_t('Student Enrollment Trend','اتجاه التسجيل')}</h4>
                <div class="chart-container"><canvas id="chart-enrollment" data-chart></canvas></div>
            </div>
            <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800">
                <h4 class="font-black text-sm uppercase tracking-widest text-slate-500 mb-6">${_t('Monthly Revenue (K EGP)','الإيرادات الشهرية (ألف ج.م)')}</h4>
                <div class="chart-container"><canvas id="chart-edu-revenue" data-chart></canvas></div>
            </div>
        </div>
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800">
                <h4 class="font-black text-sm uppercase tracking-widest text-slate-500 mb-6">${_t('Students by Grade','الطلاب حسب المستوى')}</h4>
                <div class="chart-container"><canvas id="chart-grades" data-chart></canvas></div>
            </div>
            <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800">
                <h4 class="font-black text-sm uppercase tracking-widest text-slate-500 mb-6">${_t('Weekly Attendance %','نسبة الحضور الأسبوعي')}</h4>
                <div class="chart-container"><canvas id="chart-edu-attendance" data-chart></canvas></div>
            </div>
        </div>
    `;

    return `
        <div class="mb-8">
            <h2 class="text-3xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter mb-2">${ut('analytics')}</h2>
            <p class="text-slate-500 text-sm font-medium">${_t('Live performance metrics & visual insights','مؤشرات الأداء الحية والرؤى البيانية')}</p>
        </div>
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-8">${kpiCards}</div>
        ${chartGrid}
        <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800">
            <h4 class="font-black text-sm uppercase tracking-widest text-slate-500 mb-8">${_t('Key Performance Indicators','مؤشرات الأداء الرئيسية')}</h4>
            ${perf}
        </div>
    `;
}

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
function renderDashboard() {
    if (state.module === MODULES.ACADEMY) return renderEduDashboard();
    const config = SYSTEM_MAP[state.module];
    const kpis = state.language==='ar' ? config.kpis.ar : config.kpis.en;
    const color = config.color;

    const kpiCards = kpis.map(k=>`
        <div class="stat-card bg-white dark:bg-slate-900 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm">
            <div class="flex items-center justify-between mb-4">
                <div class="p-3 rounded-2xl" style="background:${color}18; color:${color}"><i data-lucide="${k.icon}" size="20"></i></div>
                <span class="badge ${k.delta.includes('+')?'badge-green':'badge-red'}">${k.delta}</span>
            </div>
            <p class="text-3xl font-black text-mantiq-navy dark:text-white mb-1">${k.value}</p>
            <p class="text-slate-500 text-xs font-bold uppercase tracking-widest">${k.label}</p>
        </div>
    `).join('');

    const recentNav = config.nav.filter(n=>n.id!=='dashboard' && !n.isAnalytics).slice(0,4);
    const quickLinks = recentNav.map(n=>`
        <button onclick="setPage('${n.id}')" class="flex items-center gap-4 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-mantiq-cyan hover:bg-sky-50 dark:hover:bg-slate-800 transition-all text-${state.language==='ar'?'right':'left'} w-full">
            <div class="p-2.5 rounded-xl" style="background:${color}18; color:${color}"><i data-lucide="${n.icon}" size="18"></i></div>
            <div>
                <p class="font-black text-sm text-mantiq-navy dark:text-white">${_t(n.label.en,n.label.ar)}</p>
                <p class="text-xs text-slate-400">${_t('View records →','عرض السجلات ←')}</p>
            </div>
        </button>
    `).join('');

    return `
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-8">${kpiCards}</div>
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div class="lg:col-span-2 bg-white dark:bg-slate-900 rounded-[3rem] p-10 border border-slate-200 dark:border-slate-800 text-center shadow-sm flex flex-col items-center justify-center min-h-[300px]">
                <div class="w-20 h-20 rounded-[2rem] flex items-center justify-center mb-8 animate-pulse" style="background:${color}18; color:${color}">
                    <i data-lucide="${config.icon}" size="40"></i>
                </div>
                <h2 class="text-4xl font-black text-mantiq-navy dark:text-white mb-4 uppercase tracking-tighter">${ut('controlCenter')}</h2>
                <p class="text-slate-500 dark:text-slate-400 text-base max-w-md leading-relaxed">${_t(config.description.en, config.description.ar)}</p>
                <button onclick="setPage('analytics')" class="mt-8 px-8 py-4 rounded-2xl font-black text-sm text-white shadow-xl" style="background:${color}">
                    ${_t('View Analytics →','عرض التحليلات ←')}
                </button>
            </div>
            <div class="bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
                <h3 class="font-black text-xs uppercase tracking-[0.2em] text-slate-400 mb-6">${_t('Quick Access','وصول سريع')}</h3>
                <div class="space-y-3">${quickLinks}</div>
            </div>
        </div>
    `;
}

// ─── ACADEMY SYSTEM ───────────────────────────────────────────────────────────

function renderEduDashboard() {
    const color = '#a78bfa';
    const students = state.data[MODULES.ACADEMY].edu_students || [];
    const teachers = state.data[MODULES.ACADEMY].edu_teachers || [];
    const income   = state.data[MODULES.ACADEMY].edu_income   || [];
    const expenses = state.data[MODULES.ACADEMY].edu_expenses || [];
    const schedule = state.data[MODULES.ACADEMY].edu_schedule || [];
    const attendance = state.data[MODULES.ACADEMY].edu_attendance || [];

    const totalIncome  = income.reduce((s,i) => s + (parseFloat(i.Amount)||0), 0);
    const totalExpense = expenses.reduce((s,e) => s + (parseFloat(e.Amount)||0), 0);
    const netCash = totalIncome - totalExpense;

    const today = new Date().toLocaleDateString('en-US', { weekday:'long' });
    const todayLectures = schedule.filter(s => s.Day === today);

    const attToday = attendance.filter(a => a.Date === new Date().toISOString().split('T')[0]);
    const presentToday = attToday.filter(a => a.Status === 'Present').length;
    const absentToday  = attToday.filter(a => a.Status === 'Absent').length;

    const kpis = [
        { label:_t('Total Students','إجمالي الطلاب'),      value: students.length,              icon:'users',           color },
        { label:_t('Teachers','المعلمون'),                  value: teachers.length,              icon:'user-cog',        color:'#34d399' },
        { label:_t('Total Income','إجمالي الإيرادات'),     value: totalIncome.toLocaleString() + ' EGP', icon:'trending-up', color:'#38bdf8' },
        { label:_t('Net Cash','صافي الربح'),               value: netCash.toLocaleString() + (netCash>=0?' EGP':' EGP'), icon:'wallet', color: netCash>=0?'#34d399':'#f87171' }
    ];

    const kpiCards = kpis.map(k=>`
        <div class="stat-card bg-white dark:bg-slate-900 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm">
            <div class="flex items-center justify-between mb-4">
                <div class="p-3 rounded-2xl" style="background:${k.color}22; color:${k.color}"><i data-lucide="${k.icon}" size="20"></i></div>
            </div>
            <p class="text-3xl font-black text-mantiq-navy dark:text-white mb-1">${k.value}</p>
            <p class="text-slate-500 text-xs font-bold uppercase tracking-widest">${k.label}</p>
        </div>
    `).join('');

    const lectureCards = todayLectures.length
        ? todayLectures.map(l=>`
            <div class="bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                <div class="flex justify-between items-center mb-3">
                    <span class="text-[9px] font-black uppercase tracking-widest px-3 py-1 rounded-full" style="background:${color}22; color:${color}">${l.Grade}</span>
                    <span class="text-[9px] font-black text-slate-400 uppercase">${l.Room}</span>
                </div>
                <h4 class="text-base font-black text-mantiq-navy dark:text-white mb-1">${l['Subject']||l['Subject Name']||'—'}</h4>
                <p class="text-xs text-slate-500 mb-3">${l.Teacher}</p>
                <div class="flex items-center gap-2 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs font-black" style="color:${color}">
                    <i data-lucide="clock" size="13"></i>${l['Start Time']}
                </div>
            </div>
        `).join('')
        : `<div class="col-span-full py-16 text-center text-slate-300 dark:text-slate-700 font-black uppercase border-2 border-dashed border-slate-100 dark:border-slate-800 rounded-[2rem]">${_t('No lectures scheduled for today.','لا توجد محاضرات مجدولة لليوم.')}</div>`;

    const quickBtns = [
        { id:'edu_students',   icon:'users',            label:_t('Students','الطلاب') },
        { id:'edu_attendance', icon:'clipboard-check',  label:_t('Attendance','الحضور') },
        { id:'edu_income',     icon:'trending-up',      label:_t('Income','الإيرادات') },
        { id:'edu_cashflow',   icon:'arrow-left-right', label:_t('Cash Flow','التدفق المالي') }
    ].map(b=>`
        <button onclick="setPage('${b.id}')" class="flex items-center gap-3 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-mantiq-cyan hover:bg-sky-50 dark:hover:bg-slate-800 transition-all w-full text-${state.language==='ar'?'right':'left'}">
            <div class="p-2 rounded-xl" style="background:${color}22; color:${color}"><i data-lucide="${b.icon}" size="16"></i></div>
            <span class="font-black text-sm text-mantiq-navy dark:text-white">${b.label}</span>
        </button>
    `).join('');

    return `
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-8">${kpiCards}</div>
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            <div class="lg:col-span-2">
                <h3 class="font-black text-xs uppercase tracking-[0.2em] text-slate-400 mb-4 flex items-center gap-2">
                    <i data-lucide="calendar" size="14"></i> ${_t('Today\'s Schedule','جدول اليوم')} — ${today}
                </h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">${lectureCards}</div>
            </div>
            <div class="bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
                <h3 class="font-black text-xs uppercase tracking-[0.2em] text-slate-400 mb-6">${_t('Quick Access','وصول سريع')}</h3>
                <div class="space-y-3">${quickBtns}</div>
                <div class="mt-6 pt-6 border-t border-slate-100 dark:border-slate-800 grid grid-cols-2 gap-3">
                    <div class="text-center p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30">
                        <p class="text-2xl font-black text-emerald-600">${presentToday}</p>
                        <p class="text-[9px] font-black uppercase text-emerald-500">${_t('Present Today','حضروا اليوم')}</p>
                    </div>
                    <div class="text-center p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/30">
                        <p class="text-2xl font-black text-rose-500">${absentToday}</p>
                        <p class="text-[9px] font-black uppercase text-rose-400">${_t('Absent Today','غابوا اليوم')}</p>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function renderEduStudentProfile() {
    const stuId = state.edu.viewingStudentId;
    const students = state.data[MODULES.ACADEMY].edu_students || [];
    const s = students.find(x => x['Stu-ID'] === stuId);
    if (!s) return renderEduStudentsList();
    const color = '#a78bfa';
    const income = (state.data[MODULES.ACADEMY].edu_income || []).filter(i => i['Stu-ID'] === stuId);
    const att    = (state.data[MODULES.ACADEMY].edu_attendance || []).filter(a => a.TargetID === stuId);
    const present = att.filter(a => a.Status === 'Present').length;
    const absent  = att.filter(a => a.Status === 'Absent').length;
    const rate = att.length ? Math.round((present / att.length) * 100) : 0;

    const attRows = att.slice(0,8).map(a=>`
        <div class="flex justify-between items-center p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50">
            <div>
                <p class="text-xs font-black text-mantiq-navy dark:text-white">${a.Date}</p>
                <p class="text-[9px] text-slate-400 uppercase font-bold">${a.Lecture || 'General'}</p>
            </div>
            <span class="text-[9px] font-black uppercase px-3 py-1 rounded-full ${a.Status==='Present'?'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40':'bg-rose-50 text-rose-500 dark:bg-rose-950/40'}">${a.Status}</span>
        </div>
    `).join('') || `<p class="text-xs text-slate-400 italic">${_t('No attendance records','لا توجد سجلات حضور')}</p>`;

    const incRows = income.map(i=>`
        <div class="flex justify-between items-center p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50">
            <div>
                <p class="text-xs font-black text-mantiq-navy dark:text-white">${i.Category} — ${i.Subcategory}</p>
                <p class="text-[9px] text-slate-400">${i.Date}</p>
            </div>
            <span class="text-sm font-black text-emerald-600">${parseInt(i.Amount).toLocaleString()} EGP</span>
        </div>
    `).join('') || `<p class="text-xs text-slate-400 italic">${_t('No income entries','لا توجد إيرادات')}</p>`;

    return `
        <div class="fade-in">
            <button onclick="state.edu.viewingStudentId=null; render();" class="text-[10px] font-black uppercase text-slate-400 hover:text-mantiq-cyan flex items-center gap-2 mb-8 transition-colors">
                <i data-lucide="arrow-left" size="14"></i>${_t('Back to Students','العودة للطلاب')}
            </button>
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div class="bg-white dark:bg-slate-900 p-10 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col items-center text-center">
                    <div class="w-24 h-24 rounded-[2rem] flex items-center justify-center font-black text-3xl text-white mb-6 shadow-xl" style="background:${color}">
                        ${s['Student Name'].charAt(0).toUpperCase()}
                    </div>
                    <h2 class="text-xl font-black text-mantiq-navy dark:text-white mb-1">${s['Student Name']}</h2>
                    <p class="text-xs text-slate-500 mb-6">${s['Stu-ID']} · ${s.Grade}</p>
                    <div class="w-full space-y-3 pt-6 border-t border-slate-100 dark:border-slate-800 text-${state.language==='ar'?'right':'left'}">
                        ${Object.entries(s).map(([k,v]) => `
                            <div class="flex justify-between">
                                <span class="text-[9px] font-black text-slate-400 uppercase">${k}</span>
                                <span class="text-xs font-bold text-mantiq-navy dark:text-white">${v}</span>
                            </div>
                        `).join('')}
                    </div>
                    <div class="w-full mt-6 pt-6 border-t border-slate-100 dark:border-slate-800 grid grid-cols-3 gap-3">
                        <div class="text-center"><p class="text-xl font-black text-emerald-600">${present}</p><p class="text-[8px] uppercase font-black text-slate-400">${_t('Present','حاضر')}</p></div>
                        <div class="text-center"><p class="text-xl font-black text-rose-500">${absent}</p><p class="text-[8px] uppercase font-black text-slate-400">${_t('Absent','غائب')}</p></div>
                        <div class="text-center"><p class="text-xl font-black" style="color:${color}">${rate}%</p><p class="text-[8px] uppercase font-black text-slate-400">${_t('Rate','النسبة')}</p></div>
                    </div>
                </div>
                <div class="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                    <h3 class="font-black text-xs uppercase tracking-widest text-slate-400 mb-6 flex items-center gap-2"><i data-lucide="history" size="14"></i>${_t('Attendance History','سجل الحضور')}</h3>
                    <div class="space-y-2 max-h-[500px] overflow-y-auto custom-scrollbar">${attRows}</div>
                </div>
                <div class="bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                    <h3 class="font-black text-xs uppercase tracking-widest text-slate-400 mb-6 flex items-center gap-2"><i data-lucide="receipt" size="14"></i>${_t('Payment History','سجل الدفعات')}</h3>
                    <div class="space-y-2 max-h-[500px] overflow-y-auto custom-scrollbar">${incRows}</div>
                </div>
            </div>
        </div>
    `;
}

function renderEduStudentsList() {
    const color = '#a78bfa';
    let students = state.data[MODULES.ACADEMY].edu_students || [];
    const query = state.edu.searchQuery.toLowerCase();
    const gradeF = state.edu.gradeFilter;
    if (query) students = students.filter(s => Object.values(s).some(v => String(v).toLowerCase().includes(query)));
    if (gradeF !== 'All') students = students.filter(s => s.Grade === gradeF);
    const grades = Object.keys(state.edu.config.gradeFees);

    const rows = students.map((s,idx)=>`
        <tr class="group hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-all border-b border-slate-50 dark:border-slate-800 last:border-0">
            <td class="px-8 py-5 text-sm font-black text-mantiq-navy dark:text-white whitespace-nowrap">${s['Stu-ID']}</td>
            <td class="px-8 py-5">
                <div class="flex items-center gap-3">
                    <div class="w-9 h-9 rounded-xl flex items-center justify-center font-black text-xs text-white" style="background:${color}">${s['Student Name'].charAt(0)}</div>
                    <span class="text-sm font-bold text-slate-700 dark:text-slate-200">${s['Student Name']}</span>
                </div>
            </td>
            <td class="px-8 py-5 text-sm font-bold text-slate-500 whitespace-nowrap">${s.Age}</td>
            <td class="px-8 py-5 text-sm font-bold text-slate-500 whitespace-nowrap">${s.Phone}</td>
            <td class="px-8 py-5 whitespace-nowrap"><span class="px-3 py-1.5 rounded-xl text-[10px] font-black uppercase" style="background:${color}22; color:${color}">${s.Grade}</span></td>
            <td class="px-8 py-5 whitespace-nowrap">${badgeHtml(s.Status||'Active')}</td>
            <td class="px-8 py-5 whitespace-nowrap">
                <div class="flex ${state.language==='en'?'justify-end':'justify-start'} gap-2">
                    <button onclick="state.edu.viewingStudentId='${s['Stu-ID']}'; render();" class="p-2 rounded-xl hover:bg-purple-50 dark:hover:bg-slate-700 transition-colors" style="color:${color}"><i data-lucide="user" size="16"></i></button>
                    <button onclick="handleDelete(${idx})" class="p-2 rounded-xl hover:bg-red-50 dark:hover:bg-slate-700 text-slate-400 hover:text-rose-500 transition-colors"><i data-lucide="trash-2" size="16"></i></button>
                </div>
            </td>
        </tr>
    `).join('');

    return `
        <div class="flex flex-col md:flex-row justify-between md:items-center gap-4 mb-6">
            <div>
                <h2 class="text-xl md:text-3xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${_t('Students','الطلاب')}</h2>
                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">${students.length} ${_t('Records','سجل')}</p>
            </div>
            <div class="flex gap-3">
                <select onchange="state.edu.gradeFilter=this.value; render();" class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-4 py-3 rounded-2xl text-xs font-bold outline-none">
                    <option value="All">${_t('All Grades','كل المستويات')}</option>
                    ${grades.map(g=>`<option value="${g}" ${gradeF===g?'selected':''}>${g}</option>`).join('')}
                </select>
                <button onclick="state.isModalOpen=true; render();" class="bg-mantiq-navy dark:bg-white text-white dark:text-mantiq-navy px-8 py-3 rounded-2xl font-black text-xs shadow-xl flex items-center gap-2">
                    <i data-lucide="plus" size="14"></i>${_t('Add Student','إضافة طالب')}
                </button>
            </div>
        </div>
        <div class="bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-200 dark:border-slate-800 mb-6 p-4 flex gap-3">
            <div class="flex-1 relative">
                <i data-lucide="search" class="absolute ${state.language==='en'?'left-4':'right-4'} top-1/2 -translate-y-1/2 text-slate-400" size="16"></i>
                <input type="text" placeholder="${_t('Search students...','ابحث عن طالب...')}" oninput="state.edu.searchQuery=this.value; render();" value="${state.edu.searchQuery}"
                    class="w-full bg-slate-50 dark:bg-slate-800 ${state.language==='en'?'pl-12':'pr-12'} px-4 py-3 rounded-xl text-sm outline-none" />
            </div>
        </div>
        <div class="bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden overflow-x-auto custom-scrollbar">
            <table class="w-full text-left border-collapse">
                <thead class="bg-slate-50/70 dark:bg-slate-800/50 text-[10px] uppercase tracking-[0.2em] font-black text-slate-500">
                    <tr>
                        ${['Stu-ID','Student Name','Age','Phone','Grade','Status',''].map(c=>`<th class="px-8 py-5 whitespace-nowrap">${c}</th>`).join('')}
                    </tr>
                </thead>
                <tbody>${rows || `<tr><td colspan="7" class="py-20 text-center text-slate-400 italic">${_t('No students found','لا توجد سجلات')}</td></tr>`}</tbody>
            </table>
        </div>
    `;
}

function renderEduTeachers() {
    const color = '#a78bfa';
    const teachers = state.data[MODULES.ACADEMY].edu_teachers || [];
    const schedule = state.data[MODULES.ACADEMY].edu_schedule || [];
    const attendance = state.data[MODULES.ACADEMY].edu_attendance || [];

    if (state.edu.viewingTeacherId) {
        const t = teachers.find(x => x['Teacher ID'] === state.edu.viewingTeacherId);
        if (!t) { state.edu.viewingTeacherId = null; }
        else {
            const tSubs = schedule.filter(s => s.Teacher === t['Full Name']);
            const tAtt  = attendance.filter(a => a.TargetID === t['Full Name'] && a.Type === 'Teachers').slice(0,10);
            const subCards = tSubs.length ? tSubs.map(s=>`
                <div class="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border-l-4" style="border-color:${color}">
                    <p class="font-black text-sm text-mantiq-navy dark:text-white">${s.Subject||s['Subject Name']||'—'}</p>
                    <p class="text-[10px] font-bold text-slate-400 mt-1">${s.Day} · ${s['Start Time']} · ${s.Room}</p>
                    <span class="text-[9px] font-black uppercase px-2 py-0.5 rounded-full mt-2 inline-block" style="background:${color}22; color:${color}">${s.Grade}</span>
                </div>
            `).join('') : `<p class="text-xs text-slate-400 italic">${_t('No schedule assigned','لا يوجد جدول مُسند')}</p>`;
            const attRows = tAtt.length ? tAtt.map(a=>`
                <div class="flex justify-between items-center p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
                    <div><p class="text-xs font-black">${a.Date}</p><p class="text-[9px] text-slate-400">${a.Lecture||'—'}</p></div>
                    <span class="text-[9px] font-black uppercase ${a.Status==='Present'?'text-emerald-600':'text-rose-500'}">${a.Status}</span>
                </div>
            `).join('') : `<p class="text-xs text-slate-400 italic">${_t('No attendance records','لا توجد سجلات')}</p>`;
            return `
                <div class="fade-in">
                    <button onclick="state.edu.viewingTeacherId=null; render();" class="text-[10px] font-black uppercase text-slate-400 hover:text-mantiq-cyan flex items-center gap-2 mb-8 transition-colors">
                        <i data-lucide="arrow-left" size="14"></i>${_t('Back to Teachers','العودة للمعلمين')}
                    </button>
                    <div class="flex items-center gap-6 mb-10">
                        <div class="w-20 h-20 rounded-[1.5rem] flex items-center justify-center font-black text-3xl text-white shadow-xl" style="background:${color}">${t['Full Name'].charAt(0)}</div>
                        <div>
                            <h2 class="text-3xl font-black text-mantiq-navy dark:text-white">${t['Full Name']}</h2>
                            <p class="text-sm text-slate-500">${t['Teacher ID']} · ${t.Subject} · ${t.Grade}</p>
                        </div>
                    </div>
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <div class="bg-white dark:bg-slate-900 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                            <h3 class="font-black text-xs uppercase tracking-widest text-slate-400 mb-6 flex items-center gap-2"><i data-lucide="calendar" size="14"></i>${_t('Weekly Schedule','الجدول الأسبوعي')}</h3>
                            <div class="space-y-3">${subCards}</div>
                        </div>
                        <div class="bg-white dark:bg-slate-900 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                            <h3 class="font-black text-xs uppercase tracking-widest text-slate-400 mb-6 flex items-center gap-2"><i data-lucide="history" size="14"></i>${_t('Attendance History','سجل الحضور')}</h3>
                            <div class="space-y-2">${attRows}</div>
                        </div>
                    </div>
                </div>
            `;
        }
    }

    const cards = teachers.map(t=>`
        <button onclick="state.edu.viewingTeacherId='${t['Teacher ID']}'; render();" class="group bg-white dark:bg-slate-900 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all text-${state.language==='ar'?'right':'left'}">
            <div class="flex items-center gap-5 mb-6">
                <div class="w-14 h-14 rounded-2xl flex items-center justify-center font-black text-xl text-white group-hover:scale-110 transition-transform shadow-lg" style="background:${color}">${t['Full Name'].charAt(0)}</div>
                <div>
                    <h4 class="font-black text-base text-mantiq-navy dark:text-white">${t['Full Name']}</h4>
                    <p class="text-[10px] text-slate-400 font-bold">${t['Teacher ID']}</p>
                </div>
            </div>
            <div class="flex justify-between items-center text-xs pt-4 border-t border-slate-100 dark:border-slate-800">
                <span class="font-bold text-slate-500">${t.Subject}</span>
                <span class="font-black px-2 py-1 rounded-lg text-[9px] uppercase" style="background:${color}22; color:${color}">${t.Grade}</span>
            </div>
            <div class="flex items-center gap-2 mt-3 text-[9px] font-black uppercase tracking-widest" style="color:${color}">
                ${_t('View Profile','عرض الملف')} <i data-lucide="${state.language==='ar'?'arrow-left':'arrow-right'}" size="12" class="group-hover:translate-x-1 transition-transform"></i>
            </div>
        </button>
    `).join('');

    return `
        <div class="flex justify-between items-center mb-8">
            <h2 class="text-xl md:text-3xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${_t('Teachers','المعلمون')}</h2>
            <button onclick="state.isModalOpen=true; render();" class="bg-mantiq-navy dark:bg-white text-white dark:text-mantiq-navy px-8 py-3 rounded-2xl font-black text-xs shadow-xl flex items-center gap-2">
                <i data-lucide="plus" size="14"></i>${_t('Add Teacher','إضافة معلم')}
            </button>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">${cards}</div>
    `;
}

function renderEduAttendance() {
    const color = '#a78bfa';
    const attDate    = state.edu.attDate;
    const attType    = state.edu.attType;
    const attLecture = state.edu.attLecture;
    const schedule   = state.data[MODULES.ACADEMY].edu_schedule || [];
    const students   = state.data[MODULES.ACADEMY].edu_students || [];
    const teachers   = state.data[MODULES.ACADEMY].edu_teachers || [];
    const attendance = state.data[MODULES.ACADEMY].edu_attendance || [];
    const config     = state.edu.config;

    const dayName = new Date(attDate).toLocaleDateString('en-US', { weekday:'long' });
    const todaySubjects = schedule.filter(s => s.Day === dayName);

    let list = [];
    if (attType === 'Students') {
        const gradesToday = [...new Set(todaySubjects.map(s => s.Grade))];
        list = gradesToday.length ? students.filter(s => gradesToday.includes(s.Grade)) : students;
    } else {
        const teachersToday = [...new Set(todaySubjects.map(s => s.Teacher))];
        list = teachersToday.length ? teachers.filter(t => teachersToday.includes(t['Full Name'])) : teachers;
    }

    const existingRecords = attendance.filter(a => a.Date === attDate && a.Type === attType && a.Lecture === attLecture);

    const rows = list.map(item => {
        const id   = attType === 'Students' ? item['Stu-ID']    : item['Teacher ID'];
        const name = attType === 'Students' ? item['Student Name'] : item['Full Name'];
        const grade = attType === 'Students' ? item.Grade : item.Subject;
        const saved   = existingRecords.find(r => r.TargetID === id);
        const current = state.edu.tempAttendance[id];
        const status = current?.status || saved?.Status || null;
        const note   = current?.note   || saved?.Note   || '';

        return `
            <tr class="border-b border-slate-50 dark:border-slate-800 last:border-0">
                <td class="px-8 py-5">
                    <div class="flex items-center gap-3">
                        <div class="w-9 h-9 rounded-xl flex items-center justify-center font-black text-xs text-white" style="background:${color}">${name.charAt(0)}</div>
                        <div>
                            <p class="text-sm font-black text-mantiq-navy dark:text-white">${name}</p>
                            <p class="text-[9px] text-slate-400 font-bold">${id} · ${grade}</p>
                        </div>
                    </div>
                </td>
                <td class="px-8 py-5">
                    ${status ? `<span class="px-3 py-1 rounded-full text-[9px] font-black uppercase ${status==='Present'?'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40':'bg-rose-50 text-rose-500 dark:bg-rose-950/40'}">${status}</span>` : '<span class="text-slate-300 text-xs">—</span>'}
                </td>
                <td class="px-8 py-5">
                    ${status === 'Absent' ? `<input type="text" placeholder="${_t('Reason...','السبب...')}" oninput="if(!state.edu.tempAttendance['${id}'])state.edu.tempAttendance['${id}']={status:'Absent',note:''};state.edu.tempAttendance['${id}'].note=this.value;" value="${note}" class="bg-slate-50 dark:bg-slate-800 px-3 py-2 rounded-xl text-xs outline-none w-40" />` : '—'}
                </td>
                <td class="px-8 py-5">
                    <div class="flex gap-2 justify-end">
                        <button onclick="if(!state.edu.tempAttendance['${id}'])state.edu.tempAttendance['${id}']={};state.edu.tempAttendance['${id}'].status='Present';render();" class="px-4 py-2 rounded-xl text-[9px] font-black uppercase transition-all ${status==='Present'?'bg-emerald-500 text-white':'bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-emerald-100'}">
                            ${_t('Present','حاضر')}
                        </button>
                        <button onclick="if(!state.edu.tempAttendance['${id}'])state.edu.tempAttendance['${id}']={};state.edu.tempAttendance['${id}'].status='Absent';render();" class="px-4 py-2 rounded-xl text-[9px] font-black uppercase transition-all ${status==='Absent'?'bg-rose-500 text-white':'bg-slate-100 dark:bg-slate-800 text-slate-500 hover:bg-rose-100'}">
                            ${_t('Absent','غائب')}
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');

    const saveAtt = () => {
        const entries = Object.entries(state.edu.tempAttendance);
        entries.forEach(([id, data]) => {
            if (!data.status) return;
            const label = attType === 'Students'
                ? (students.find(s => s['Stu-ID'] === id)||{})['Student Name']
                : (teachers.find(t => t['Teacher ID'] === id)||{})['Full Name'];
            state.data[MODULES.ACADEMY].edu_attendance.push({
                Date: attDate, Type: attType, Lecture: attLecture,
                TargetID: id, Label: label||id, Status: data.status,
                Note: data.status==='Absent' ? data.note : '',
                Grade: attType==='Students' ? (students.find(s=>s['Stu-ID']===id)||{}).Grade : ''
            });
        });
        state.edu.tempAttendance = {};
        pushNotify(_t('Attendance saved successfully.','تم حفظ كشف الحضور بنجاح.'));
        render();
    };
    window.saveEduAttendance = saveAtt;

    return `
        <div class="fade-in space-y-6">
            <div class="flex flex-col lg:flex-row justify-between gap-6">
                <h2 class="text-xl md:text-3xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${_t('Attendance','الحضور والانصراف')}</h2>
                <div class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-[2rem] p-6 flex flex-wrap gap-4 items-end shadow-sm">
                    <div>
                        <label class="text-[9px] font-black uppercase text-slate-400 mb-1 block">${_t('Date','التاريخ')}</label>
                        <input type="date" value="${attDate}" onchange="state.edu.attDate=this.value; state.edu.tempAttendance={}; render();" class="bg-slate-50 dark:bg-slate-800 px-4 py-2 rounded-xl text-xs font-bold outline-none" />
                    </div>
                    <div>
                        <label class="text-[9px] font-black uppercase text-slate-400 mb-1 block">${_t('Category','الفئة')}</label>
                        <select onchange="state.edu.attType=this.value; state.edu.tempAttendance={}; render();" class="bg-slate-50 dark:bg-slate-800 px-4 py-2 rounded-xl text-xs font-bold outline-none">
                            <option value="Students" ${attType==='Students'?'selected':''}>${_t('Students','الطلاب')}</option>
                            <option value="Teachers" ${attType==='Teachers'?'selected':''}>${_t('Teachers','المعلمون')}</option>
                        </select>
                    </div>
                    <div>
                        <label class="text-[9px] font-black uppercase text-slate-400 mb-1 block">${_t('Lecture','المحاضرة')}</label>
                        <select onchange="state.edu.attLecture=this.value; state.edu.tempAttendance={}; render();" class="bg-slate-50 dark:bg-slate-800 px-4 py-2 rounded-xl text-xs font-bold outline-none">
                            <option value="General" ${attLecture==='General'?'selected':''}>General</option>
                            ${todaySubjects.map(s=>`<option value="${s.Subject||s['Subject Name']}" ${attLecture===(s.Subject||s['Subject Name'])?'selected':''}>${s.Subject||s['Subject Name']} (${s.Grade})</option>`).join('')}
                        </select>
                    </div>
                    <button onclick="saveEduAttendance();" class="px-8 py-3 rounded-2xl font-black text-xs uppercase text-white shadow-xl hover:scale-105 transition-transform" style="background:#a78bfa">
                        ${_t('Save Records','حفظ السجلات')}
                    </button>
                </div>
            </div>
            <div class="bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden overflow-x-auto custom-scrollbar">
                <table class="w-full text-left border-collapse">
                    <thead class="bg-slate-50/70 dark:bg-slate-800/50 text-[10px] uppercase tracking-widest font-black text-slate-500">
                        <tr>
                            <th class="px-8 py-5">${_t('Name','الاسم')}</th>
                            <th class="px-8 py-5">${_t('Status','الحالة')}</th>
                            <th class="px-8 py-5">${_t('Note','ملاحظة')}</th>
                            <th class="px-8 py-5 text-right">${_t('Action','الإجراء')}</th>
                        </tr>
                    </thead>
                    <tbody>${rows || `<tr><td colspan="4" class="py-16 text-center text-slate-300 font-black uppercase">${dayName}: ${_t('No lectures today','لا توجد محاضرات اليوم')}</td></tr>`}</tbody>
                </table>
            </div>
        </div>
    `;
}

function renderEduCashflow() {
    const color = '#a78bfa';
    const income   = state.data[MODULES.ACADEMY].edu_income   || [];
    const expenses = state.data[MODULES.ACADEMY].edu_expenses || [];
    const config   = state.edu.config;

    let all = [
        ...income.map(i   => ({ Type:'Inflow',  Label: i['Student Name'], Category: i.Category, Amount: parseFloat(i.Amount)||0, Date: i.Date })),
        ...expenses.map(e => ({ Type:'Outflow', Label: e['Title'],         Category: e.Category, Amount: parseFloat(e.Amount)||0, Date: e.Date }))
    ].sort((a,b) => new Date(b.Date) - new Date(a.Date));

    const totalInflow  = income.reduce((s,i)  => s + (parseFloat(i.Amount)||0), 0);
    const totalOutflow = expenses.reduce((s,e) => s + (parseFloat(e.Amount)||0), 0);
    const netCash = totalInflow - totalOutflow;

    const typeFilter = state.edu.cfTypeFilter;
    const catFilter  = state.edu.cfCatFilter;
    const query      = state.edu.searchQuery;

    if (typeFilter !== 'All') all = all.filter(x => x.Type === typeFilter);
    if (catFilter  !== 'All') all = all.filter(x => x.Category === catFilter);
    if (query) { const q = query.toLowerCase(); all = all.filter(x => x.Label.toLowerCase().includes(q) || (x.Category||'').toLowerCase().includes(q)); }

    const allCats = [...new Set([...config.incomeCategories.map(c=>c.name), ...config.expenseCategories.map(c=>c.name)])];

    const rows = all.map(t=>`
        <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/20 transition-all border-b border-slate-50 dark:border-slate-800 last:border-0">
            <td class="px-8 py-5"><span class="px-3 py-1.5 rounded-full text-[9px] font-black uppercase ${t.Type==='Inflow'?'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40':'bg-rose-50 text-rose-500 dark:bg-rose-950/40'}">${t.Type==='Inflow'?_t('Inflow','وارد'):_t('Outflow','صادر')}</span></td>
            <td class="px-8 py-5 text-sm font-bold text-slate-700 dark:text-slate-200">${t.Label}</td>
            <td class="px-8 py-5 text-xs text-slate-500">${t.Category||'—'}</td>
            <td class="px-8 py-5 font-black text-sm ${t.Type==='Inflow'?'text-emerald-600':'text-rose-500'}">${t.Amount.toLocaleString()} EGP</td>
            <td class="px-8 py-5 text-xs text-slate-400">${t.Date}</td>
        </tr>
    `).join('');

    return `
        <div class="fade-in space-y-6">
            <div class="flex justify-between items-center flex-wrap gap-4">
                <h2 class="text-xl md:text-3xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${_t('Cash Flow','التدفق المالي')}</h2>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-2">
                <div class="bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm text-center">
                    <p class="text-[10px] font-black uppercase text-emerald-500 mb-1">${_t('Total Inflow','إجمالي الوارد')}</p>
                    <p class="text-2xl font-black text-emerald-600">${totalInflow.toLocaleString()} EGP</p>
                </div>
                <div class="bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm text-center">
                    <p class="text-[10px] font-black uppercase text-rose-500 mb-1">${_t('Total Outflow','إجمالي الصادر')}</p>
                    <p class="text-2xl font-black text-rose-500">${totalOutflow.toLocaleString()} EGP</p>
                </div>
                <div class="p-6 rounded-[2rem] text-center" style="background:${color}22">
                    <p class="text-[10px] font-black uppercase mb-1" style="color:${color}">${_t('Net Cash','صافي الربح')}</p>
                    <p class="text-2xl font-black ${netCash>=0?'text-emerald-600':'text-rose-500'}">${netCash.toLocaleString()} EGP</p>
                </div>
            </div>
            <div class="bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-200 dark:border-slate-800 p-4 flex flex-col sm:flex-row gap-3 items-center">
                <div class="flex-1 relative w-full">
                    <i data-lucide="search" class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size="15"></i>
                    <input type="text" placeholder="${_t('Search...','بحث...')}" oninput="state.edu.searchQuery=this.value; render();" value="${query}"
                        class="w-full bg-slate-50 dark:bg-slate-800 pl-12 pr-4 py-3 rounded-xl text-sm outline-none" />
                </div>
                <select onchange="state.edu.cfTypeFilter=this.value; render();" class="bg-slate-50 dark:bg-slate-800 px-4 py-3 rounded-xl text-xs font-bold outline-none">
                    <option value="All" ${typeFilter==='All'?'selected':''}>${_t('All Types','كل الأنواع')}</option>
                    <option value="Inflow"  ${typeFilter==='Inflow' ?'selected':''}>${_t('Inflow','وارد')}</option>
                    <option value="Outflow" ${typeFilter==='Outflow'?'selected':''}>${_t('Outflow','صادر')}</option>
                </select>
                <select onchange="state.edu.cfCatFilter=this.value; render();" class="bg-slate-50 dark:bg-slate-800 px-4 py-3 rounded-xl text-xs font-bold outline-none">
                    <option value="All" ${catFilter==='All'?'selected':''}>${_t('All Categories','كل الفئات')}</option>
                    ${allCats.map(c=>`<option value="${c}" ${catFilter===c?'selected':''}>${c}</option>`).join('')}
                </select>
            </div>
            <div class="bg-white dark:bg-slate-900 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden overflow-x-auto custom-scrollbar">
                <table class="w-full text-left border-collapse">
                    <thead class="bg-slate-50/70 dark:bg-slate-800/50 text-[10px] uppercase tracking-widest font-black text-slate-500">
                        <tr>${['Type','Label','Category','Amount','Date'].map(c=>`<th class="px-8 py-5 whitespace-nowrap">${c}</th>`).join('')}</tr>
                    </thead>
                    <tbody>${rows || `<tr><td colspan="5" class="py-16 text-center text-slate-400 italic">${_t('No records','لا توجد سجلات')}</td></tr>`}</tbody>
                </table>
            </div>
        </div>
    `;
}

function renderEduConfig() {
    const color  = '#a78bfa';
    const config = state.edu.config;

    const teacherList = config.teachers.map((t,i)=>`
        <div class="flex justify-between items-center p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50">
            <div class="flex items-center gap-3">
                <div class="w-8 h-8 rounded-xl flex items-center justify-center font-black text-xs text-white" style="background:${color}">${t.charAt(0)}</div>
                <span class="text-sm font-bold text-slate-700 dark:text-slate-200">${t}</span>
            </div>
            <button onclick="config.teachers.splice(${i},1); render();" class="p-2 rounded-xl hover:bg-rose-50 text-slate-400 hover:text-rose-500 transition-colors"><i data-lucide="trash-2" size="15"></i></button>
        </div>
    `).join('');

    const gradeList = Object.entries(config.gradeFees).map(([g,f])=>`
        <div class="flex justify-between items-center p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50">
            <div>
                <p class="text-sm font-black text-mantiq-navy dark:text-white">${g}</p>
                <p class="text-[10px] font-bold mt-0.5" style="color:${color}">${parseInt(f).toLocaleString()} EGP / month</p>
            </div>
            <button onclick="delete config.gradeFees['${g}']; render();" class="p-2 rounded-xl hover:bg-rose-50 text-slate-400 hover:text-rose-500 transition-colors"><i data-lucide="trash-2" size="15"></i></button>
        </div>
    `).join('');

    const catPanel = (type, list) => `
        <div class="bg-white dark:bg-slate-900 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm">
            <h3 class="font-black text-sm uppercase tracking-widest text-slate-400 mb-6 flex items-center gap-2">
                <i data-lucide="layers" size="14"></i>${type === 'income' ? _t('Income Categories','فئات الإيرادات') : _t('Expense Categories','فئات المصاريف')}
            </h3>
            <div class="flex gap-2 mb-6">
                <input id="edu-cfg-${type}-cat" placeholder="${_t('Category name...','اسم الفئة...')}" class="flex-1 bg-slate-50 dark:bg-slate-800 px-4 py-3 rounded-xl text-xs font-bold outline-none" />
                <button onclick="const v=document.getElementById('edu-cfg-${type}-cat').value.trim(); if(v){state.edu.config.${type}Categories.push({name:v,subs:[]});document.getElementById('edu-cfg-${type}-cat').value='';render();}" class="p-3 rounded-xl text-white" style="background:${color}"><i data-lucide="plus" size="16"></i></button>
            </div>
            <div class="space-y-4">
                ${list.map((cat,ci)=>`
                    <div class="p-5 bg-slate-50 dark:bg-slate-800/30 rounded-2xl">
                        <div class="flex justify-between items-center mb-3">
                            <span class="text-xs font-black uppercase text-mantiq-navy dark:text-white">${cat.name}</span>
                            <button onclick="state.edu.config.${type}Categories.splice(${ci},1);render();" class="p-1 text-slate-400 hover:text-rose-500"><i data-lucide="trash-2" size="14"></i></button>
                        </div>
                        <div class="flex flex-wrap gap-2 mb-3">
                            ${cat.subs.map((s,si)=>`<span class="bg-white dark:bg-slate-700 px-3 py-1 rounded-lg text-[10px] font-bold flex items-center gap-2 shadow-sm">${s}<button onclick="state.edu.config.${type}Categories[${ci}].subs.splice(${si},1);render();" class="text-slate-400 hover:text-rose-500"><i data-lucide="x" size="10"></i></button></span>`).join('')}
                        </div>
                        <div class="flex gap-2">
                            <input id="edu-cfg-${type}-sub-${ci}" placeholder="${_t('Sub-category...','فئة فرعية...')}" class="flex-1 bg-white dark:bg-slate-900 px-3 py-2 rounded-xl text-[10px] outline-none border border-slate-100 dark:border-slate-700 font-bold" />
                            <button onclick="const v=document.getElementById('edu-cfg-${type}-sub-${ci}').value.trim(); if(v){state.edu.config.${type}Categories[${ci}].subs.push(v);document.getElementById('edu-cfg-${type}-sub-${ci}').value='';render();}" class="hover:scale-110 transition-transform" style="color:${color}"><i data-lucide="plus-circle" size="18"></i></button>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;

    return `
        <div class="fade-in space-y-8 pb-16">
            <h2 class="text-xl md:text-3xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${_t('Settings','الإعدادات')}</h2>
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div class="bg-white dark:bg-slate-900 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                    <h3 class="font-black text-sm uppercase tracking-widest text-slate-400 mb-6 flex items-center gap-2"><i data-lucide="user-plus" size="14"></i>${_t('Teachers','المعلمون')}</h3>
                    <div class="flex gap-2 mb-6">
                        <input id="edu-cfg-teacher" placeholder="${_t('Teacher full name...','اسم المعلم الكامل...')}" class="flex-1 bg-slate-50 dark:bg-slate-800 px-4 py-3 rounded-xl text-xs font-bold outline-none" />
                        <button onclick="const v=document.getElementById('edu-cfg-teacher').value.trim(); if(v){state.edu.config.teachers.push(v);document.getElementById('edu-cfg-teacher').value='';render();}" class="p-3 rounded-xl text-white" style="background:${color}"><i data-lucide="plus" size="16"></i></button>
                    </div>
                    <div class="space-y-2">${teacherList || `<p class="text-xs text-slate-400 italic">${_t('No teachers added','لم تُضف معلمون بعد')}</p>`}</div>
                </div>
                <div class="bg-white dark:bg-slate-900 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                    <h3 class="font-black text-sm uppercase tracking-widest text-slate-400 mb-6 flex items-center gap-2"><i data-lucide="graduation-cap" size="14"></i>${_t('Grades & Fees','المستويات والرسوم')}</h3>
                    <div class="space-y-2 mb-6">
                        <input id="edu-cfg-gname" placeholder="${_t('Grade name (e.g. Year 1)','اسم المستوى (مثال: المستوى الأول)')}" class="w-full bg-slate-50 dark:bg-slate-800 px-4 py-3 rounded-xl text-xs font-bold outline-none" />
                        <div class="flex gap-2">
                            <input id="edu-cfg-gfee" type="number" placeholder="${_t('Base monthly fee (EGP)','الرسوم الشهرية (ج.م)')}" class="flex-1 bg-slate-50 dark:bg-slate-800 px-4 py-3 rounded-xl text-xs font-bold outline-none" />
                            <button onclick="const n=document.getElementById('edu-cfg-gname').value.trim(),f=parseFloat(document.getElementById('edu-cfg-gfee').value);if(n&&!isNaN(f)){state.edu.config.gradeFees[n]=f;document.getElementById('edu-cfg-gname').value='';document.getElementById('edu-cfg-gfee').value='';render();}" class="px-5 py-3 rounded-xl font-black text-xs uppercase text-white" style="background:${color}">${_t('Add','إضافة')}</button>
                        </div>
                    </div>
                    <div class="space-y-2">${gradeList || `<p class="text-xs text-slate-400 italic">${_t('No grades defined','لم تُعرَّف مستويات بعد')}</p>`}</div>
                </div>
            </div>
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                ${catPanel('income', config.incomeCategories)}
                ${catPanel('expense', config.expenseCategories)}
            </div>
        </div>
    `;
}

// ─── TABLE VIEW ───────────────────────────────────────────────────────────────
function renderTable() {
    const currentNav = SYSTEM_MAP[state.module].nav.find(n=>n.id===state.page);
    const pageData = state.data[state.module][state.page] || [];
    const cols = _t(currentNav.tableCols.en, currentNav.tableCols.ar);
    const colsKeys = currentNav.tableCols.en;

    const rowsHtml = pageData.map((row,idx)=>`
        <tr class="group hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-all border-b border-slate-50 dark:border-slate-800 last:border-0">
            ${colsKeys.map(k=>`
                <td class="px-8 py-5 text-sm font-bold text-slate-700 dark:text-slate-200 whitespace-nowrap">
                    ${isStatusCol(k) ? badgeHtml(row[k]||'-') : (row[k]||'-')}
                </td>
            `).join('')}
            <td class="px-8 py-5 whitespace-nowrap">
                <div class="flex ${state.language==='en'?'justify-end':'justify-start'} gap-2">
                    <button onclick="pushNotify('${_t('View Only Mode','وضع العرض فقط')}')" class="p-2 rounded-xl hover:bg-sky-50 dark:hover:bg-slate-700 text-mantiq-cyan transition-colors"><i data-lucide="eye" size="16"></i></button>
                    <button onclick="handleDelete(${idx})" class="p-2 rounded-xl hover:bg-red-50 dark:hover:bg-slate-700 text-slate-400 hover:text-rose-500 transition-colors"><i data-lucide="trash-2" size="16"></i></button>
                </div>
            </td>
        </tr>
    `).join('');

    return `
        <div class="flex flex-col md:flex-row justify-between md:items-center gap-4 mb-8">
            <h2 class="text-xl md:text-3xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${_t(currentNav.label.en,currentNav.label.ar)}</h2>
            <div class="flex gap-3">
                <button onclick="pushNotify('${ut('export')}...')" class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-6 py-4 rounded-2xl font-black text-sm text-slate-600 dark:text-slate-300 shadow-sm flex items-center gap-2">
                    <i data-lucide="download" size="15"></i>${ut('export')}
                </button>
                <button onclick="state.isModalOpen=true; render();" class="bg-mantiq-navy dark:bg-white text-white dark:text-mantiq-navy px-8 py-4 rounded-2xl font-black text-sm shadow-xl flex items-center gap-2">
                    <i data-lucide="plus" size="15"></i>${ut('addRecord')}
                </button>
            </div>
        </div>
        <div class="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden overflow-x-auto custom-scrollbar">
            <table class="w-full text-left border-collapse" dir="${state.language==='ar'?'rtl':'ltr'}">
                <thead class="bg-slate-50/70 dark:bg-slate-800/50 text-[10px] uppercase tracking-[0.2em] font-black text-slate-500">
                    <tr>
                        ${cols.map(c=>`<th class="px-8 py-6 whitespace-nowrap">${c}</th>`).join('')}
                        <th class="px-8 py-6 ${state.language==='en'?'text-right':'text-left'}">${ut('action')}</th>
                    </tr>
                </thead>
                <tbody>${rowsHtml||`<tr><td colspan="20" class="p-20 text-center italic text-slate-400">${_t('No records found','لا توجد سجلات')}</td></tr>`}</tbody>
            </table>
        </div>
    `;
}

// ─── MODAL ────────────────────────────────────────────────────────────────────
function renderModal() {
    const currentNav = SYSTEM_MAP[state.module].nav.find(n=>n.id===state.page);
    const colsEn = currentNav.tableCols.en;
    const colsAr = currentNav.tableCols.ar;
    const inputs = colsEn.map((col,idx)=>`
        <div class="flex flex-col gap-2">
            <label class="text-[10px] font-black uppercase tracking-widest text-slate-400">${_t(col,colsAr[idx])}</label>
            <input type="text" name="${col}" placeholder="${_t('Enter ','أدخل ')+_t(col,colsAr[idx])}" class="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl px-5 py-4 text-sm font-bold text-mantiq-navy dark:text-white outline-none focus:ring-2 focus:ring-mantiq-cyan focus:border-transparent" />
        </div>
    `).join('');
    return `
        <div class="fixed inset-0 z-[101] flex items-center justify-center p-6 modal-overlay fade-in">
            <div class="bg-white dark:bg-slate-900 w-full max-w-xl rounded-[2.5rem] p-10 border border-slate-200 dark:border-slate-800 shadow-2xl max-h-[85vh] overflow-y-auto custom-scrollbar">
                <div class="flex justify-between items-start mb-8">
                    <div>
                        <h2 class="text-2xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${ut('addRecord')}</h2>
                        <p class="text-slate-500 text-xs mt-1 uppercase font-bold tracking-widest">${_t(currentNav.label.en,currentNav.label.ar)}</p>
                    </div>
                    <button onclick="state.isModalOpen=false; render();" class="text-slate-400 hover:text-rose-500 transition-colors p-2"><i data-lucide="x" size="24"></i></button>
                </div>
                <form id="add-record-form" onsubmit="handleAddData(event)" class="grid grid-cols-1 md:grid-cols-2 gap-5">
                    ${inputs}
                    <div class="md:col-span-2 flex gap-3 mt-4">
                        <button type="button" onclick="state.isModalOpen=false; render();" class="flex-1 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 py-5 rounded-2xl font-black text-sm uppercase">${ut('cancel')}</button>
                        <button type="submit" class="flex-1 bg-mantiq-navy dark:bg-white text-white dark:text-mantiq-navy py-5 rounded-2xl font-black text-sm uppercase shadow-xl">${ut('submit')}</button>
                    </div>
                </form>
            </div>
        </div>
    `;
}

// ─── MOBILE NAV ───────────────────────────────────────────────────────────────
function renderMobileNav() {
    const config = SYSTEM_MAP[state.module];
    return `
        <div class="fixed inset-0 z-[100] lg:hidden">
            <div class="absolute inset-0 bg-mantiq-navy/60 backdrop-blur-sm" onclick="state.isMobileMenuOpen=false; render();"></div>
            <div class="absolute ${state.language==='en'?'left-0':'right-0'} top-0 h-full w-4/5 max-w-xs bg-white dark:bg-slate-900 shadow-2xl flex flex-col fade-in">
                <div class="p-8 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
                    ${getLogo("h-6 text-lg")}
                    <button onclick="state.isMobileMenuOpen=false; render();" class="p-2 text-slate-400"><i data-lucide="x" size="24"></i></button>
                </div>
                <nav class="flex-1 p-6 space-y-1 overflow-y-auto custom-scrollbar">
                    ${config.nav.map(item=>`
                        <button onclick="setPage('${item.id}')" class="w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-sm font-bold transition-all ${state.page===item.id?'bg-mantiq-cyan text-white shadow-md':'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800'}">
                            <i data-lucide="${item.icon}" size="18"></i><span>${_t(item.label.en,item.label.ar)}</span>
                        </button>
                    `).join('')}
                </nav>
                <div class="p-8 border-t border-slate-100 dark:border-slate-800">
                    <button onclick="setModule(MODULES.LANDING)" class="w-full py-4 rounded-2xl bg-slate-100 dark:bg-slate-800 font-black text-xs uppercase text-rose-500">
                        ${_t('Exit System','خروج من النظام')}
                    </button>
                </div>
            </div>
        </div>
    `;
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
function renderApp() {
    const config = SYSTEM_MAP[state.module];
    const currentNavItem = config.nav.find(n=>n.id===state.page);
    const navHtml = config.nav.map(item=>`
        <button onclick="setPage('${item.id}')" class="w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-sm font-bold transition-all ${state.page===item.id ? 'bg-mantiq-cyan text-white shadow-lg shadow-sky-500/30 '+(state.language==='en'?'translate-x-1':'-translate-x-1') : 'text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'}">
            <i data-lucide="${item.icon}" size="18"></i>
            <span class="whitespace-nowrap overflow-hidden text-ellipsis">${_t(item.label.en,item.label.ar)}</span>
            ${item.isAnalytics ? `<span class="ml-auto badge badge-blue">${_t('New','جديد')}</span>` : ''}
        </button>
    `).join('');

    return `
        <div class="flex bg-slate-50 dark:bg-slate-950 h-screen overflow-hidden">
            <aside class="hidden lg:flex w-80 h-screen fixed ${state.language==='en'?'left-0 border-r':'right-0 border-l'} top-0 border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 z-30 flex-col">
                <div class="p-10 border-b border-slate-200 dark:border-slate-800">
                    <button onclick="setModule(MODULES.LANDING)">${getLogo("h-8 text-xl")}</button>
                </div>
                <nav class="flex-1 p-6 space-y-1 overflow-y-auto custom-scrollbar">
                    <p class="px-6 py-4 text-[10px] font-black uppercase tracking-[0.3em] text-slate-400 opacity-60">${_t(config.title.en,config.title.ar)}</p>
                    ${navHtml}
                </nav>
                <div class="p-8 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/50">
                    <div class="flex items-center gap-4">
                        <div class="w-12 h-12 rounded-2xl bg-mantiq-navy text-white flex items-center justify-center font-black shadow-lg text-sm">AS</div>
                        <div class="flex-1 min-w-0">
                            <p class="text-sm font-black text-mantiq-navy dark:text-white truncate uppercase">${_t('Ahmed Sharaf','أحمد شرف')}</p>
                            <p class="text-[10px] text-slate-500 font-bold uppercase tracking-wider">${ut('role')}</p>
                        </div>
                        <button onclick="toggleDarkMode()" class="p-2.5 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                            <i data-lucide="${state.darkMode?'sun':'moon'}" size="16"></i>
                        </button>
                    </div>
                </div>
            </aside>

            <div class="flex-1 ${state.language==='en'?'lg:pl-80':'lg:pr-80'} h-screen overflow-y-auto custom-scrollbar">
                <header class="h-28 bg-white/80 dark:bg-slate-950/80 backdrop-blur-3xl border-b border-slate-200 dark:border-slate-800 items-center justify-between px-14 sticky top-0 z-20 hidden lg:flex">
                    <div>
                        <div class="flex items-center gap-3 text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1">
                            <span>${ut('demoEnv')}</span>
                            <i data-lucide="chevron-right" size="12" class="${state.language==='ar'?'rotate-180':''}"></i>
                            <span class="font-bold" style="color:${config.color}">${_t(config.title.en,config.title.ar)}</span>
                        </div>
                        <h1 class="text-3xl font-black text-mantiq-navy dark:text-white capitalize tracking-tighter">${_t(currentNavItem.label.en, currentNavItem.label.ar)}</h1>
                    </div>
                    <div class="flex items-center gap-4">
                        <button onclick="setLanguage('${state.language==='en'?'ar':'en'}')" class="font-black text-xs uppercase px-4 py-2 border border-slate-200 dark:border-slate-800 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                            ${state.language==='en'?'Arabic':'English'}
                        </button>
                        <button onclick="state.showTourInvite=true; render();" class="flex items-center gap-1.5 font-black text-xs uppercase px-4 py-2 rounded-xl transition-colors text-white" style="background:${config.color}44; color:${config.color}; border: 1.5px solid ${config.color}55;">
                            <i data-lucide="map" size="14"></i>${_t('Tour','جولة')}
                        </button>
                        <button class="relative p-3 text-slate-400 hover:text-mantiq-cyan" onclick="pushNotify('${_t('No new notifications','لا توجد إشعارات جديدة')}')">
                            <i data-lucide="bell" size="22"></i>
                            <span class="absolute top-3 right-3 w-2.5 h-2.5 bg-rose-500 rounded-full border-2 border-white dark:border-slate-950"></span>
                        </button>
                        <button onclick="setModule(MODULES.LANDING)" class="p-3 text-slate-400 hover:text-rose-500 transition-colors"><i data-lucide="log-out" size="22"></i></button>
                    </div>
                </header>

                <!-- Mobile Header -->
                <div class="lg:hidden bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 sticky top-0 z-30">
                    <div class="flex items-center justify-between px-5 py-4">
                        <button onclick="setModule(MODULES.LANDING)">${getLogo("h-6 text-base")}</button>
                        <div class="flex items-center gap-2">
                            <button onclick="setLanguage('${state.language==='en'?'ar':'en'}')" class="p-2 text-slate-400 hover:text-mantiq-cyan"><i data-lucide="languages" size="18"></i></button>
                            <button onclick="toggleDarkMode()" class="p-2 text-slate-400 hover:text-mantiq-cyan"><i data-lucide="${state.darkMode?'sun':'moon'}" size="18"></i></button>
                            <button onclick="state.showTourInvite=true; render();" class="p-2 rounded-lg text-white" style="background:${config.color}88"><i data-lucide="map" size="16"></i></button>
                            <button onclick="toggleMobileMenu()" class="p-2 bg-mantiq-cyan text-white rounded-lg shadow-lg"><i data-lucide="menu" size="18"></i></button>
                        </div>
                    </div>
                    <div class="px-5 pb-3">
                        <p class="text-[9px] font-black uppercase tracking-widest text-slate-400" style="color:${config.color}">${_t(config.title.en,config.title.ar)}</p>
                        <h1 class="text-lg font-black text-mantiq-navy dark:text-white tracking-tight">${_t(currentNavItem.label.en, currentNavItem.label.ar)}</h1>
                    </div>
                </div>

                <main class="p-4 md:p-8 lg:p-14 max-w-[1600px] mx-auto fade-in">
                    ${renderWorkspace()}
                </main>
            </div>
        </div>
        ${state.isMobileMenuOpen ? renderMobileNav() : ''}
        ${state.isModalOpen ? (state.module === 'hr' ? renderHRModal() : state.addLeadMode ? renderAddLeadModal() : renderModal()) : ''}
        ${state.openLeadId ? renderLeadDrawer() : ''}
        ${state.module === 'hr' && state.openEmployeeId ? renderEmployeeDrawer() : ''}
    `;
}

function renderWorkspace() {
    // HR System pages
    if (state.module === MODULES.HR) {
        if (state.page === 'dashboard')   return renderHRDashboard();
        if (state.page === 'analytics')   return renderHRAnalytics();
        if (state.page === 'directory')   return renderDirectory();
        if (state.page === 'attendance')  return renderAttendance();
        if (state.page === 'leaves')      return renderLeaves();
        if (state.page === 'payroll')     return renderPayroll();
        if (state.page === 'contracts')   return renderContracts();
        if (state.page === 'recruitment') return renderRecruitment();
        if (state.page === 'performance') return renderPerformance();
        if (state.page === 'training')    return renderTraining();
        if (state.page === 'reports')     return renderReports();
        if (state.page === 'settings')    return renderSettings();
        return renderDashboard();
    }
    if (state.page === 'dashboard') return renderDashboard();
    if (state.page === 'analytics') return renderAnalytics();
    // Lead pipeline for CRM and Sales
    if (state.page === 'leads' && (state.module === MODULES.CRM || state.module === MODULES.SALES)) {
        return state.leadsView === 'table' ? renderLeadsTable() : renderLeadsPipeline();
    }
    // Academy special pages
    if (state.module === MODULES.ACADEMY) {
        if (state.page === 'edu_students')   return state.edu.viewingStudentId ? renderEduStudentProfile() : renderEduStudentsList();
        if (state.page === 'edu_teachers')   return renderEduTeachers();
        if (state.page === 'edu_attendance') return renderEduAttendance();
        if (state.page === 'edu_cashflow')   return renderEduCashflow();
        if (state.page === 'edu_config')     return renderEduConfig();
    }
    return renderTable();
}

// ─── TOUR SYSTEM ──────────────────────────────────────────────────────────────
const TOUR_STEPS = {
    [MODULES.CRM]: [
        { page:'dashboard',     selector:null, title:{en:'Welcome to CRM Tracker',ar:'مرحبًا في متتبع العملاء'}, body:{en:'Your command center. See live KPIs — total leads, active deals, win rate, and pipeline value — all updating in real-time.',ar:'مركز القيادة. شاهد مؤشرات الأداء الحية — إجمالي العملاء والصفقات النشطة ومعدل الفوز وقيمة المسار — تتحدث فورًا.'} },
        { page:'leads',         selector:'.pipeline-board', title:{en:'Lead Pipeline (Kanban)',ar:'مسار العملاء (كانبان)'}, body:{en:'Every lead lives in a stage column. Click a stage button on a card to advance or return it. Click the card itself to open full details.',ar:'كل عميل يعيش في عمود مرحلته. انقر زر المرحلة على البطاقة للتقدم أو الرجوع. انقر البطاقة لفتح التفاصيل الكاملة.'} },
        { page:'deals',         selector:'table', title:{en:'Deals Table',ar:'جدول الصفقات'}, body:{en:'Each row is an open deal with its account, value, stage, probability, and expected close date. Click Add Record to log a new opportunity.',ar:'كل صف صفقة مفتوحة بحسابها وقيمتها ومرحلتها واحتمالية الإغلاق. انقر إضافة سجل لتسجيل فرصة جديدة.'} },
        { page:'activities',    selector:'table', title:{en:'Activity Log',ar:'سجل الأنشطة'}, body:{en:'Log every touchpoint — calls, emails, demos, and follow-ups. Set priority and due date so the team stays on track.',ar:'سجّل كل نقطة تواصل — مكالمات وبريد وعروض ومتابعات. حدد الأولوية والموعد حتى يبقى الفريق على المسار.'} },
        { page:'analytics',     selector:null, title:{en:'Analytics & Charts',ar:'التحليلات والرسوم البيانية'}, body:{en:'Monthly lead trends, lead source breakdown, and pipeline stage distribution — all visual. KPI progress bars show health at a glance.',ar:'اتجاهات العملاء الشهرية ومصادرهم وتوزيع مراحل المسار — كلها مرئية. أشرطة KPI تظهر الصحة بنظرة واحدة.'} }
    ],
    [MODULES.HR]: [
        { page:'dashboard',     selector:null,    title:{en:'Welcome to HR System',ar:'مرحبًا في نظام الموارد البشرية'}, body:{en:'Your command center: live headcount, employees on leave today, monthly payroll total, and average performance score — plus action alerts for expiring contracts and pending approvals.',ar:'مركزك: إجمالي الموظفين والغائبين اليوم وإجمالي الرواتب ومتوسط الأداء — مع تنبيهات العقود المنتهية والطلبات المعلقة.'} },
        { page:'directory',     selector:'table', title:{en:'Employee Directory',ar:'دليل الموظفين'}, body:{en:'25 real employee profiles with salary, contract, leave balances, and performance data. Click any row to open a full side-panel with 4 tabs: Profile, Salary, Leaves, and Attendance.',ar:'25 ملف موظف حقيقي بالراتب والعقد ورصيد الإجازات والأداء. انقر أي صف لفتح لوحة جانبية بـ4 تبويبات: الملف، الراتب، الإجازات، الحضور.'} },
        { page:'attendance',    selector:'table', title:{en:'Attendance Tracking',ar:'تتبع الحضور'}, body:{en:'Daily punch-in/out log with auto-calculated overtime. Late arrivals are flagged amber, overtime in blue. Switch to Summary for daily stats or Overtime tab to bulk-approve hours.',ar:'سجل الحضور اليومي مع حساب تلقائي للعمل الإضافي. التأخر بالأصفر والإضافي بالأزرق. بدّل إلى الملخص أو تبويب الإضافي لاعتماد الساعات.'} },
        { page:'leaves',        selector:null,    title:{en:'Leave Management',ar:'إدارة الإجازات'}, body:{en:'Approve or reject leave requests with one click. The Balances tab shows each employee\'s remaining Annual, Sick, and Emergency days with a visual progress bar.',ar:'اعتمد أو ارفض طلبات الإجازة بنقرة واحدة. تبويب الأرصدة يظهر الأيام المتبقية لكل موظف بشريط مرئي.'} },
        { page:'payroll',       selector:'table', title:{en:'Payroll Processing',ar:'معالجة الرواتب'}, body:{en:'Full payroll breakdown per employee: base salary, allowances, social insurance (11%), income tax (tiered), and net pay. Click Process to mark as paid, or generate a PDF payslip instantly.',ar:'تفصيل كامل للراتب: الأساسي والبدلات والتأمين الاجتماعي 11% وضريبة الدخل والصافي. انقر معالجة للتأشير كمدفوع أو أنشئ قسيمة PDF فورًا.'} },
        { page:'contracts',     selector:'table', title:{en:'Contract Management',ar:'إدارة العقود'}, body:{en:'Track all employment contracts with expiry alerts. Contracts expiring within 30 days are highlighted in amber — click Renew directly from the alert banner.',ar:'تتبع جميع عقود العمل مع تنبيهات الانتهاء. العقود التي تنتهي خلال 30 يومًا مُعلَّمة بالأصفر — انقر تجديد مباشرة من شريط التنبيه.'} },
        { page:'recruitment',   selector:'.kanban-board', title:{en:'Recruitment Kanban',ar:'كانبان التوظيف'}, body:{en:'Applicants flow through 6 stages: Applied → Screening → Interview → Offer Sent → Hired / Rejected. Advance or reject candidates directly from their card.',ar:'المتقدمون يتدفقون عبر 6 مراحل: تقدّم → فرز → مقابلة → عرض → توظيف / رفض. قدّم أو ارفض المرشحين مباشرة من بطاقتهم.'} },
        { page:'performance',   selector:null,    title:{en:'Performance Reviews',ar:'تقييمات الأداء'}, body:{en:'Each review card shows 5-axis scoring: KPI, Attitude, Teamwork, Communication, and Initiative. Overall score is color-coded — green is excellent, red needs improvement.',ar:'كل بطاقة تقييم تظهر 5 محاور: مؤشرات الأداء والسلوك والعمل الجماعي والتواصل والمبادرة. النتيجة الإجمالية ملوّنة — أخضر ممتاز، أحمر يحتاج تحسينًا.'} },
        { page:'training',      selector:null,    title:{en:'Training & Development',ar:'التدريب والتطوير'}, body:{en:'Course catalog with completion rates, costs, and certifications. Each card shows enrollment count and a visual progress bar. Add new courses or enroll employees directly.',ar:'كتالوج الدورات بمعدلات الإتمام والتكاليف والشهادات. كل بطاقة تظهر عدد المسجلين وشريط تقدم مرئي. أضف دورات أو سجّل موظفين مباشرة.'} },
        { page:'analytics',     selector:null,    title:{en:'HR Analytics',ar:'تحليلات الموارد البشرية'}, body:{en:'6 live charts: headcount trend, employees by department, weekly attendance %, leave type distribution, monthly payroll cost, and performance score distribution — plus 6 KPI progress bars.',ar:'6 رسوم بيانية حية: اتجاه القوى العاملة وتوزيع الأقسام ونسبة الحضور وأنواع الإجازات وتكلفة الرواتب وتوزيع نقاط الأداء — بالإضافة إلى 6 أشرطة KPI.'} }
    ],
    [MODULES.FINANCE]: [
        { page:'dashboard',     selector:null, title:{en:'Welcome to Finance Tracker',ar:'مرحبًا في متتبع المالية'}, body:{en:'Live financials at a glance: MTD revenue, expenses, net profit, and outstanding invoices — with growth deltas vs last month.',ar:'المالية الحية بنظرة واحدة: الإيرادات والمصاريف والربح الصافي والفواتير المعلقة — مع نسب النمو مقارنة بالشهر الماضي.'} },
        { page:'invoices',      selector:'table', title:{en:'Tax-Compliant Invoices',ar:'الفواتير المتوافقة ضريبيًا'}, body:{en:'VAT 14% is auto-calculated on every invoice. Track how much is paid vs outstanding per client. Export to PDF with one click.',ar:'ضريبة القيمة المضافة 14% تُحسب تلقائيًا على كل فاتورة. تتبع المدفوع والمعلق لكل عميل. صدّر PDF بنقرة واحدة.'} },
        { page:'expenses',      selector:'table', title:{en:'Expense Management',ar:'إدارة المصاريف'}, body:{en:'Every outgoing payment is logged with vendor, category, VAT, method, and approver. Attach receipts and route for approval.',ar:'كل مدفوعات صادرة مُسجَّلة بالمورد والفئة والضريبة والطريقة والمعتمد. أرفق الإيصالات ووجّه للموافقة.'} },
        { page:'budgeting',     selector:'table', title:{en:'Budget vs Actual',ar:'الميزانية مقابل الفعلي'}, body:{en:'Set annual and quarterly budgets per category. Usage % updates as expenses are logged. Alerts fire automatically at 80% consumption.',ar:'ضع ميزانيات سنوية وفصلية لكل فئة. نسبة الاستخدام تتحدث مع تسجيل المصاريف. تنبيهات تلقائية عند 80%.'} },
        { page:'profitloss',    selector:'table', title:{en:'P&L Statement',ar:'بيان الأرباح والخسائر'}, body:{en:'Live P&L with current vs last period comparison. Drill into any line item — gross profit, EBITDA, net profit — for full transaction detail.',ar:'بيان الأرباح والخسائر الحي مع مقارنة الفترة الحالية بالماضية. انقر على أي بند للتفاصيل الكاملة.'} },
        { page:'analytics',     selector:null, title:{en:'Finance Analytics',ar:'التحليلات المالية'}, body:{en:'Cash flow inflow vs outflow over 6 months, expense category breakdown pie, and revenue trend line — full picture in seconds.',ar:'التدفق النقدي الوارد والصادر على 6 أشهر وتوزيع فئات المصاريف واتجاه الإيراد — الصورة الكاملة في ثوانٍ.'} }
    ],
    [MODULES.SALES]: [
        { page:'dashboard',     selector:null, title:{en:'Welcome to Sales Tracker',ar:'مرحبًا في متتبع المبيعات'}, body:{en:'MTD revenue, orders closed, quota attainment %, and average deal size — live at the top. Use quick-access links to jump to any section.',ar:'الإيراد الشهري والطلبات المغلقة ونسبة تحقيق الحصة ومتوسط الصفقة — حية في الأعلى. استخدم الوصول السريع للانتقال لأي قسم.'} },
        { page:'leads',         selector:'.pipeline-board', title:{en:'Sales Lead Pipeline',ar:'مسار عملاء المبيعات'}, body:{en:'Move leads across New → Contacted → Qualified → Proposal → Won. Click any card to view full details and contacts.',ar:'حرّك العملاء عبر جديد → تواصل → مؤهل → عرض → فوز. انقر أي بطاقة لعرض التفاصيل الكاملة وجهات الاتصال.'} },
        { page:'quotations',    selector:'table', title:{en:'Quotations',ar:'عروض الأسعار'}, body:{en:'Build professional quotes with line items and discount rules. Click "Convert to Order" once the client confirms.',ar:'أنشئ عروض احترافية بالبنود وقواعد الخصم. انقر "تحويل لطلب" بعد تأكيد العميل.'} },
        { page:'targets',       selector:'table', title:{en:'Sales Targets',ar:'أهداف المبيعات'}, body:{en:'Each rep\'s monthly target, achieved revenue, variance, and % attainment in one view. Color-coded — green is on track, red needs attention.',ar:'هدف كل مندوب الشهري والإيراد المحقق والفرق والنسبة في مكان واحد. ألوان — أخضر على المسار، أحمر يحتاج اهتمامًا.'} },
        { page:'commissions',   selector:'table', title:{en:'Commission Calculation',ar:'حساب العمولات'}, body:{en:'Commissions auto-calculated from closed revenue and rate tier. Status moves Draft → Approved → Paid each pay cycle.',ar:'العمولات تُحسب تلقائيًا من الإيراد المغلق وشريحة النسبة. الحالة تنتقل من مسودة إلى معتمد إلى مدفوع كل دورة.'} },
        { page:'analytics',     selector:null, title:{en:'Sales Analytics',ar:'تحليلات المبيعات'}, body:{en:'Revenue trend, per-rep performance bar, and product mix doughnut. Spot your top performer and best-selling category instantly.',ar:'اتجاه الإيراد وأداء كل مندوب وتوزيع المنتجات. اكتشف أفضل مندوب وأكثر منتج مبيعًا فورًا.'} }
    ],
    [MODULES.ACADEMY]: [
        { page:'dashboard',       selector:null,   title:{en:'Academy Overview',ar:'نظرة عامة على المركز'}, body:{en:'Live KPIs at a glance: total students, teachers, monthly revenue, and today\'s scheduled lectures — all on one screen.',ar:'مؤشرات أداء حية: إجمالي الطلاب والمعلمين والإيرادات الشهرية ومحاضرات اليوم — كل ذلك في شاشة واحدة.'} },
        { page:'edu_students',    selector:'table', title:{en:'Student Roster',ar:'قائمة الطلاب'}, body:{en:'Every enrolled student with their ID, grade, age, and phone number. Click the eye icon on any row to open their full profile and attendance history.',ar:'جميع الطلاب المسجلين بمعرّفاتهم ومستوياتهم وعمرهم ورقم الهاتف. انقر أيقونة العرض لفتح الملف الكامل وسجل الحضور.'} },
        { page:'edu_teachers',    selector:null,    title:{en:'Teachers\' Hub',ar:'مركز المعلمين'}, body:{en:'Each teacher has a profile card. Click any card to see their full weekly schedule and attendance history — useful for HR and supervision.',ar:'لكل معلم بطاقة ملف. انقر أي بطاقة لعرض جدوله الأسبوعي الكامل وسجل حضوره — مفيد للموارد البشرية والإشراف.'} },
        { page:'edu_attendance',  selector:null,    title:{en:'Attendance Tracking',ar:'تسجيل الحضور'}, body:{en:'Select a date, category (students or teachers), and lecture. Mark each person present or absent, add absence notes, and save with one click.',ar:'اختر التاريخ والفئة (طلاب أو معلمون) والمحاضرة. ضع علامة حضور أو غياب لكل شخص وأضف ملاحظة وأحفظ بنقرة واحدة.'} },
        { page:'edu_income',      selector:'table', title:{en:'Income Entries',ar:'سجل الإيرادات'}, body:{en:'Log every payment received from students — tuition, registration, activities. Category and subcategory come from your Settings configuration.',ar:'سجّل كل مبلغ مستلم من الطلاب — رسوم وتسجيل وأنشطة. الفئة والفئة الفرعية من إعدادات النظام.'} },
        { page:'edu_cashflow',    selector:null,    title:{en:'Cash Flow View',ar:'التدفق المالي'}, body:{en:'Combined inflow + outflow sorted by date. Filter by type or category to see exactly where money comes from and where it goes.',ar:'الوارد والصادر معًا مرتبان بالتاريخ. فلتر بالنوع أو الفئة لترى بالضبط مصادر المال وأين يذهب.'} },
        { page:'analytics',       selector:null,    title:{en:'Academy Analytics',ar:'تحليلات المركز'}, body:{en:'Enrollment growth line, monthly revenue bar, students-per-grade breakdown, and weekly attendance rate — four charts giving you the full picture.',ar:'منحنى نمو التسجيل وإيرادات شهرية وتوزيع الطلاب بالمستوى ونسبة الحضور الأسبوعي — أربعة رسوم بيانية تعطيك الصورة كاملة.'} }
    ]
};

let tourState = { active:false, stepIndex:0, mod:null };

function startTour() {
    state.showTourInvite = false;
    tourState = { active:true, stepIndex:0, mod:state.module };
    const firstStep = (TOUR_STEPS[tourState.mod]||[])[0];
    if (firstStep) { state.page = firstStep.page; }
    render();
    setTimeout(renderTourStep, 280);
}

function skipTour() {
    state.showTourInvite = false;
    tourState.active = false;
    document.getElementById('tour-bubble')?.remove();
    document.getElementById('tour-spotlight')?.remove();
    render();
}

function tourNext() {
    const steps = TOUR_STEPS[tourState.mod] || [];
    if (tourState.stepIndex < steps.length - 1) {
        tourState.stepIndex++;
        const step = steps[tourState.stepIndex];
        state.page = step.page;
        render();
        setTimeout(renderTourStep, 320);
    } else {
        tourState.active = false;
        document.getElementById('tour-bubble')?.remove();
        document.getElementById('tour-spotlight')?.remove();
        pushNotify(_t('Tour complete! Explore freely.','انتهت الجولة! استكشف بحرية.'));
    }
}

function tourPrev() {
    if (tourState.stepIndex > 0) {
        tourState.stepIndex--;
        const steps = TOUR_STEPS[tourState.mod] || [];
        const step = steps[tourState.stepIndex];
        state.page = step.page;
        render();
        setTimeout(renderTourStep, 320);
    }
}

function renderTourStep() {
    document.getElementById('tour-bubble')?.remove();
    document.getElementById('tour-spotlight')?.remove();

    const steps = TOUR_STEPS[tourState.mod] || [];
    if (!steps.length) return;
    const step = steps[tourState.stepIndex];
    const isLast = tourState.stepIndex === steps.length - 1;
    const isFirst = tourState.stepIndex === 0;

    // Spotlight
    const spotlight = document.createElement('div');
    spotlight.id = 'tour-spotlight';
    spotlight.className = 'tour-spotlight';
    const targetEl = step.selector ? document.querySelector(step.selector) : null;
    if (targetEl) {
        const r = targetEl.getBoundingClientRect();
        spotlight.style.top    = (r.top - 8) + 'px';
        spotlight.style.left   = (r.left - 8) + 'px';
        spotlight.style.width  = (r.width + 16) + 'px';
        spotlight.style.height = (r.height + 16) + 'px';
    } else {
        spotlight.style.display = 'none';
    }
    document.body.appendChild(spotlight);

    // Bubble
    const bubble = document.createElement('div');
    bubble.id = 'tour-bubble';
    bubble.className = 'tour-bubble';
    if (state.darkMode) bubble.classList.add('dark');
    bubble.innerHTML = `
        <div style="display:flex; align-items:center; gap:14px; margin-bottom:18px;">
            <div style="width:44px; height:44px; border-radius:14px; display:flex; align-items:center; justify-content:center; color:#fff; font-size:18px; font-weight:900; flex-shrink:0; background:${SYSTEM_MAP[tourState.mod]?.color||'#38bdf8'}; box-shadow:0 8px 20px ${SYSTEM_MAP[tourState.mod]?.color||'#38bdf8'}55;">${tourState.stepIndex+1}</div>
            <h3 style="font-size:18px; font-weight:900; line-height:1.25; color:${state.darkMode?'#f1f5f9':'#001e3c'}; margin:0;">${_t(step.title.en,step.title.ar)}</h3>
        </div>
        <p style="font-size:14px; line-height:1.75; color:${state.darkMode?'#94a3b8':'#64748b'}; margin:0 0 24px 0;">${_t(step.body.en,step.body.ar)}</p>
        <div style="display:flex; align-items:center; justify-content:space-between; gap:12px;">
            <div style="display:flex; gap:6px; align-items:center; flex-shrink:0;">
                ${steps.map((_,idx)=>`<div style="width:${idx===tourState.stepIndex?'22px':'7px'}; height:7px; border-radius:99px; transition:all 0.3s; background:${idx===tourState.stepIndex?(SYSTEM_MAP[tourState.mod]?.color||'#38bdf8'):(state.darkMode?'#334155':'#e2e8f0')};"></div>`).join('')}
            </div>
            <div style="display:flex; gap:8px; flex-shrink:0;">
                <button onclick="skipTour()" style="padding:10px 16px; border-radius:14px; font-size:11px; font-weight:800; text-transform:uppercase; letter-spacing:0.06em; background:${state.darkMode?'#1e293b':'#f1f5f9'}; color:${state.darkMode?'#94a3b8':'#64748b'}; border:none; cursor:pointer;">${_t('Skip','تخطي')}</button>
                ${!isFirst?`<button onclick="tourPrev()" style="padding:10px 16px; border-radius:14px; font-size:11px; font-weight:800; text-transform:uppercase; letter-spacing:0.06em; background:${state.darkMode?'#1e293b':'#f1f5f9'}; color:${state.darkMode?'#94a3b8':'#64748b'}; border:none; cursor:pointer;">← ${_t('Back','رجوع')}</button>`:''}
                <button onclick="tourNext()" style="padding:10px 22px; border-radius:14px; font-size:11px; font-weight:800; text-transform:uppercase; letter-spacing:0.06em; background:${SYSTEM_MAP[tourState.mod]?.color||'#38bdf8'}; color:#fff; border:none; cursor:pointer; box-shadow:0 6px 18px ${SYSTEM_MAP[tourState.mod]?.color||'#38bdf8'}55;">${isLast ? _t('Finish ✓','إنهاء ✓') : _t('Next →','التالي →')}</button>
            </div>
        </div>
    `;
    // Position bubble — below spotlight or centered on screen
    if (targetEl) {
        const r = targetEl.getBoundingClientRect();
        const bubbleH = 220;
        const bubbleW = Math.min(440, window.innerWidth - 32);
        let topPos = r.bottom + 20;
        if (topPos + bubbleH > window.innerHeight - 16) topPos = Math.max(16, r.top - bubbleH - 20);
        const leftPos = Math.max(16, Math.min(r.left + r.width/2 - bubbleW/2, window.innerWidth - bubbleW - 16));
        bubble.style.top  = topPos + 'px';
        bubble.style.left = leftPos + 'px';
    } else {
        bubble.style.top  = '50%';
        bubble.style.left = '50%';
        bubble.style.transform = 'translate(-50%, -50%)';
    }
    document.body.appendChild(bubble);
    lucide.createIcons();
}

function renderTourInvite() {
    const config = SYSTEM_MAP[state.module];
    return `
        <div class="tour-invite" id="tour-invite">
            <div class="bg-white dark:bg-slate-900 rounded-[2.5rem] p-10 max-w-md w-full mx-5 border border-slate-200 dark:border-slate-800 shadow-2xl text-center fade-in" style="box-shadow:0 40px 100px rgba(0,20,45,0.35);">
                <div class="w-20 h-20 rounded-[1.75rem] flex items-center justify-center mx-auto mb-7 text-white" style="background:${config.color}; box-shadow:0 12px 32px ${config.color}66;">
                    <i data-lucide="${config.icon}" size="38"></i>
                </div>
                <p class="text-xs font-black uppercase tracking-[0.2em] mb-2" style="color:${config.color}">${_t(config.title.en, config.title.ar)}</p>
                <h2 class="text-2xl font-black text-mantiq-navy dark:text-white mb-4 tracking-tight leading-tight">${_t('Take a Quick Tour?','هل تريد جولة سريعة؟')}</h2>
                <p class="text-slate-500 dark:text-slate-400 text-sm leading-relaxed mb-8">${_t('We\'ll walk you through the key features of the '+config.title.en+' — takes about 2 minutes.','سنأخذك عبر الميزات الرئيسية لـ '+config.title.ar+' — يستغرق حوالي دقيقتين.')}</p>
                <div class="flex gap-3">
                    <button onclick="skipTour()" class="flex-1 py-4 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-black text-sm uppercase tracking-wide">${_t('Skip','تخطي')}</button>
                    <button onclick="startTour()" class="flex-1 py-4 rounded-2xl text-white font-black text-sm uppercase tracking-wide" style="background:${config.color}; box-shadow:0 8px 24px ${config.color}55;">${_t('Start Tour →','ابدأ الجولة →')}</button>
                </div>
            </div>
        </div>
    `;
}

// ─── RENDER ───────────────────────────────────────────────────────────────────
function render() {
    const root = document.getElementById('app');
    root.innerHTML = state.module === MODULES.LANDING ? renderLanding() : renderApp();
    lucide.createIcons();
    if (state.page === 'analytics') { if (state.module === MODULES.HR) renderHRCharts(); else renderCharts(); }

    // Inject tour invite as DOM overlay (not inside app innerHTML, so it survives re-renders)
    document.getElementById('tour-invite-overlay')?.remove();
    if (state.showTourInvite && state.module !== MODULES.LANDING) {
        const inv = document.createElement('div');
        inv.id = 'tour-invite-overlay';
        inv.innerHTML = renderTourInvite();
        document.body.appendChild(inv);
        lucide.createIcons();
    }

    // Re-attach live tour bubble if tour is mid-flow
    if (tourState.active) {
        setTimeout(renderTourStep, 280);
    }
}


// ════════════════════════════════════════════════════════════════
// HR SYSTEM — ENHANCED MODULE
// ════════════════════════════════════════════════════════════════
// ═══════════════════════════════════════════════════════════════
// CONSTANTS
// ═══════════════════════════════════════════════════════════════
const HR_COLOR = '#a78bfa';
const HR_NAVY  = '#001e3c';

const DEPT_COLORS = {
    'Engineering':'#38bdf8','Sales':'#fb923c','Finance':'#34d399',
    'HR':'#a78bfa','Operations':'#f472b6','Marketing':'#fbbf24',
    'Legal':'#94a3b8','Customer Success':'#4ade80'
};

const CONTRACT_BADGE = { 'Full-Time':'badge-green','Part-Time':'badge-blue','Contractor':'badge-amber','Internship':'badge-purple' };

const LEAVE_COLORS = { 'Annual':'#38bdf8','Sick':'#f87171','Emergency':'#fb923c','Unpaid':'#94a3b8','Maternity/Paternity':'#f472b6' };

const RECRUIT_STAGES = [
    { id:'applied',    label:{en:'Applied',ar:'تقدَّم'},        color:'#94a3b8', icon:'inbox' },
    { id:'screening',  label:{en:'Screening',ar:'فرز أولي'},   color:'#38bdf8', icon:'search' },
    { id:'interview',  label:{en:'Interview',ar:'مقابلة'},      color:'#818cf8', icon:'video' },
    { id:'offer',      label:{en:'Offer Sent',ar:'عرض أُرسل'}, color:'#fb923c', icon:'send' },
    { id:'hired',      label:{en:'Hired ✓',ar:'تم التعيين ✓'}, color:'#34d399', icon:'check-circle' },
    { id:'rejected',   label:{en:'Rejected',ar:'مرفوض'},        color:'#f87171', icon:'x-circle' }
];





// ═══════════════════════════════════════════════════════════════
// DATA INITIALIZATION
// ═══════════════════════════════════════════════════════════════
function initHRData() {
    const NAMES = ['Ahmed Hassan','Mona Zaki','Kareem Abdelaziz','Sara El-Gohary','Youssef El-Shamy',
        'Omar Khairat','Layla Eloui','Tarek El-Sheikh','Hana Mustafa','Ramy Saleh',
        'Dina Kamal','Islam Raafat','Rana Magdy','Bassem Atef','Nour El-Din',
        'Salma Khaled','Ziad Mostafa','Mariam Sherif','Hassan Abdalla','Fatma Ibrahim',
        'Sherif Gaber','Asmaa Lotfy','Mahmoud Tarek','Enas Saad','Walid Nour'];
    const DEPTS = ['Engineering','Sales','Finance','HR','Operations','Marketing','Legal','Customer Success'];
    const JOBS = ['Software Engineer','Sales Manager','Financial Analyst','HR Specialist','Operations Director',
        'Marketing Lead','Legal Counsel','Customer Success Manager','Senior Developer','Sales Rep',
        'Accountant','HR Coordinator','Logistics Manager','Content Creator','Junior Developer'];
    const MANAGERS = ['Ahmed Hassan','Sara El-Gohary','Youssef El-Shamy','Omar Khairat','Layla Eloui'];
    const rnd = a => a[Math.floor(Math.random()*a.length)];
    const rndN = (mn,mx) => Math.floor(Math.random()*(mx-mn+1))+mn;
    const d = (m=0) => { const dt=new Date(2024,8+m,rndN(1,28)); return dt.toISOString().slice(0,10); };

    // ── Employees (25)
    state.data.employees = NAMES.map((name,i) => ({
        id: 'EMP-' + String(1001+i).padStart(4,'0'),
        name,
        firstName: name.split(' ')[0],
        avatar: name.slice(0,2).toUpperCase(),
        jobTitle: JOBS[i % JOBS.length],
        dept: DEPTS[i % DEPTS.length],
        manager: i < 5 ? 'C-Level' : MANAGERS[i % MANAGERS.length],
        email: name.toLowerCase().replace(/ /g,'.') + '@company.com',
        phone: '010' + rndN(10000000,99999999),
        mobile: '011' + rndN(10000000,99999999),
        hireDate: d(-(i % 4)),
        contractType: ['Full-Time','Full-Time','Full-Time','Part-Time','Contractor'][i % 5],
        contractEnd: i % 4 === 0 ? d(2) : i % 6 === 0 ? d(1) : null,
        salary: (rndN(8,60) * 1000),
        allowances: (rndN(1,8) * 1000),
        transportAllowance: (rndN(5,15) * 100),
        mobileAllowance: 500,
        deductions: (rndN(0,3) * 500),
        socialInsurance: null, // computed
        incomeTax: null,       // computed
        dept_color: DEPTS[i % DEPTS.length],
        status: i % 8 === 0 ? 'On Leave' : i % 12 === 0 ? 'Inactive' : 'Active',
        leaveBalance: { Annual: rndN(5,21), Sick: rndN(3,10), Emergency: 3 },
        nationality: ['Egyptian','Egyptian','Egyptian','Egyptian','Saudi','Jordanian','Egyptian'][i%7],
        nationalId: '29' + rndN(1000000000,9999999999),
        startDate: d(-(i%4)),
        probationEnd: d(-(i%4-3)),
        emergencyContact: NAMES[(i+3)%NAMES.length],
        emergencyPhone: '012' + rndN(10000000,99999999),
        address: ['Cairo','Giza','Alexandria','New Cairo','6th October'][i%5],
        education: ['Bachelor\'s - Computer Science','MBA','Bachelor\'s - Commerce','BSc Engineering','Bachelor\'s - Arts'][i%5],
        lastReview: d(-(i%2)),
        performanceScore: (rndN(28,50)/10).toFixed(1),
        notes: '',
        photo: null,
    }));

    // Compute social insurance & tax
    state.data.employees.forEach(e => {
        e.socialInsurance = Math.round(e.salary * 0.11);
        const gross = e.salary + e.allowances + e.transportAllowance + e.mobileAllowance;
        e.incomeTax = gross > 40000 ? Math.round((gross - 40000)*0.25) : gross > 20000 ? Math.round((gross-20000)*0.15) : 0;
        e.netSalary = gross - e.deductions - e.socialInsurance - e.incomeTax;
    });

    // ── Attendance (last 20 days × sample employees)
    state.data.attendance = [];
    const empSample = state.data.employees.slice(0,15);
    for (let d2=0; d2<10; d2++) {
        const dt = new Date(2025,2,10-d2);
        const dateStr = dt.toISOString().slice(0,10);
        empSample.forEach((e,i) => {
            const inH = rndN(8,10);
            const inM = rndN(0,59);
            const outH = rndN(16,19);
            const outM = rndN(0,59);
            const lateMin = inH > 9 ? (inH-9)*60+inM : inH===9&&inM>0 ? inM : 0;
            const workedH = outH - inH + (outM - inM)/60;
            const overtime = Math.max(0, workedH - 8);
            const absent = (i + d2) % 7 === 0;
            state.data.attendance.push({
                id: 'ATT-' + String(state.data.attendance.length+1).padStart(5,'0'),
                empId: e.id, empName: e.name, dept: e.dept,
                date: dateStr,
                checkIn:  absent ? null : `${String(inH).padStart(2,'0')}:${String(inM).padStart(2,'0')}`,
                checkOut: absent ? null : `${String(outH).padStart(2,'0')}:${String(outM).padStart(2,'0')}`,
                workedHours: absent ? 0 : +workedH.toFixed(1),
                lateMinutes: absent ? 0 : lateMin,
                overtime: absent ? 0 : +overtime.toFixed(1),
                status: absent ? 'Absent' : lateMin > 15 ? 'Late' : 'Present',
                note: absent ? 'No check-in recorded' : ''
            });
        });
    }

    // ── Leaves
    const LEAVE_REASONS = ['Family vacation','Medical appointment','Emergency family issue','Personal matter','Medical procedure','Honeymoon','Religious holiday'];
    state.data.leaves = state.data.employees.slice(0,18).map((e,i) => ({
        id: 'LV-' + String(1001+i).padStart(4,'0'),
        empId: e.id,
        empName: e.name,
        dept: e.dept,
        type: ['Annual','Annual','Sick','Emergency','Maternity/Paternity','Unpaid','Annual'][i%7],
        startDate: `2025-0${(i%3)+1}-${String(rndN(1,20)).padStart(2,'0')}`,
        endDate:   `2025-0${(i%3)+1}-${String(rndN(21,28)).padStart(2,'0')}`,
        days: rndN(1,14),
        reason: LEAVE_REASONS[i%LEAVE_REASONS.length],
        status: ['Pending','Approved','Approved','Rejected','Pending','Approved','Approved'][i%7],
        appliedDate: `2025-0${(i%3)+1}-01`,
        approvedBy: i%3===0 ? null : MANAGERS[i%MANAGERS.length],
        hrApproved: i%4===0 ? false : true,
        comment: i%5===0 ? 'Please ensure coverage for your tasks.' : '',
    }));

    // ── Payroll (March 2025)
    state.data.payroll = state.data.employees.map((e,i) => ({
        id: 'PAY-' + String(2001+i).padStart(4,'0'),
        empId: e.id,
        empName: e.name,
        dept: e.dept,
        month: 'March 2025',
        baseSalary: e.salary,
        allowances: e.allowances,
        transport: e.transportAllowance,
        mobile: e.mobileAllowance,
        bonus: i%5===0 ? rndN(1,5)*1000 : 0,
        deductions: e.deductions,
        socialInsurance: e.socialInsurance,
        incomeTax: e.incomeTax,
        lateDeductions: Math.round((state.data.attendance.filter(a=>a.empId===e.id&&a.lateMinutes>0).reduce((s,a)=>s+a.lateMinutes,0)/60) * (e.salary/176)),
        netSalary: e.netSalary,
        paymentMethod: ['Bank Transfer','Bank Transfer','Bank Transfer','Cash','Bank Transfer'][i%5],
        bankAccount: 'XXXX-XXXX-' + rndN(1000,9999),
        status: i%8===0 ? 'Pending' : i%12===0 ? 'On Hold' : 'Processed',
        processedDate: i%8===0 ? null : '2025-03-28',
        slipGenerated: i%8!==0,
    }));

    // ── Contracts
    state.data.contracts = state.data.employees.map((e,i) => ({
        id: 'CTR-' + String(3001+i).padStart(4,'0'),
        empId: e.id,
        empName: e.name,
        dept: e.dept,
        type: e.contractType,
        startDate: e.hireDate,
        endDate: e.contractEnd,
        duration: e.contractEnd ? '1 Year' : 'Permanent',
        noticePeriod: ['30 Days','60 Days','30 Days','14 Days','90 Days'][i%5],
        probationEnd: e.probationEnd,
        renewalAlert: e.contractEnd ? (new Date(e.contractEnd) - new Date() < 30*24*3600*1000 ? 'Expiring Soon' : 'Active') : 'Permanent',
        status: e.contractEnd && new Date(e.contractEnd) < new Date() ? 'Expired' : 'Active',
        signedDate: e.hireDate,
        documents: ['Employment Contract.pdf','ID Copy.pdf','Offer Letter.pdf'].slice(0,rndN(1,3)),
    }));

    // ── Recruitment pipeline
    state.data.recruitment = [];
    const POSITIONS = ['Senior Developer','Sales Representative','Financial Controller','HR Manager','Marketing Specialist','Operations Lead','UX Designer','DevOps Engineer'];
    const APPLICANT_NAMES = ['Mohamed Ali','Nadia Salem','Khaled Ibrahim','Rania Tawfik','Amr Hassan','Dalia Nour','Faisal Ahmad','Yasmin Sherif','Amir Kamal','Lena Hossam','Tariq Fouad','Sara Gaber'];
    const SOURCES = ['LinkedIn','Indeed','Referral','Company Website','Wuzzuf','Forasna'];
    let rid=4001;
    RECRUIT_STAGES.forEach((stage,si) => {
        const count=[4,3,3,2,2,2][si]||2;
        for(let i=0;i<count;i++){
            const ni=(rid+i)%APPLICANT_NAMES.length;
            state.data.recruitment.push({
                id:'APP-'+String(rid++).padStart(4,'0'),
                name: APPLICANT_NAMES[ni],
                position: POSITIONS[(si+i)%POSITIONS.length],
                dept: ['Engineering','Sales','Finance','HR','Marketing','Operations'][si%6],
                source: SOURCES[(si+i)%SOURCES.length],
                stage: stage.id,
                appliedDate: `2025-0${rndN(1,3)}-${String(rndN(1,28)).padStart(2,'0')}`,
                experience: rndN(1,12) + ' yrs',
                salary_expect: (rndN(15,60)*1000) + ' EGP',
                score: rndN(40,98),
                interviewer: MANAGERS[(si+i)%MANAGERS.length],
                interviewDate: stage.id==='interview'||stage.id==='offer' ? `2025-03-${String(rndN(10,28)).padStart(2,'0')}` : null,
                notes: si===0?'':'Promising candidate, strong technical background.',
                email: APPLICANT_NAMES[ni].toLowerCase().replace(/ /g,'.') + '@gmail.com',
                phone: '010' + rndN(10000000,99999999),
            });
        }
    });

    // ── Performance Reviews
    state.data.performance = state.data.employees.slice(0,20).map((e,i) => ({
        id:'PER-'+String(5001+i).padStart(4,'0'),
        empId: e.id,
        empName: e.name,
        dept: e.dept,
        period: 'Q1 2025',
        reviewer: MANAGERS[i%MANAGERS.length],
        kpiScore: (rndN(28,50)/10).toFixed(1),
        attitudeScore: (rndN(30,50)/10).toFixed(1),
        teamworkScore: (rndN(30,50)/10).toFixed(1),
        communicationScore: (rndN(28,50)/10).toFixed(1),
        initiativeScore: (rndN(25,50)/10).toFixed(1),
        overallScore: null, // computed
        kpiDetails: [
            { label:'Targets Met', val: rndN(60,100)+'%' },
            { label:'Projects Completed', val: rndN(2,8) },
            { label:'On-Time Delivery', val: rndN(70,100)+'%' },
        ],
        strengths: ['Technical skills','Leadership','Communication'][i%3],
        improvements: ['Time management','Documentation','Delegation'][i%3],
        managerComment: 'Strong performer this quarter. Delivered all major milestones on time.',
        status: i%5===0 ? 'Pending Submission' : i%7===0 ? 'Under Review' : 'Completed',
        submitDate: i%5===0 ? null : '2025-03-15',
    }));
    state.data.performance.forEach(p => {
        p.overallScore = ((parseFloat(p.kpiScore)+parseFloat(p.attitudeScore)+parseFloat(p.teamworkScore)+parseFloat(p.communicationScore)+parseFloat(p.initiativeScore))/5).toFixed(1);
    });

    // ── Training
    state.data.training = [
        { id:'TRN-001', name:'Leadership Excellence', provider:'Dale Carnegie', type:'External', mode:'In-Person', enrollees:12, completed:8, hours:16, cost:24000, startDate:'2025-02-01', endDate:'2025-02-15', status:'Completed', cert:true },
        { id:'TRN-002', name:'Advanced Excel & Power BI', provider:'Internal L&D', type:'Internal', mode:'Online', enrollees:18, completed:15, hours:8, cost:0, startDate:'2025-01-20', endDate:'2025-01-27', status:'Completed', cert:false },
        { id:'TRN-003', name:'Project Management (PMP)', provider:'PMI Egypt', type:'External', mode:'In-Person', enrollees:6, completed:3, hours:40, cost:48000, startDate:'2025-03-01', endDate:'2025-03-31', status:'In Progress', cert:true },
        { id:'TRN-004', name:'ISO 9001 Quality Awareness', provider:'Bureau Veritas', type:'External', mode:'Online', enrollees:30, completed:22, hours:4, cost:9000, startDate:'2025-01-10', endDate:'2025-01-12', status:'Completed', cert:true },
        { id:'TRN-005', name:'Sales Excellence Program', provider:'ESLSCA', type:'External', mode:'In-Person', enrollees:10, completed:0, hours:24, cost:36000, startDate:'2025-04-05', endDate:'2025-04-20', status:'Scheduled', cert:false },
        { id:'TRN-006', name:'Cybersecurity Basics', provider:'Internal IT', type:'Internal', mode:'Online', enrollees:45, completed:38, hours:3, cost:0, startDate:'2025-02-10', endDate:'2025-02-12', status:'Completed', cert:true },
        { id:'TRN-007', name:'Customer Service Excellence', provider:'AUC Exec Ed', type:'External', mode:'Blended', enrollees:14, completed:9, hours:12, cost:21000, startDate:'2025-03-15', endDate:'2025-03-22', status:'In Progress', cert:false },
        { id:'TRN-008', name:'Arabic Business Writing', provider:'Internal L&D', type:'Internal', mode:'In-Person', enrollees:20, completed:0, hours:6, cost:0, startDate:'2025-04-15', endDate:'2025-04-17', status:'Scheduled', cert:false },
    ];

    // ── HR Reports (metric snapshots)
    state.data.hrReports = {
        headcount: { current:25, lastMonth:24, target:30, byDept:{ Engineering:5, Sales:6, Finance:4, HR:3, Operations:4, Marketing:3 } },
        turnover: { rate:'8%', resigned:2, terminated:0, period:'Q1 2025' },
        avgTenure: '2.4 yrs',
        timeToHire: '18 days',
        offerAcceptance: '82%',
        trainingHoursAvg: 14,
        payrollCost: 1850000,
        absenteeism: '3.2%',
        openPositions: 5,
        pendingLeaves: state.data.leaves.filter(l=>l.status==='Pending').length,
        expiringContracts: state.data.contracts.filter(c=>c.renewalAlert==='Expiring Soon').length,
    };

    // ── Settings
    state.data.hrSettings = {
        workingHours: { start:'09:00', end:'17:00', days:['Sun','Mon','Tue','Wed','Thu'] },
        leavePolicy: { annual:21, sick:10, emergency:3, unpaid:'unlimited', carryover:5 },
        overtimeRate: 1.5,
        probationDays: 90,
        noticePeriod: { 'Full-Time':30, 'Part-Time':14, 'Contractor':7 },
        taxBands: [{ from:0, to:20000, rate:'0%' },{ from:20001, to:40000, rate:'15%' },{ from:40001, to:Infinity, rate:'25%' }],
        socialInsurance: '11%',
        departments: ['Engineering','Sales','Finance','HR','Operations','Marketing','Legal','Customer Success'],
        roles: ['Super Admin','HR Manager','Department Manager','Team Lead','Employee','Read Only'],
    };
}


function scoreColor(s) {
    const n=parseFloat(s);
    if(n>=4.5) return '#34d399';
    if(n>=3.5) return '#38bdf8';
    if(n>=2.5) return '#fb923c';
    return '#f87171';
}

function daysUntil(dateStr) {
    if(!dateStr) return null;
    const diff = new Date(dateStr) - new Date();
    return Math.ceil(diff/(1000*60*60*24));
}

function formatCurrency(n) {
    return Math.abs(n).toLocaleString() + ' EGP';
}

function getEmp(id) { return state.data.employees.find(e=>e.id===id); }


function openEmployee(id) { state.openEmployeeId=id; render(); }
function closeEmployee() { state.openEmployeeId=null; render(); }

function renderHRCharts() {
    const isDark = state.darkMode;
    const grid   = isDark?'rgba(255,255,255,0.06)':'rgba(0,0,0,0.06)';
    const text   = isDark?'#94a3b8':'#64748b';
    Chart.defaults.color=text; Chart.defaults.borderColor=grid;
    document.querySelectorAll('canvas[data-chart]').forEach(c=>{const e=Chart.getChart(c);if(e)e.destroy();});
    setTimeout(()=>{
        const c1=document.getElementById('ch-headcount');
        if(c1) new Chart(c1,{type:'line',data:{labels:['Oct','Nov','Dec','Jan','Feb','Mar'],datasets:[{label:'Headcount',data:[22,23,23,24,24,25],borderColor:HR_COLOR,backgroundColor:'rgba(167,139,250,0.1)',tension:0.4,fill:true,pointRadius:5,pointBackgroundColor:HR_COLOR}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{x:{grid:{display:false}},y:{grid:{color:grid},min:18}}}});
        const c2=document.getElementById('ch-dept');
        if(c2) new Chart(c2,{type:'bar',data:{labels:['Eng','Sales','Fin','HR','Ops','Mkt'],datasets:[{label:'Employees',data:[5,6,4,3,4,3],backgroundColor:'rgba(167,139,250,0.7)',borderRadius:8,borderSkipped:false}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{x:{grid:{display:false}},y:{grid:{color:grid}}}}});
        const c3=document.getElementById('ch-attendance');
        if(c3) new Chart(c3,{type:'line',data:{labels:['Mon','Tue','Wed','Thu','Sun'],datasets:[{label:'Attendance %',data:[94,91,97,89,88],borderColor:'#34d399',backgroundColor:'rgba(52,211,153,0.1)',tension:0.4,fill:true,pointRadius:5,pointBackgroundColor:'#34d399'}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{x:{grid:{display:false}},y:{min:75,max:100,grid:{color:grid}}}}});
        const c4=document.getElementById('ch-leave-types');
        if(c4) new Chart(c4,{type:'doughnut',data:{labels:['Annual','Sick','Emergency','Maternity','Unpaid'],datasets:[{data:[45,28,12,10,5],backgroundColor:['#38bdf8','#f87171','#fb923c','#f472b6','#94a3b8'],borderWidth:0,hoverOffset:8}]},options:{responsive:true,cutout:'62%',plugins:{legend:{position:'bottom',labels:{boxWidth:10,padding:14}}}}});
        const c5=document.getElementById('ch-payroll-trend');
        if(c5) new Chart(c5,{type:'bar',data:{labels:['Oct','Nov','Dec','Jan','Feb','Mar'],datasets:[{label:'Payroll Cost (K EGP)',data:[1720,1740,1750,1800,1820,1850],backgroundColor:'rgba(167,139,250,0.7)',borderRadius:8,borderSkipped:false}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{x:{grid:{display:false}},y:{grid:{color:grid}}}}});
        const c6=document.getElementById('ch-perf-dist');
        if(c6) new Chart(c6,{type:'bar',data:{labels:['< 2.5','2.5–3.5','3.5–4.5','4.5–5'],datasets:[{label:'Employees',data:[1,4,14,6],backgroundColor:['#f87171','#fb923c','#38bdf8','#34d399'],borderRadius:8,borderSkipped:false}]},options:{responsive:true,plugins:{legend:{display:false}},scales:{x:{grid:{display:false}},y:{grid:{color:grid}}}}});
    },80);
}


function renderEmployeeDrawer() {
    const e = getEmp(state.openEmployeeId);
    if(!e) return '';
    const dc = DEPT_COLORS[e.dept]||HR_COLOR;
    const payRow = state.data.payroll.find(p=>p.empId===e.id);
    const leaveRows = state.data.leaves.filter(l=>l.empId===e.id);
    const attRows = state.data.attendance.filter(a=>a.empId===e.id).slice(0,7);
    const perf = state.data.performance.find(p=>p.empId===e.id);
    const contract = state.data.contracts.find(c=>c.empId===e.id);

    const tabs = [
        {id:'profile',label:_t('Profile','الملف')},
        {id:'salary', label:_t('Salary','الراتب')},
        {id:'leaves', label:_t('Leaves','الإجازات')},
        {id:'attend', label:_t('Attendance','الحضور')},
    ];
    const activeTab = state.empDrawerTab||'profile';

    const profileContent = `
        <div class="space-y-5">
            <div class="grid grid-cols-2 gap-4">
                ${[
                    [_t('Employee ID','المعرف'), e.id],
                    [_t('Job Title','المنصب'), e.jobTitle],
                    [_t('Department','القسم'), `<span style="color:${dc}">${e.dept}</span>`],
                    [_t('Reports To','المدير'), e.manager],
                    [_t('Email','البريد'), `<span class="text-mantiq-cyan text-[11px]">${e.email}</span>`],
                    [_t('Phone','الهاتف'), e.phone],
                    [_t('Mobile','المحمول'), e.mobile],
                    [_t('Nationality','الجنسية'), e.nationality],
                    [_t('Address','العنوان'), e.address],
                    [_t('Education','التعليم'), e.education],
                    [_t('Hire Date','تاريخ التعيين'), e.hireDate],
                    [_t('Contract Type','نوع العقد'), badgeHtml(e.contractType, CONTRACT_BADGE[e.contractType]||'badge-blue')],
                    [_t('Status','الحالة'), badgeHtml(e.status)],
                    [_t('National ID','الرقم القومي'), e.nationalId],
                    [_t('Emergency Contact','جهة الطوارئ'), e.emergencyContact],
                    [_t('Emergency Phone','هاتف الطوارئ'), e.emergencyPhone],
                ].map(([k,v])=>`
                    <div class="bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl">
                        <p class="text-[9px] font-black uppercase text-slate-400 mb-1">${k}</p>
                        <p class="text-xs font-bold text-mantiq-navy dark:text-white">${v}</p>
                    </div>
                `).join('')}
            </div>
            ${contract ? `
            <div class="bg-amber-50 dark:bg-amber-950/30 p-4 rounded-2xl border border-amber-200 dark:border-amber-900">
                <div class="flex justify-between items-center">
                    <div>
                        <p class="text-[9px] font-black uppercase text-amber-600 mb-1">${_t('Contract','العقد')}</p>
                        <p class="text-sm font-black text-mantiq-navy dark:text-white">${contract.type} — ${contract.duration}</p>
                        ${contract.endDate?`<p class="text-xs text-amber-600 font-bold">${_t('Expires:','ينتهي:')} ${contract.endDate}</p>`:''}
                    </div>
                    ${badgeHtml(contract.renewalAlert)}
                </div>
            </div>` : ''}
            ${perf ? `
            <div class="p-4 rounded-2xl border border-slate-100 dark:border-slate-800">
                <p class="text-[9px] font-black uppercase text-slate-400 mb-3">${_t('Latest Performance Score','آخر تقييم أداء')} (${perf.period})</p>
                <div class="flex items-center gap-4">
                    <div class="w-14 h-14 rounded-2xl flex items-center justify-center font-black text-xl text-white" style="background:${scoreColor(perf.overallScore)}">${perf.overallScore}</div>
                    <div class="flex-1 space-y-1.5">
                        ${[['KPI',perf.kpiScore],['Teamwork',perf.teamworkScore],['Communication',perf.communicationScore]].map(([l,v])=>`
                            <div class="flex items-center gap-2">
                                <span class="text-[9px] font-bold text-slate-400 w-24">${l}</span>
                                <div class="flex-1 kpi-bar"><div class="kpi-bar-fill" style="width:${parseFloat(v)/5*100}%;background:${scoreColor(v)}"></div></div>
                                <span class="text-[9px] font-black" style="color:${scoreColor(v)}">${v}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>` : ''}
            <div class="flex gap-2">
                <button onclick="pushNotify('${_t('Opening email...','فتح البريد...')}')" class="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-black text-slate-600 dark:text-slate-300 uppercase"><i data-lucide="mail" size="13"></i>${_t('Email','بريد')}</button>
                <button onclick="pushNotify('${_t('Generating payslip...','إنشاء قسيمة راتب...')}')" class="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-black text-slate-600 dark:text-slate-300 uppercase"><i data-lucide="receipt" size="13"></i>${_t('Payslip','الراتب')}</button>
                <button onclick="pushNotify('${_t('Editing employee...','تعديل الموظف...')}')" class="py-3 px-4 rounded-xl bg-purple-100 dark:bg-purple-950/40 text-purple-600 font-black"><i data-lucide="edit" size="14"></i></button>
                <button onclick="if(confirm('${_t('Archive this employee?','أرشفة هذا الموظف؟')}')){ const e=state.data.employees.find(x=>x.id==='${e.id}'); if(e)e.status='Inactive'; pushNotify('${_t('Employee archived.','تم أرشفة الموظف.')}'); closeEmployee(); }" class="py-3 px-4 rounded-xl bg-red-50 dark:bg-red-950/40 text-rose-500 font-black"><i data-lucide="archive" size="14"></i></button>
            </div>
        </div>
    `;

    const salaryContent = payRow ? `
        <div class="space-y-4">
            <div class="p-6 rounded-2xl border border-slate-100 dark:border-slate-800">
                <p class="text-[10px] font-black uppercase text-slate-400 mb-4">${_t('Salary Breakdown — March 2025','تفاصيل الراتب — مارس 2025')}</p>
                <div class="space-y-1">
                    ${[
                        {label:_t('Base Salary','الراتب الأساسي'), val:payRow.baseSalary, type:'earning'},
                        {label:_t('Housing Allowance','بدل سكن'), val:payRow.allowances, type:'earning'},
                        {label:_t('Transport','النقل'), val:payRow.transport, type:'earning'},
                        {label:_t('Mobile','المحمول'), val:payRow.mobile, type:'earning'},
                        {label:_t('Bonus','مكافأة'), val:payRow.bonus, type:'earning'},
                        {label:'—', val:null, type:'divider'},
                        {label:_t('Deductions','خصومات'), val:payRow.deductions, type:'deduction'},
                        {label:_t('Social Insurance (11%)','تأمينات اجتماعية (11%)'), val:payRow.socialInsurance, type:'deduction'},
                        {label:_t('Income Tax','ضريبة دخل'), val:payRow.incomeTax, type:'deduction'},
                        {label:_t('Late Penalty','خصم تأخير'), val:payRow.lateDeductions, type:'deduction'},
                    ].map(row=>{
                        if(row.type==='divider') return `<div class="border-t border-slate-100 dark:border-slate-800 my-2"></div>`;
                        if(!row.val && row.type!=='earning') return '';
                        return `<div class="slip-row"><span class="text-xs font-bold text-slate-600 dark:text-slate-300">${row.label}</span><span class="text-xs font-black ${row.type==='earning'?'text-mantiq-navy dark:text-white':'text-rose-500'}">${row.type==='earning'?'+':'-'} ${formatCurrency(row.val||0)}</span></div>`;
                    }).join('')}
                    <div class="pt-3 mt-2 border-t-2 border-mantiq-navy dark:border-white">
                        <div class="slip-row">
                            <span class="text-sm font-black text-mantiq-navy dark:text-white uppercase">${_t('Net Salary','صافي الراتب')}</span>
                            <span class="text-lg font-black text-emerald-600">${formatCurrency(payRow.netSalary)}</span>
                        </div>
                    </div>
                </div>
                <div class="mt-4 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 flex justify-between items-center">
                    <span class="text-xs font-bold text-slate-500">${_t('Payment Method','طريقة الدفع')}</span>
                    <span class="text-xs font-black text-mantiq-navy dark:text-white">${payRow.paymentMethod} — ${payRow.bankAccount}</span>
                </div>
            </div>
            <button onclick="pushNotify('${_t('Payslip PDF generated...','تم إنشاء قسيمة الراتب PDF...')}')" class="w-full py-4 rounded-2xl font-black text-sm uppercase text-white flex items-center justify-center gap-2" style="background:${HR_COLOR}">
                <i data-lucide="download" size="16"></i>${_t('Download Payslip','تحميل قسيمة الراتب')}
            </button>
        </div>
    ` : `<p class="text-slate-400 italic text-sm">${_t('No payroll record found.','لا يوجد سجل رواتب.')}</p>`;

    const leavesContent = `
        <div class="space-y-4">
            <div class="grid grid-cols-3 gap-3">
                ${Object.entries(e.leaveBalance).map(([type,bal])=>`
                    <div class="text-center p-4 rounded-2xl border border-slate-100 dark:border-slate-800">
                        <p class="text-2xl font-black mb-1" style="color:${LEAVE_COLORS[type]||HR_COLOR}">${bal}</p>
                        <p class="text-[9px] font-black uppercase text-slate-400">${type}</p>
                        <p class="text-[8px] text-slate-400">${_t('days left','أيام متبقية')}</p>
                    </div>
                `).join('')}
            </div>
            <p class="text-[10px] font-black uppercase text-slate-400">${_t('Leave History','سجل الإجازات')}</p>
            ${leaveRows.length ? leaveRows.map(l=>`
                <div class="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="text-sm font-black text-mantiq-navy dark:text-white">${l.type}</p>
                            <p class="text-xs text-slate-400">${l.startDate} → ${l.endDate} (${l.days} ${_t('days','أيام')})</p>
                            <p class="text-xs text-slate-500 mt-1 italic">"${l.reason}"</p>
                        </div>
                        ${badgeHtml(l.status)}
                    </div>
                </div>
            `).join('') : `<p class="text-xs text-slate-400 italic">${_t('No leave records.','لا توجد سجلات إجازات.')}</p>`}
        </div>
    `;

    const attendContent = `
        <div class="space-y-3">
            ${attRows.length ? attRows.map(a=>`
                <div class="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40">
                    <div>
                        <p class="text-xs font-black text-mantiq-navy dark:text-white">${a.date}</p>
                        <p class="text-[10px] text-slate-400 font-bold">${a.checkIn||'—'} → ${a.checkOut||'—'} · ${a.workedHours}h</p>
                        ${a.lateMinutes>0?`<p class="text-[9px] text-amber-500 font-bold">⚠ ${a.lateMinutes} min late</p>`:''}
                        ${a.overtime>0?`<p class="text-[9px] text-blue-500 font-bold">+${a.overtime}h overtime</p>`:''}
                    </div>
                    ${badgeHtml(a.status)}
                </div>
            `).join('') : `<p class="text-xs text-slate-400 italic">${_t('No attendance records.','لا توجد سجلات حضور.')}</p>`}
        </div>
    `;

    const tabContent = { profile:profileContent, salary:salaryContent, leaves:leavesContent, attend:attendContent };

    return `
        <div class="emp-drawer-overlay" onclick="closeEmployee()"></div>
        <div class="emp-drawer custom-scrollbar" onclick="event.stopPropagation()">
            <!-- Header -->
            <div class="sticky top-0 z-10 bg-white/95 dark:bg-slate-900/95 backdrop-blur-sm border-b border-slate-100 dark:border-slate-800 px-8 py-6 flex items-center justify-between">
                <div class="flex items-center gap-4">
                    <div class="w-12 h-12 rounded-2xl flex items-center justify-center text-white font-black text-sm shadow-lg" style="background:${dc}">${e.avatar}</div>
                    <div>
                        <p class="font-black text-mantiq-navy dark:text-white text-base">${e.name}</p>
                        <p class="text-xs text-slate-400 font-bold">${e.jobTitle} · ${e.dept}</p>
                    </div>
                </div>
                <button onclick="closeEmployee()" class="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-rose-500 transition-colors"><i data-lucide="x" size="20"></i></button>
            </div>
            <!-- Tabs -->
            <div class="px-8 py-4 flex gap-2 border-b border-slate-100 dark:border-slate-800 overflow-x-auto">
                ${tabs.map(tab=>`
                    <button onclick="state.empDrawerTab='${tab.id}'; render();" class="tab-pill ${activeTab===tab.id?'active':''} whitespace-nowrap">${tab.label}</button>
                `).join('')}
            </div>
            <div class="p-8">${tabContent[activeTab]||profileContent}</div>
        </div>
    `;
}

// ═══════════════════════════════════════════════════════════════
// PAGE: DASHBOARD
// ═══════════════════════════════════════════════════════════════
function renderHRDashboard() {
    const r = state.data.hrReports;
    const expiringContracts = state.data.contracts.filter(c=>c.renewalAlert==='Expiring Soon');
    const pendingLeaves     = state.data.leaves.filter(l=>l.status==='Pending');
    const onLeave           = state.data.employees.filter(e=>e.status==='On Leave');
    const todayAtt          = state.data.attendance.filter(a=>a.date==='2025-03-10');
    const presentToday      = todayAtt.filter(a=>a.status==='Present').length;
    const lateToday         = todayAtt.filter(a=>a.status==='Late').length;

    const kpis = [
        { label:_t('Total Employees','إجمالي الموظفين'), value:'25', delta:'+1 this month', icon:'users', color:'#a78bfa' },
        { label:_t('Present Today','حاضرون اليوم'), value:String(presentToday), delta:lateToday+' late', icon:'clipboard-check', color:'#34d399' },
        { label:_t('Payroll (MTD)','الرواتب (الشهر)'), value:'1.85M EGP', delta:'+2% vs Feb', icon:'wallet', color:'#38bdf8' },
        { label:_t('Open Positions','وظائف شاغرة'), value:String(r.openPositions), delta:r.timeToHire+' avg hire time', icon:'briefcase', color:'#fb923c' },
    ];

    const alertItems = [
        ...expiringContracts.map(c=>({ icon:'alert-triangle', color:'#fb923c', text:`${c.empName}'s contract expires ${c.endDate}`, action:()=>setPage('contracts') })),
        ...pendingLeaves.map(l=>({ icon:'calendar', color:'#38bdf8', text:`${l.empName} requesting ${l.type} leave (${l.days} days)`, action:()=>setPage('leaves') })),
        ...state.data.employees.filter(e=>state.data.performance.find(p=>p.empId===e.id&&p.status==='Pending Submission')).slice(0,2).map(e=>({ icon:'trending-up', color:'#a78bfa', text:`${e.name}'s performance review pending submission`, action:()=>setPage('performance') })),
    ].slice(0,6);

    const quickStats = [
        { label:_t('Avg Performance','متوسط الأداء'), value:'3.9/5', icon:'star', color:'#fbbf24' },
        { label:_t('Turnover Rate','معدل الدوران'), value:'8%', icon:'trending-down', color:'#f87171' },
        { label:_t('Training Hours','ساعات تدريب'), value:'14 avg', icon:'graduation-cap', color:'#34d399' },
        { label:_t('Offer Acceptance','قبول العروض'), value:'82%', icon:'check-circle', color:'#38bdf8' },
    ];

    return `
    <div class="fade-in space-y-8">
        <!-- KPIs -->
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6">
            ${kpis.map(k=>`
                <div class="stat-card bg-white dark:bg-slate-900 p-7 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                    <div class="flex items-center justify-between mb-4">
                        <div class="p-3 rounded-2xl" style="background:${k.color}20;color:${k.color}"><i data-lucide="${k.icon}" size="20"></i></div>
                        <span class="text-[10px] font-black text-slate-400">${k.delta}</span>
                    </div>
                    <p class="text-2xl md:text-3xl font-black text-mantiq-navy dark:text-white mb-1">${k.value}</p>
                    <p class="text-xs font-bold uppercase tracking-widest text-slate-500">${k.label}</p>
                </div>
            `).join('')}
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Alerts Panel -->
            <div class="lg:col-span-2 bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="font-black text-sm uppercase tracking-widest text-slate-800 dark:text-white flex items-center gap-2">
                        <i data-lucide="bell-ring" size="16" class="text-amber-500"></i>${_t('Action Required','يتطلب إجراء')}
                    </h3>
                    <span class="badge badge-red">${alertItems.length} ${_t('items','عناصر')}</span>
                </div>
                <div class="space-y-3">
                    ${alertItems.map(a=>`
                        <div onclick="${a.action.toString()}" class="flex items-start gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 hover:bg-amber-50 dark:hover:bg-amber-950/20 cursor-pointer transition-all border border-transparent hover:border-amber-200 dark:hover:border-amber-800">
                            <div class="p-2 rounded-xl flex-shrink-0" style="background:${a.color}20;color:${a.color}"><i data-lucide="${a.icon}" size="16"></i></div>
                            <p class="text-sm font-bold text-slate-700 dark:text-slate-200 flex-1">${a.text}</p>
                            <i data-lucide="chevron-right" size="16" class="text-slate-300 flex-shrink-0 mt-0.5 ${state.language==='ar'?'rotate-180':''}"></i>
                        </div>
                    `).join('')||`<p class="text-slate-400 italic text-sm">${_t('No alerts — all clear!','لا تنبيهات — كل شيء على ما يرام!')}</p>`}
                </div>
            </div>

            <!-- Quick Stats -->
            <div class="space-y-4">
                <div class="bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
                    <h3 class="font-black text-xs uppercase tracking-widest text-slate-400 mb-5">${_t('HR Health','صحة الموارد البشرية')}</h3>
                    <div class="space-y-4">
                        ${quickStats.map(s=>`
                            <div class="flex items-center gap-3">
                                <div class="p-2 rounded-xl" style="background:${s.color}20;color:${s.color}"><i data-lucide="${s.icon}" size="14"></i></div>
                                <div class="flex-1">
                                    <p class="text-xs font-bold text-slate-500 dark:text-slate-400">${s.label}</p>
                                    <p class="text-base font-black text-mantiq-navy dark:text-white">${s.value}</p>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
                <!-- Today attendance mini -->
                <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
                    <p class="text-[10px] font-black uppercase text-slate-400 mb-4">${_t("Today's Attendance","حضور اليوم")}</p>
                    <div class="grid grid-cols-3 gap-2 text-center">
                        <div class="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/30"><p class="text-xl font-black text-emerald-600">${presentToday}</p><p class="text-[8px] uppercase font-black text-emerald-500">${_t('Present','حاضر')}</p></div>
                        <div class="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30"><p class="text-xl font-black text-amber-500">${lateToday}</p><p class="text-[8px] uppercase font-black text-amber-500">${_t('Late','متأخر')}</p></div>
                        <div class="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/30"><p class="text-xl font-black text-rose-500">${todayAtt.filter(a=>a.status==='Absent').length}</p><p class="text-[8px] uppercase font-black text-rose-400">${_t('Absent','غائب')}</p></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Department overview -->
        <div class="bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
            <div class="flex justify-between items-center mb-6">
                <h3 class="font-black text-sm uppercase tracking-widest text-slate-800 dark:text-white">${_t('Department Overview','نظرة حسب الأقسام')}</h3>
                <button onclick="setPage('analytics')" class="text-[11px] font-black uppercase text-purple-500 flex items-center gap-1.5">${_t('Full Analytics','تحليلات كاملة')} <i data-lucide="${state.language==='ar'?'arrow-left':'arrow-right'}" size="12"></i></button>
            </div>
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
                ${Object.entries(state.data.hrReports.headcount.byDept).map(([dept,count])=>`
                    <div class="p-5 rounded-2xl border border-slate-100 dark:border-slate-800 card-hover cursor-pointer" onclick="state.hr.directoryDept='${dept}'; setPage('directory')">
                        <div class="flex items-center gap-2 mb-3">
                            <div class="w-3 h-3 rounded-full" style="background:${DEPT_COLORS[dept]||HR_COLOR}"></div>
                            <span class="text-xs font-black text-slate-600 dark:text-slate-300 uppercase">${dept}</span>
                        </div>
                        <p class="text-3xl font-black text-mantiq-navy dark:text-white">${count}</p>
                        <p class="text-[9px] text-slate-400 uppercase font-bold">${_t('employees','موظف')}</p>
                    </div>
                `).join('')}
            </div>
        </div>
    </div>`;
}

// ═══════════════════════════════════════════════════════════════
// PAGE: ANALYTICS
// ═══════════════════════════════════════════════════════════════
function renderHRAnalytics() {
    const perf = [
        { label:_t('Attendance Rate','معدل الحضور'), val:94, color:'#a78bfa' },
        { label:_t('Training Completion','إتمام التدريب'), val:71, color:'#34d399' },
        { label:_t('Performance Review Coverage','تغطية تقييم الأداء'), val:88, color:'#38bdf8' },
        { label:_t('Retention Rate','معدل الاستبقاء'), val:92, color:'#fb923c' },
        { label:_t('Offer Acceptance Rate','معدل قبول العروض'), val:82, color:'#f472b6' },
        { label:_t('Internal Promotion Rate','معدل الترقية الداخلية'), val:35, color:'#fbbf24' },
    ];
    return `
    <div class="fade-in space-y-8">
        <h2 class="text-xl md:text-3xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${_t('HR Analytics','تحليلات الموارد البشرية')}</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            ${[
                {id:'ch-headcount',title:_t('Headcount Trend','اتجاه عدد الموظفين')},
                {id:'ch-dept',title:_t('Employees by Department','الموظفين حسب القسم')},
                {id:'ch-attendance',title:_t('Weekly Attendance %','نسبة الحضور الأسبوعي')},
                {id:'ch-leave-types',title:_t('Leave Type Distribution','توزيع أنواع الإجازات')},
                {id:'ch-payroll-trend',title:_t('Monthly Payroll Cost (K EGP)','تكلفة الرواتب الشهرية')},
                {id:'ch-perf-dist',title:_t('Performance Score Distribution','توزيع نقاط الأداء')},
            ].map(c=>`
                <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
                    <h4 class="font-black text-xs uppercase tracking-widest text-slate-400 mb-5">${c.title}</h4>
                    <div><canvas id="${c.id}" data-chart></canvas></div>
                </div>
            `).join('')}
        </div>
        <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
            <h4 class="font-black text-sm uppercase tracking-widest text-slate-500 mb-8">${_t('Key HR Indicators','مؤشرات الموارد البشرية الرئيسية')}</h4>
            ${perf.map(p=>`
                <div class="mb-5">
                    <div class="flex justify-between mb-2"><span class="text-sm font-bold text-slate-700 dark:text-slate-200">${p.label}</span><span class="text-sm font-black" style="color:${p.color}">${p.val}%</span></div>
                    <div class="kpi-bar"><div class="kpi-bar-fill" style="width:${p.val}%;background:${p.color}"></div></div>
                </div>
            `).join('')}
        </div>
    </div>`;
}

// ═══════════════════════════════════════════════════════════════
// PAGE: DIRECTORY
// ═══════════════════════════════════════════════════════════════
function renderDirectory() {
    const hr = state.hr;
    let emps = [...state.data.employees];
    if(hr.directoryDept!=='All') emps=emps.filter(e=>e.dept===hr.directoryDept);
    if(hr.directoryFilter!=='All') emps=emps.filter(e=>e.status===hr.directoryFilter||e.contractType===hr.directoryFilter);
    if(hr.directorySearch) { const q=hr.directorySearch.toLowerCase(); emps=emps.filter(e=>e.name.toLowerCase().includes(q)||e.jobTitle.toLowerCase().includes(q)||e.id.toLowerCase().includes(q)); }

    const depts = ['All',...new Set(state.data.employees.map(e=>e.dept))];
    const filters = ['All','Active','On Leave','Inactive','Full-Time','Part-Time','Contractor'];

    const tableView = `
        <div class="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden overflow-x-auto custom-scrollbar">
            <table class="w-full text-left border-collapse">
                <thead class="bg-slate-50/70 dark:bg-slate-800/50 text-[10px] uppercase tracking-widest font-black text-slate-500">
                    <tr>${[_t('Employee','الموظف'),_t('Department','القسم'),_t('Job Title','المنصب'),_t('Phone','الهاتف'),_t('Contract','العقد'),_t('Hire Date','التعيين'),_t('Status','الحالة'),''].map(h=>`<th class="px-3 md:px-7 py-3 md:py-5 whitespace-nowrap">${h}</th>`).join('')}</tr>
                </thead>
                <tbody>
                    ${emps.map(e=>{
                        const dc=DEPT_COLORS[e.dept]||HR_COLOR;
                        return `
                        <tr class="group hover:bg-slate-50 dark:hover:bg-slate-800/20 border-b border-slate-50 dark:border-slate-800 last:border-0 cursor-pointer" onclick="openEmployee('${e.id}')">
                            <td class="px-7 py-5">
                                <div class="flex items-center gap-3">
                                    <div class="w-9 h-9 rounded-xl flex items-center justify-center font-black text-xs text-white shadow-sm" style="background:${dc}">${e.avatar}</div>
                                    <div><p class="text-sm font-black text-mantiq-navy dark:text-white">${e.name}</p><p class="text-[10px] text-slate-400">${e.id}</p></div>
                                </div>
                            </td>
                            <td class="px-7 py-5"><span class="text-xs font-black px-2 py-1 rounded-lg" style="background:${dc}20;color:${dc}">${e.dept}</span></td>
                            <td class="px-3 md:px-7 py-3 md:py-5 text-sm font-bold text-slate-600 dark:text-slate-300 whitespace-nowrap">${e.jobTitle}</td>
                            <td class="px-3 md:px-7 py-3 md:py-5 text-sm font-bold text-slate-500 whitespace-nowrap">${e.phone}</td>
                            <td class="px-7 py-5">${badgeHtml(e.contractType, CONTRACT_BADGE[e.contractType]||'badge-blue')}</td>
                            <td class="px-3 md:px-7 py-3 md:py-5 text-sm font-bold text-slate-500 whitespace-nowrap">${e.hireDate}</td>
                            <td class="px-7 py-5">${badgeHtml(e.status)}</td>
                            <td class="px-7 py-5">
                                <div class="flex gap-1.5 justify-end" onclick="event.stopPropagation()">
                                    <button onclick="openEmployee('${e.id}')" class="p-2 rounded-xl hover:bg-purple-50 dark:hover:bg-slate-700 transition-colors" style="color:${HR_COLOR}"><i data-lucide="user" size="15"></i></button>
                                    <button onclick="pushNotify('${_t('Email sent to ','تم إرسال بريد إلى ')}${e.name}')" class="p-2 rounded-xl hover:bg-sky-50 dark:hover:bg-slate-700 text-slate-400 hover:text-sky-500 transition-colors"><i data-lucide="mail" size="15"></i></button>
                                </div>
                            </td>
                        </tr>`;
                    }).join('')||`<tr><td colspan="8" class="py-20 text-center text-slate-400 italic">${_t('No employees found.','لا يوجد موظفون.')}</td></tr>`}
                </tbody>
            </table>
        </div>
    `;

    const cardsView = `
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            ${emps.map(e=>{
                const dc=DEPT_COLORS[e.dept]||HR_COLOR;
                const perf=state.data.performance.find(p=>p.empId===e.id);
                return `
                <div class="card-hover bg-white dark:bg-slate-900 rounded-[2rem] p-7 border border-slate-200 dark:border-slate-800 shadow-sm cursor-pointer" onclick="openEmployee('${e.id}')">
                    <div class="flex items-start justify-between mb-5">
                        <div class="flex items-center gap-3">
                            <div class="w-14 h-14 rounded-[1.5rem] flex items-center justify-center font-black text-xl text-white shadow-lg" style="background:${dc}">${e.avatar}</div>
                            <div>
                                <p class="font-black text-base text-mantiq-navy dark:text-white">${e.name}</p>
                                <p class="text-[10px] text-slate-400 font-bold">${e.jobTitle}</p>
                            </div>
                        </div>
                        ${badgeHtml(e.status)}
                    </div>
                    <div class="space-y-2 pt-4 border-t border-slate-100 dark:border-slate-800">
                        <div class="flex items-center gap-2 text-xs"><span class="font-black px-2 py-0.5 rounded-lg" style="background:${dc}20;color:${dc}">${e.dept}</span><span class="text-slate-400">${e.id}</span></div>
                        <div class="flex items-center gap-2 text-xs text-slate-500"><i data-lucide="phone" size="11"></i>${e.phone}</div>
                        <div class="flex items-center gap-2 text-xs text-mantiq-cyan truncate"><i data-lucide="mail" size="11"></i>${e.email}</div>
                        ${perf?`<div class="flex items-center gap-2 text-xs"><i data-lucide="star" size="11" style="color:#fbbf24"></i><span class="font-black" style="color:${scoreColor(perf.overallScore)}">${perf.overallScore}/5</span><span class="text-slate-400">${_t('Performance','أداء')}</span></div>`:''}
                    </div>
                </div>`;
            }).join('')||`<p class="col-span-3 py-20 text-center text-slate-400 italic">${_t('No employees found.','لا يوجد موظفون.')}</p>`}
        </div>
    `;

    return `
    <div class="fade-in space-y-6">
        <div class="flex flex-col sm:flex-row justify-between sm:items-center gap-3 md:gap-4">
            <div>
                <h2 class="text-xl md:text-3xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${_t('Employee Directory','دليل الموظفين')}</h2>
                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">${emps.length} ${_t('employees','موظف')}</p>
            </div>
            <div class="flex flex-wrap gap-3">
                <!-- View toggle -->
                <div class="flex bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm">
                    <button onclick="state.hr.directoryView='table'; render();" class="px-4 py-2.5 text-[10px] font-black uppercase transition-all ${hr.directoryView==='table'?'bg-mantiq-navy text-white':'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800'}">
                        <i data-lucide="list" size="14"></i>
                    </button>
                    <button onclick="state.hr.directoryView='cards'; render();" class="px-4 py-2.5 text-[10px] font-black uppercase transition-all ${hr.directoryView==='cards'?'bg-mantiq-navy text-white':'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800'}">
                        <i data-lucide="grid-3x3" size="14"></i>
                    </button>
                </div>
                <button onclick="pushNotify('${_t('Exporting...','تصدير...')}')" class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-5 py-2.5 rounded-2xl font-black text-xs text-slate-500 flex items-center gap-2 shadow-sm">
                    <i data-lucide="download" size="14"></i>${_t('Export','تصدير')}
                </button>
                <button onclick="state.isModalOpen=true; state.modalType='add_employee'; render();" class="bg-mantiq-navy dark:bg-white text-white dark:text-mantiq-navy px-7 py-2.5 rounded-2xl font-black text-xs shadow-xl flex items-center gap-2">
                    <i data-lucide="plus" size="14"></i>${_t('Add Employee','إضافة موظف')}
                </button>
            </div>
        </div>

        <!-- Filters -->
        <div class="flex flex-wrap gap-3 items-center">
            <div class="relative flex-1 min-w-[200px]">
                <i data-lucide="search" class="absolute ${state.language==='en'?'left-4':'right-4'} top-1/2 -translate-y-1/2 text-slate-400" size="15"></i>
                <input type="text" placeholder="${_t('Search by name, title, ID...','بحث بالاسم، المنصب، المعرف...')}"
                    oninput="state.hr.directorySearch=this.value; render();"
                    value="${hr.directorySearch}"
                    class="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 ${state.language==='en'?'pl-12':'pr-12'} px-4 py-3 rounded-2xl text-sm outline-none shadow-sm" />
            </div>
            <select onchange="state.hr.directoryDept=this.value; render();" class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-4 py-3 rounded-2xl text-xs font-bold outline-none shadow-sm">
                ${depts.map(d=>`<option value="${d}" ${hr.directoryDept===d?'selected':''}>${d}</option>`).join('')}
            </select>
            <select onchange="state.hr.directoryFilter=this.value; render();" class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-4 py-3 rounded-2xl text-xs font-bold outline-none shadow-sm">
                ${filters.map(f=>`<option value="${f}" ${hr.directoryFilter===f?'selected':''}>${f}</option>`).join('')}
            </select>
        </div>

        ${hr.directoryView==='cards' ? cardsView : tableView}
    </div>`;
}

// ═══════════════════════════════════════════════════════════════
// PAGE: ATTENDANCE
// ═══════════════════════════════════════════════════════════════
function renderAttendance() {
    const hr = state.hr;
    let records = [...state.data.attendance].filter(a=>a.date===hr.attendanceDate);
    if(hr.attendanceDept!=='All') records=records.filter(r=>r.dept===hr.attendanceDept);

    const depts = ['All',...new Set(state.data.employees.map(e=>e.dept))];
    const present = records.filter(r=>r.status==='Present').length;
    const late    = records.filter(r=>r.status==='Late').length;
    const absent  = records.filter(r=>r.status==='Absent').length;
    const totalOT = records.reduce((s,r)=>s+r.overtime,0).toFixed(1);

    const summaryTab = `
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            ${[
                {label:_t('Present','حاضر'),     val:present, color:'#34d399', icon:'check-circle'},
                {label:_t('Late','متأخر'),        val:late,    color:'#fb923c', icon:'clock'},
                {label:_t('Absent','غائب'),       val:absent,  color:'#f87171', icon:'x-circle'},
                {label:_t('Overtime Hours','ساعات إضافية'), val:totalOT+'h', color:'#38bdf8', icon:'timer'},
            ].map(s=>`
                <div class="bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-4">
                    <div class="p-3 rounded-xl flex-shrink-0" style="background:${s.color}20;color:${s.color}"><i data-lucide="${s.icon}" size="20"></i></div>
                    <div><p class="text-2xl font-black text-mantiq-navy dark:text-white">${s.val}</p><p class="text-[9px] font-black uppercase text-slate-400">${s.label}</p></div>
                </div>
            `).join('')}
        </div>
    `;

    const logTab = `
        <div class="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden overflow-x-auto custom-scrollbar">
            <table class="w-full text-left border-collapse">
                <thead class="bg-slate-50/70 dark:bg-slate-800/50 text-[10px] uppercase tracking-widest font-black text-slate-500">
                    <tr>${[_t('Employee','الموظف'),_t('Dept','القسم'),_t('Check In','دخول'),_t('Check Out','خروج'),_t('Hours','ساعات'),_t('Late','تأخر'),_t('Overtime','إضافي'),_t('Status','الحالة'),''].map(h=>`<th class="px-3 md:px-7 py-3 md:py-5 whitespace-nowrap">${h}</th>`).join('')}</tr>
                </thead>
                <tbody>
                    ${records.map(r=>`
                        <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/20 border-b border-slate-50 dark:border-slate-800 last:border-0">
                            <td class="px-7 py-5">
                                <div class="flex items-center gap-3">
                                    <div class="w-8 h-8 rounded-xl flex items-center justify-center font-black text-[10px] text-white flex-shrink-0" style="background:${DEPT_COLORS[r.dept]||HR_COLOR}">${r.empName.slice(0,2).toUpperCase()}</div>
                                    <div><p class="text-sm font-black text-mantiq-navy dark:text-white">${r.empName}</p><p class="text-[9px] text-slate-400">${r.empId}</p></div>
                                </div>
                            </td>
                            <td class="px-7 py-5"><span class="text-[10px] font-black px-2 py-1 rounded-lg" style="background:${DEPT_COLORS[r.dept]||HR_COLOR}20;color:${DEPT_COLORS[r.dept]||HR_COLOR}">${r.dept}</span></td>
                            <td class="px-3 md:px-7 py-3 md:py-5 font-bold text-sm text-slate-700 dark:text-slate-200 whitespace-nowrap">${r.checkIn||'—'}</td>
                            <td class="px-3 md:px-7 py-3 md:py-5 font-bold text-sm text-slate-700 dark:text-slate-200 whitespace-nowrap">${r.checkOut||'—'}</td>
                            <td class="px-3 md:px-7 py-3 md:py-5 font-black text-sm text-mantiq-navy dark:text-white">${r.workedHours}h</td>
                            <td class="px-3 md:px-7 py-3 md:py-5 whitespace-nowrap">
                                ${r.lateMinutes>0?`<span class="text-[10px] font-black text-amber-500 bg-amber-50 dark:bg-amber-950/30 px-2 py-1 rounded-lg">⚠ ${r.lateMinutes}m</span>`:'<span class="text-slate-300">—</span>'}
                            </td>
                            <td class="px-3 md:px-7 py-3 md:py-5 whitespace-nowrap">
                                ${r.overtime>0?`<span class="text-[10px] font-black text-blue-500 bg-blue-50 dark:bg-blue-950/30 px-2 py-1 rounded-lg">+${r.overtime}h</span>`:'<span class="text-slate-300">—</span>'}
                            </td>
                            <td class="px-7 py-5">${badgeHtml(r.status)}</td>
                            <td class="px-7 py-5">
                                <button onclick="pushNotify('${_t('Editing attendance record','تعديل سجل الحضور')}')" class="p-1.5 rounded-lg hover:bg-purple-50 dark:hover:bg-slate-700 transition-colors" style="color:${HR_COLOR}"><i data-lucide="edit-3" size="14"></i></button>
                            </td>
                        </tr>
                    `).join('')||`<tr><td colspan="9" class="py-20 text-center text-slate-400 italic">${_t('No records for this date.','لا توجد سجلات لهذا التاريخ.')}</td></tr>`}
                </tbody>
            </table>
        </div>
    `;

    // Overtime summary
    const overtimeEmps = records.filter(r=>r.overtime>0).sort((a,b)=>b.overtime-a.overtime);
    const overtimeTab = `
        <div class="bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
            <div class="flex justify-between items-center mb-6">
                <h3 class="font-black text-sm uppercase tracking-widest text-slate-500">${_t('Overtime Records','سجلات العمل الإضافي')} — ${hr.attendanceDate}</h3>
                <span class="badge badge-blue">${_t('Total:','الإجمالي:')} ${totalOT}h</span>
            </div>
            ${overtimeEmps.length ? `
            <div class="space-y-3">
                ${overtimeEmps.map(r=>`
                    <div class="flex items-center gap-4 p-4 bg-blue-50 dark:bg-blue-950/20 rounded-2xl border border-blue-100 dark:border-blue-900">
                        <div class="w-10 h-10 rounded-xl flex items-center justify-center font-black text-xs text-white" style="background:${DEPT_COLORS[r.dept]||HR_COLOR}">${r.empName.slice(0,2).toUpperCase()}</div>
                        <div class="flex-1">
                            <p class="font-black text-sm text-mantiq-navy dark:text-white">${r.empName}</p>
                            <p class="text-[10px] text-slate-400">${r.dept} · ${r.checkIn} – ${r.checkOut}</p>
                        </div>
                        <div class="text-right">
                            <p class="font-black text-lg text-blue-600">+${r.overtime}h</p>
                            <p class="text-[9px] text-slate-400 uppercase">${_t('overtime','إضافي')}</p>
                        </div>
                        <button onclick="pushNotify('${_t('Overtime approved for ','تمت الموافقة على إضافي ')}${r.empName}')" class="px-4 py-2 rounded-xl text-[10px] font-black uppercase text-white" style="background:${HR_COLOR}">${_t('Approve','موافقة')}</button>
                    </div>
                `).join('')}
            </div>` : `<p class="text-slate-400 italic">${_t('No overtime recorded.','لا يوجد عمل إضافي.')}</p>`}
        </div>
    `;

    const tabContent = { log:logTab, summary:summaryTab+logTab, overtime:overtimeTab };

    return `
    <div class="fade-in space-y-6">
        <div class="flex flex-col sm:flex-row justify-between sm:items-center gap-3 md:gap-4">
            <div>
                <h2 class="text-xl md:text-3xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${_t('Attendance','الحضور والانصراف')}</h2>
                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">${records.length} ${_t('records','سجل')}</p>
            </div>
            <div class="flex flex-wrap gap-3 items-center">
                <input type="date" value="${hr.attendanceDate}" onchange="state.hr.attendanceDate=this.value; render();" class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-4 py-2.5 rounded-2xl text-xs font-bold outline-none shadow-sm" />
                <select onchange="state.hr.attendanceDept=this.value; render();" class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-4 py-2.5 rounded-2xl text-xs font-bold outline-none shadow-sm">
                    ${depts.map(d=>`<option value="${d}" ${hr.attendanceDept===d?'selected':''}>${d}</option>`).join('')}
                </select>
                <button onclick="pushNotify('${_t('Exporting attendance...','تصدير الحضور...')}')" class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-5 py-2.5 rounded-2xl font-black text-xs text-slate-500 flex items-center gap-2 shadow-sm"><i data-lucide="download" size="14"></i>${_t('Export','تصدير')}</button>
                <button onclick="state.isModalOpen=true; state.modalType='add_attendance'; render();" class="bg-mantiq-navy dark:bg-white text-white dark:text-mantiq-navy px-7 py-2.5 rounded-2xl font-black text-xs shadow-xl flex items-center gap-2"><i data-lucide="plus" size="14"></i>${_t('Manual Entry','إدخال يدوي')}</button>
            </div>
        </div>

        <!-- Tabs -->
        <div class="flex gap-2 bg-white dark:bg-slate-900 p-2 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm w-fit">
            ${[{id:'summary',label:_t('Summary','ملخص')},{id:'log',label:_t('Full Log','السجل الكامل')},{id:'overtime',label:_t('Overtime','الإضافي')}].map(t=>`
                <button onclick="state.hr.attendanceTab='${t.id}'; render();" class="tab-pill ${hr.attendanceTab===t.id?'active':''}">${t.label}</button>
            `).join('')}
        </div>

        ${tabContent[hr.attendanceTab]||logTab}
    </div>`;
}

// ═══════════════════════════════════════════════════════════════
// PAGE: LEAVES
// ═══════════════════════════════════════════════════════════════
function renderLeaves() {
    const hr = state.hr;
    let requests = [...state.data.leaves];
    if(hr.leaveFilter!=='All') requests=requests.filter(l=>l.status===hr.leaveFilter||l.type===hr.leaveFilter);

    const pending  = state.data.leaves.filter(l=>l.status==='Pending');
    const approved = state.data.leaves.filter(l=>l.status==='Approved');
    const rejected = state.data.leaves.filter(l=>l.status==='Rejected');

    const requestsTab = `
        <div class="grid grid-cols-3 gap-2 md:gap-4 mb-4 md:mb-6">
            ${[{label:_t('Pending','معلق'),val:pending.length,color:'#fb923c',icon:'clock'},{label:_t('Approved','موافق عليه'),val:approved.length,color:'#34d399',icon:'check-circle'},{label:_t('Rejected','مرفوض'),val:rejected.length,color:'#f87171',icon:'x-circle'}].map(s=>`
                <div class="bg-white dark:bg-slate-900 p-5 rounded-[2rem] border border-slate-200 dark:border-slate-800 text-center shadow-sm stat-card cursor-pointer" onclick="state.hr.leaveFilter='${s.label.split(' ')[0]}'; render();">
                    <div class="p-3 rounded-xl inline-block mb-3" style="background:${s.color}20;color:${s.color}"><i data-lucide="${s.icon}" size="20"></i></div>
                    <p class="text-2xl font-black text-mantiq-navy dark:text-white">${s.val}</p>
                    <p class="text-[9px] font-black uppercase text-slate-400">${s.label}</p>
                </div>
            `).join('')}
        </div>
        <div class="space-y-3">
            ${requests.map(l=>{
                const emp = getEmp(l.empId);
                const ltColor = LEAVE_COLORS[l.type]||'#94a3b8';
                const isPending = l.status==='Pending';
                return `
                <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-6 border border-slate-200 dark:border-slate-800 shadow-sm card-hover">
                    <div class="flex flex-col md:flex-row md:items-center gap-4">
                        <div class="flex items-center gap-4 flex-1">
                            <div class="w-12 h-12 rounded-2xl flex items-center justify-center font-black text-sm text-white shadow-sm" style="background:${DEPT_COLORS[l.dept]||HR_COLOR}">${l.empName.slice(0,2).toUpperCase()}</div>
                            <div>
                                <p class="font-black text-base text-mantiq-navy dark:text-white">${l.empName}</p>
                                <p class="text-xs text-slate-400 font-bold">${l.dept} · ${l.id}</p>
                            </div>
                        </div>
                        <div class="flex-1">
                            <span class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-[10px] font-black text-white mb-2" style="background:${ltColor}">${l.type}</span>
                            <p class="text-sm font-bold text-mantiq-navy dark:text-white">${l.startDate} → ${l.endDate}</p>
                            <p class="text-xs text-slate-500">${l.days} ${_t('days','أيام')} · "${l.reason}"</p>
                        </div>
                        <div class="flex items-center gap-3">
                            ${badgeHtml(l.status)}
                            ${isPending ? `
                                <button onclick="const lv=state.data.leaves.find(x=>x.id==='${l.id}'); if(lv){lv.status='Approved';lv.approvedBy='HR Manager';} pushNotify('${_t('Leave approved for ','تمت الموافقة على إجازة ')}${l.empName}'); render();" 
                                    class="px-4 py-2 rounded-xl text-[10px] font-black uppercase text-white bg-emerald-500 hover:bg-emerald-600 transition-colors">${_t('Approve','موافقة')}</button>
                                <button onclick="const lv=state.data.leaves.find(x=>x.id==='${l.id}'); if(lv)lv.status='Rejected'; pushNotify('${_t('Leave rejected.','تم رفض الإجازة.')}'); render();"
                                    class="px-4 py-2 rounded-xl text-[10px] font-black uppercase text-rose-500 bg-rose-50 dark:bg-rose-950/30 hover:bg-rose-100 transition-colors">${_t('Reject','رفض')}</button>
                            ` : `${l.approvedBy?`<span class="text-[10px] text-slate-400">${_t('by','من')} ${l.approvedBy}</span>`:''}` }
                        </div>
                    </div>
                    ${l.comment?`<div class="mt-3 p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl text-xs text-slate-500 italic">"${l.comment}"</div>`:''}
                </div>`;
            }).join('')||`<p class="text-slate-400 italic text-center py-12">${_t('No leave requests match the filter.','لا توجد طلبات إجازة تطابق الفلتر.')}</p>`}
        </div>
    `;

    // Leave balances
    const balancesTab = `
        <div class="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden overflow-x-auto custom-scrollbar">
            <table class="w-full text-left border-collapse">
                <thead class="bg-slate-50/70 dark:bg-slate-800/50 text-[10px] uppercase tracking-widest font-black text-slate-500">
                    <tr>${[_t('Employee','الموظف'),_t('Annual Remaining','سنوية متبقية'),_t('Sick Remaining','مرضية متبقية'),_t('Emergency','طارئة'),_t('Used This Year','مستخدمة هذا العام'),''].map(h=>`<th class="px-3 md:px-7 py-3 md:py-5 whitespace-nowrap">${h}</th>`).join('')}</tr>
                </thead>
                <tbody>
                    ${state.data.employees.map(e=>{
                        const usedLeaves = state.data.leaves.filter(l=>l.empId===e.id&&l.status==='Approved').reduce((s,l)=>s+l.days,0);
                        return `
                        <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/20 border-b border-slate-50 dark:border-slate-800 last:border-0">
                            <td class="px-7 py-4">
                                <div class="flex items-center gap-3">
                                    <div class="w-8 h-8 rounded-xl flex items-center justify-center font-black text-[10px] text-white" style="background:${DEPT_COLORS[e.dept]||HR_COLOR}">${e.avatar}</div>
                                    <div><p class="text-sm font-black text-mantiq-navy dark:text-white">${e.name}</p><p class="text-[9px] text-slate-400">${e.dept}</p></div>
                                </div>
                            </td>
                            <td class="px-7 py-4">
                                <div class="flex items-center gap-2">
                                    <div class="kpi-bar w-24"><div class="kpi-bar-fill" style="width:${(e.leaveBalance.Annual/21)*100}%;background:#38bdf8"></div></div>
                                    <span class="text-sm font-black text-mantiq-navy dark:text-white">${e.leaveBalance.Annual}</span>
                                </div>
                            </td>
                            <td class="px-7 py-4 text-sm font-black text-mantiq-navy dark:text-white">${e.leaveBalance.Sick}</td>
                            <td class="px-7 py-4 text-sm font-black text-mantiq-navy dark:text-white">${e.leaveBalance.Emergency}</td>
                            <td class="px-7 py-4"><span class="text-sm font-black ${usedLeaves>15?'text-amber-500':'text-slate-500'}">${usedLeaves} ${_t('days','أيام')}</span></td>
                            <td class="px-7 py-4">
                                <button onclick="state.hr.leaveFormEmployee='${e.id}'; state.isModalOpen=true; state.modalType='request_leave'; render();" class="action-btn text-white text-[9px]" style="background:${HR_COLOR}">${_t('Request','طلب')}</button>
                            </td>
                        </tr>`;
                    }).join('')}
                </tbody>
            </table>
        </div>
    `;

    return `
    <div class="fade-in space-y-6">
        <div class="flex flex-col sm:flex-row justify-between sm:items-center gap-3 md:gap-4">
            <h2 class="text-xl md:text-3xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${_t('Leaves & Absences','الإجازات والغيابات')}</h2>
            <div class="flex gap-3">
                <select onchange="state.hr.leaveFilter=this.value; render();" class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-4 py-2.5 rounded-2xl text-xs font-bold outline-none shadow-sm">
                    ${['All','Pending','Approved','Rejected','Annual','Sick','Emergency','Maternity/Paternity','Unpaid'].map(f=>`<option value="${f}" ${hr.leaveFilter===f?'selected':''}>${f}</option>`).join('')}
                </select>
                <button onclick="state.isModalOpen=true; state.modalType='request_leave'; state.hr.leaveFormEmployee=''; render();" class="bg-mantiq-navy dark:bg-white text-white dark:text-mantiq-navy px-7 py-2.5 rounded-2xl font-black text-xs shadow-xl flex items-center gap-2"><i data-lucide="plus" size="14"></i>${_t('New Request','طلب جديد')}</button>
            </div>
        </div>
        <div class="flex gap-2 bg-white dark:bg-slate-900 p-2 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm w-fit">
            ${[{id:'requests',label:_t('Requests','الطلبات')},{id:'balances',label:_t('Balances','الأرصدة')}].map(t=>`
                <button onclick="state.hr.leaveTab='${t.id}'; render();" class="tab-pill ${hr.leaveTab===t.id?'active':''}">${t.label}</button>
            `).join('')}
        </div>
        ${hr.leaveTab==='balances' ? balancesTab : requestsTab}
    </div>`;
}

// ═══════════════════════════════════════════════════════════════
// PAGE: PAYROLL
// ═══════════════════════════════════════════════════════════════
function renderPayroll() {
    const hr = state.hr;
    const payrollData = state.data.payroll;
    const totalNet     = payrollData.reduce((s,p)=>s+p.netSalary,0);
    const totalGross   = payrollData.reduce((s,p)=>s+p.baseSalary+p.allowances+p.transport+p.mobile+p.bonus,0);
    const totalTax     = payrollData.reduce((s,p)=>s+p.incomeTax,0);
    const totalSI      = payrollData.reduce((s,p)=>s+p.socialInsurance,0);
    const pending      = payrollData.filter(p=>p.status==='Pending').length;

    const summaryTab = `
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            ${[
                {label:_t('Total Gross','الإجمالي الخام'),     val:formatCurrency(totalGross), color:'#38bdf8'},
                {label:_t('Total Net Paid','صافي المدفوع'),     val:formatCurrency(totalNet),  color:'#34d399'},
                {label:_t('Total Income Tax','ضريبة الدخل'),    val:formatCurrency(totalTax),  color:'#fb923c'},
                {label:_t('Soc. Insurance','تأمينات اجتماعية'),val:formatCurrency(totalSI),   color:'#a78bfa'},
            ].map(s=>`
                <div class="bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm stat-card">
                    <p class="text-[9px] font-black uppercase text-slate-400 mb-2">${s.label}</p>
                    <p class="text-xl font-black" style="color:${s.color}">${s.val}</p>
                </div>
            `).join('')}
        </div>
        ${pending>0?`<div class="p-4 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-2xl flex items-center gap-3 mb-6">
            <i data-lucide="alert-triangle" class="text-amber-500" size="18"></i>
            <p class="text-sm font-bold text-amber-700 dark:text-amber-300">${pending} ${_t('payroll records are pending processing. Review and approve to finalize.','سجلات رواتب معلقة. راجع واعتمد لإتمام الصرف.')}</p>
        </div>`:``}
        <div class="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden overflow-x-auto custom-scrollbar">
            <table class="w-full text-left border-collapse">
                <thead class="bg-slate-50/70 dark:bg-slate-800/50 text-[10px] uppercase tracking-widest font-black text-slate-500">
                    <tr>${[_t('Employee','الموظف'),_t('Department','القسم'),_t('Base','أساسي'),_t('Allowances','بدلات'),_t('Deductions','خصومات'),_t('Tax','ضريبة'),_t('SI','تأمينات'),_t('Net Salary','صافي الراتب'),_t('Method','طريقة'),_t('Status','الحالة'),''].map(h=>`<th class="px-3 md:px-6 py-3 md:py-5 whitespace-nowrap">${h}</th>`).join('')}</tr>
                </thead>
                <tbody>
                    ${payrollData.map(p=>{
                        const gross=p.baseSalary+p.allowances+p.transport+p.mobile+p.bonus;
                        return `
                        <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/20 border-b border-slate-50 dark:border-slate-800 last:border-0">
                            <td class="px-6 py-4">
                                <p class="text-sm font-black text-mantiq-navy dark:text-white">${p.empName}</p>
                                <p class="text-[9px] text-slate-400">${p.dept}</p>
                            </td>
                            <td class="px-6 py-4"><span class="text-[10px] font-black px-2 py-1 rounded-lg" style="background:${DEPT_COLORS[p.dept]||HR_COLOR}20;color:${DEPT_COLORS[p.dept]||HR_COLOR}">${p.dept}</span></td>
                            <td class="px-3 md:px-6 py-3 md:py-4 text-sm font-bold text-slate-700 dark:text-slate-200 whitespace-nowrap">${formatCurrency(p.baseSalary)}</td>
                            <td class="px-3 md:px-6 py-3 md:py-4 text-sm font-bold text-emerald-600 whitespace-nowrap">+${formatCurrency(p.allowances+p.transport+p.mobile+(p.bonus||0))}</td>
                            <td class="px-3 md:px-6 py-3 md:py-4 text-sm font-bold text-rose-500 whitespace-nowrap">-${formatCurrency(p.deductions)}</td>
                            <td class="px-3 md:px-6 py-3 md:py-4 text-sm font-bold text-amber-500 whitespace-nowrap">-${formatCurrency(p.incomeTax)}</td>
                            <td class="px-3 md:px-6 py-3 md:py-4 text-sm font-bold text-slate-500 whitespace-nowrap">-${formatCurrency(p.socialInsurance)}</td>
                            <td class="px-3 md:px-6 py-3 md:py-4 font-black text-mantiq-navy dark:text-white whitespace-nowrap text-base">${formatCurrency(p.netSalary)}</td>
                            <td class="px-3 md:px-6 py-3 md:py-4 text-xs font-bold text-slate-500 whitespace-nowrap">${p.paymentMethod}</td>
                            <td class="px-6 py-4">${badgeHtml(p.status)}</td>
                            <td class="px-6 py-4">
                                <div class="flex gap-1.5">
                                    ${p.status==='Pending'?`<button onclick="const pr=state.data.payroll.find(x=>x.id==='${p.id}'); if(pr){pr.status='Processed';pr.slipGenerated=true;pr.processedDate='2025-03-28';} pushNotify('${_t('Payroll processed for ','تم صرف راتب ')}${p.empName}'); render();" class="action-btn text-white text-[8px]" style="background:#34d399">${_t('Process','صرف')}</button>`:''}
                                    <button onclick="pushNotify('${_t('Generating payslip PDF...','إنشاء قسيمة PDF...')}')" class="p-1.5 rounded-lg hover:bg-purple-50 dark:hover:bg-slate-700" style="color:${HR_COLOR}"><i data-lucide="receipt" size="14"></i></button>
                                </div>
                            </td>
                        </tr>`;
                    }).join('')}
                </tbody>
            </table>
        </div>
    `;

    return `
    <div class="fade-in space-y-6">
        <div class="flex flex-col sm:flex-row justify-between sm:items-center gap-3 md:gap-4">
            <div>
                <h2 class="text-xl md:text-3xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${_t('Payroll','الرواتب')}</h2>
                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">${hr.payrollMonth}</p>
            </div>
            <div class="flex gap-3">
                <select onchange="state.hr.payrollMonth=this.value; render();" class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-4 py-2.5 rounded-2xl text-xs font-bold outline-none shadow-sm">
                    ${['March 2025','February 2025','January 2025','December 2024'].map(m=>`<option ${hr.payrollMonth===m?'selected':''}>${m}</option>`).join('')}
                </select>
                <button onclick="pushNotify('${_t('Bulk payroll run initiated...','بدء تشغيل الرواتب الدفعي...')}')" class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-5 py-2.5 rounded-2xl font-black text-xs text-slate-500 flex items-center gap-2 shadow-sm"><i data-lucide="play-circle" size="14"></i>${_t('Run Payroll','تشغيل الرواتب')}</button>
                <button onclick="pushNotify('${_t('Exporting payroll...','تصدير الرواتب...')}')" class="bg-mantiq-navy dark:bg-white text-white dark:text-mantiq-navy px-7 py-2.5 rounded-2xl font-black text-xs shadow-xl flex items-center gap-2"><i data-lucide="download" size="14"></i>${_t('Export','تصدير')}</button>
            </div>
        </div>
        ${summaryTab}
    </div>`;
}

// ═══════════════════════════════════════════════════════════════
// PAGE: CONTRACTS
// ═══════════════════════════════════════════════════════════════
function renderContracts() {
    const hr = state.hr;
    let contracts = [...state.data.contracts];
    if(hr.contractFilter!=='All') contracts=contracts.filter(c=>c.type===hr.contractFilter||c.status===hr.contractFilter||c.renewalAlert===hr.contractFilter);
    if(hr.contractSearch){ const q=hr.contractSearch.toLowerCase(); contracts=contracts.filter(c=>c.empName.toLowerCase().includes(q)||c.id.toLowerCase().includes(q)); }

    const expiringSoon = state.data.contracts.filter(c=>c.renewalAlert==='Expiring Soon');

    return `
    <div class="fade-in space-y-6">
        <div class="flex flex-col sm:flex-row justify-between sm:items-center gap-3 md:gap-4">
            <div>
                <h2 class="text-xl md:text-3xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${_t('Contracts','العقود')}</h2>
                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">${contracts.length} ${_t('contracts','عقود')}</p>
            </div>
            <div class="flex gap-3">
                <button onclick="state.isModalOpen=true; state.modalType='add_contract'; render();" class="bg-mantiq-navy dark:bg-white text-white dark:text-mantiq-navy px-7 py-2.5 rounded-2xl font-black text-xs shadow-xl flex items-center gap-2"><i data-lucide="plus" size="14"></i>${_t('New Contract','عقد جديد')}</button>
            </div>
        </div>

        ${expiringSoon.length?`
        <div class="p-5 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 rounded-[2rem]">
            <div class="flex items-center gap-2 mb-4"><i data-lucide="alert-triangle" class="text-amber-500" size="18"></i><p class="font-black text-sm text-amber-700 dark:text-amber-300 uppercase">${_t('Contracts Expiring Within 30 Days','عقود تنتهي خلال 30 يومًا')}</p></div>
            <div class="flex flex-wrap gap-3">
                ${expiringSoon.map(c=>`
                    <div class="flex items-center gap-3 bg-white dark:bg-slate-900 px-4 py-3 rounded-2xl border border-amber-200 dark:border-amber-800">
                        <div class="w-8 h-8 rounded-xl flex items-center justify-center font-black text-xs text-white" style="background:${DEPT_COLORS[c.dept]||HR_COLOR}">${c.empName.slice(0,2).toUpperCase()}</div>
                        <div><p class="text-xs font-black text-mantiq-navy dark:text-white">${c.empName}</p><p class="text-[9px] text-amber-600 font-bold">${_t('Expires:','ينتهي:')} ${c.endDate}</p></div>
                        <button onclick="pushNotify('${_t('Renewal process started for ','بدء تجديد عقد ')}${c.empName}')" class="text-[9px] font-black uppercase px-3 py-1.5 rounded-xl text-white" style="background:#fb923c">${_t('Renew','تجديد')}</button>
                    </div>
                `).join('')}
            </div>
        </div>` : ''}

        <!-- Filters -->
        <div class="flex flex-wrap gap-3">
            <div class="relative flex-1 min-w-[200px]">
                <i data-lucide="search" class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size="15"></i>
                <input type="text" placeholder="${_t('Search employee or contract ID...','بحث باسم موظف أو رقم عقد...')}" oninput="state.hr.contractSearch=this.value; render();" value="${hr.contractSearch}" class="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 pl-12 px-4 py-3 rounded-2xl text-sm outline-none shadow-sm" />
            </div>
            <select onchange="state.hr.contractFilter=this.value; render();" class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-4 py-3 rounded-2xl text-xs font-bold outline-none shadow-sm">
                ${['All','Full-Time','Part-Time','Contractor','Internship','Active','Expired','Expiring Soon'].map(f=>`<option value="${f}" ${hr.contractFilter===f?'selected':''}>${f}</option>`).join('')}
            </select>
        </div>

        <div class="bg-white dark:bg-slate-900 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden overflow-x-auto custom-scrollbar">
            <table class="w-full text-left border-collapse">
                <thead class="bg-slate-50/70 dark:bg-slate-800/50 text-[10px] uppercase tracking-widest font-black text-slate-500">
                    <tr>${[_t('Contract ID','رقم العقد'),_t('Employee','الموظف'),_t('Type','النوع'),_t('Start Date','البداية'),_t('End Date','النهاية'),_t('Notice Period','فترة إشعار'),_t('Alert','تنبيه'),_t('Status','الحالة'),''].map(h=>`<th class="px-3 md:px-7 py-3 md:py-5 whitespace-nowrap">${h}</th>`).join('')}</tr>
                </thead>
                <tbody>
                    ${contracts.map(c=>{
                        const days = c.endDate ? daysUntil(c.endDate) : null;
                        return `
                        <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/20 border-b border-slate-50 dark:border-slate-800 last:border-0">
                            <td class="px-3 md:px-7 py-3 md:py-5 text-sm font-black text-slate-500">${c.id}</td>
                            <td class="px-7 py-5">
                                <div class="flex items-center gap-3">
                                    <div class="w-9 h-9 rounded-xl flex items-center justify-center font-black text-[10px] text-white" style="background:${DEPT_COLORS[c.dept]||HR_COLOR}">${c.empName.slice(0,2).toUpperCase()}</div>
                                    <div><p class="text-sm font-black text-mantiq-navy dark:text-white">${c.empName}</p><p class="text-[9px] text-slate-400">${c.dept}</p></div>
                                </div>
                            </td>
                            <td class="px-7 py-5">${badgeHtml(c.type, CONTRACT_BADGE[c.type]||'badge-blue')}</td>
                            <td class="px-3 md:px-7 py-3 md:py-5 text-sm font-bold text-slate-600 dark:text-slate-300 whitespace-nowrap">${c.startDate}</td>
                            <td class="px-3 md:px-7 py-3 md:py-5 text-sm font-bold whitespace-nowrap ${days!==null&&days<30?'text-amber-500 font-black':' text-slate-600 dark:text-slate-300'}">${c.endDate||_t('Permanent','دائم')}</td>
                            <td class="px-3 md:px-7 py-3 md:py-5 text-sm font-bold text-slate-500 whitespace-nowrap">${c.noticePeriod}</td>
                            <td class="px-7 py-5">${days!==null?badgeHtml(days<30?'Expiring Soon':'Active'):badgeHtml('Permanent','badge-green')}</td>
                            <td class="px-7 py-5">${badgeHtml(c.status)}</td>
                            <td class="px-7 py-5">
                                <div class="flex gap-1.5">
                                    <button onclick="pushNotify('${_t('Opening contract...','فتح العقد...')}')" class="p-1.5 rounded-lg hover:bg-sky-50 dark:hover:bg-slate-700 text-sky-500 transition-colors"><i data-lucide="eye" size="14"></i></button>
                                    ${c.endDate&&days<30?`<button onclick="pushNotify('${_t('Renewal initiated for ','بدء تجديد ')}${c.empName}')" class="action-btn text-white text-[8px]" style="background:#fb923c">${_t('Renew','تجديد')}</button>`:''}
                                </div>
                            </td>
                        </tr>`;
                    }).join('')||`<tr><td colspan="9" class="py-20 text-center text-slate-400 italic">${_t('No contracts found.','لا توجد عقود.')}</td></tr>`}
                </tbody>
            </table>
        </div>
    </div>`;
}

// ═══════════════════════════════════════════════════════════════
// PAGE: RECRUITMENT
// ═══════════════════════════════════════════════════════════════
function renderRecruitment() {
    const applications = state.data.recruitment;

    // Summary
    const totalApps = applications.length;
    const totalHired = applications.filter(a=>a.stage==='hired').length;
    const inProgress = applications.filter(a=>!['hired','rejected'].includes(a.stage)).length;

    // Kanban
    const board = RECRUIT_STAGES.map(stage=>{
        const cards = applications.filter(a=>a.stage===stage.id);
        const isDark = state.darkMode;
        const bg = isDark ? `rgba(${stage.color.slice(1).match(/.{2}/g).map(x=>parseInt(x,16)).join(',')},0.08)` : `rgba(${stage.color.slice(1).match(/.{2}/g).map(x=>parseInt(x,16)).join(',')},0.07)`;
        return `
            <div class="kanban-col">
                <div class="kanban-col-header" style="background:${bg};color:${stage.color}">
                    <div class="flex items-center gap-2"><i data-lucide="${stage.icon}" size="13"></i>${_t(stage.label.en,stage.label.ar)}</div>
                    <span class="w-5 h-5 flex items-center justify-center rounded-full text-white text-[9px] font-black" style="background:${stage.color}">${cards.length}</span>
                </div>
                ${cards.map(app=>{
                    const nextStage = RECRUIT_STAGES[RECRUIT_STAGES.findIndex(s=>s.id===app.stage)+1];
                    return `
                    <div class="kanban-card">
                        <div class="flex items-start justify-between mb-2">
                            <div>
                                <p class="font-black text-sm text-mantiq-navy dark:text-white leading-tight">${app.name}</p>
                                <p class="text-[10px] text-slate-400 font-bold">${app.position}</p>
                            </div>
                            <span class="text-[9px] font-black px-2 py-0.5 rounded-lg" style="background:${DEPT_COLORS[app.dept]||HR_COLOR}20;color:${DEPT_COLORS[app.dept]||HR_COLOR}">${app.dept}</span>
                        </div>
                        <div class="text-[10px] text-slate-500 space-y-1 mb-3">
                            <div class="flex justify-between"><span>${app.source}</span><span class="font-black" style="color:${app.score>=80?'#34d399':app.score>=60?'#fb923c':'#f87171'}">${app.score}/100</span></div>
                            <div>${app.experience} · ${app.salary_expect}</div>
                            ${app.interviewDate?`<div class="font-bold text-purple-500">📅 ${app.interviewDate}</div>`:''}
                        </div>
                        <div class="flex gap-1.5">
                            ${nextStage&&!['hired','rejected'].includes(app.stage)?`
                                <button onclick="const a=state.data.recruitment.find(x=>x.id==='${app.id}'); if(a)a.stage='${nextStage.id}'; pushNotify('${app.name} → ${_t(nextStage.label.en,nextStage.label.ar)}'); render();"
                                    class="flex-1 text-[9px] font-black uppercase py-2 rounded-xl text-white transition-colors" style="background:${nextStage.color}">
                                    ${_t(nextStage.label.en,nextStage.label.ar)} →
                                </button>
                            `:''}
                            ${!['rejected','hired'].includes(app.stage)?`
                                <button onclick="const a=state.data.recruitment.find(x=>x.id==='${app.id}'); if(a)a.stage='rejected'; pushNotify('${app.name} ${_t('rejected.','مرفوض.')}'); render();"
                                    class="p-2 rounded-xl text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors text-[9px]">
                                    <i data-lucide="x" size="12"></i>
                                </button>
                            `:''}
                        </div>
                    </div>`;
                }).join('')||`<div class="text-center py-8 text-slate-300 dark:text-slate-700 text-[10px] font-black uppercase">${_t('Empty','فارغ')}</div>`}
            </div>
        `;
    }).join('');

    return `
    <div class="fade-in space-y-6">
        <div class="flex flex-col sm:flex-row justify-between sm:items-center gap-3 md:gap-4">
            <div>
                <h2 class="text-xl md:text-3xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${_t('Recruitment Pipeline','مسار التوظيف')}</h2>
                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">${totalApps} ${_t('applicants','متقدم')} · ${inProgress} ${_t('in progress','في المسار')} · ${totalHired} ${_t('hired','تم تعيينهم')}</p>
            </div>
            <button onclick="state.isModalOpen=true; state.modalType='add_applicant'; render();" class="bg-mantiq-navy dark:bg-white text-white dark:text-mantiq-navy px-7 py-2.5 rounded-2xl font-black text-xs shadow-xl flex items-center gap-2 self-start">
                <i data-lucide="plus" size="14"></i>${_t('Add Applicant','إضافة متقدم')}
            </button>
        </div>
        <!-- Summary badges -->
        <div class="flex flex-wrap gap-3">
            ${RECRUIT_STAGES.map(s=>`
                <div class="flex items-center gap-2 px-4 py-2.5 rounded-2xl border text-xs font-black" style="border-color:${s.color}30;background:rgba(${s.color.slice(1).match(/.{2}/g).map(x=>parseInt(x,16)).join(',')},0.07);color:${s.color}">
                    <i data-lucide="${s.icon}" size="13"></i>${_t(s.label.en,s.label.ar)}
                    <span class="px-1.5 py-0.5 rounded-full text-white text-[9px]" style="background:${s.color}">${applications.filter(a=>a.stage===s.id).length}</span>
                </div>
            `).join('')}
        </div>
        <div class="kanban-board">${board}</div>
    </div>`;
}

// ═══════════════════════════════════════════════════════════════
// PAGE: PERFORMANCE
// ═══════════════════════════════════════════════════════════════
function renderPerformance() {
    const hr = state.hr;
    const reviews = state.data.performance.filter(p=>p.period===hr.performancePeriod);

    const reviewsTab = `
        <div class="grid grid-cols-3 gap-2 md:gap-4 mb-4 md:mb-6">
            ${[
                {label:_t('Completed','مكتملة'), val:reviews.filter(r=>r.status==='Completed').length, color:'#34d399'},
                {label:_t('Under Review','قيد المراجعة'), val:reviews.filter(r=>r.status==='Under Review').length, color:'#38bdf8'},
                {label:_t('Pending Submission','لم يُرسل بعد'), val:reviews.filter(r=>r.status==='Pending Submission').length, color:'#fb923c'},
            ].map(s=>`
                <div class="bg-white dark:bg-slate-900 p-5 rounded-[2rem] border border-slate-200 dark:border-slate-800 text-center shadow-sm stat-card">
                    <p class="text-2xl font-black mb-1" style="color:${s.color}">${s.val}</p>
                    <p class="text-[9px] font-black uppercase text-slate-400">${s.label}</p>
                </div>
            `).join('')}
        </div>
        <div class="space-y-3">
            ${reviews.map(p=>`
                <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-6 border border-slate-200 dark:border-slate-800 shadow-sm card-hover">
                    <div class="flex flex-col md:flex-row md:items-center gap-4">
                        <div class="flex items-center gap-4 flex-1">
                            <div class="w-14 h-14 rounded-[1.5rem] flex items-center justify-center font-black text-base text-white shadow-lg" style="background:${scoreColor(p.overallScore)}">${p.overallScore}</div>
                            <div>
                                <p class="font-black text-base text-mantiq-navy dark:text-white">${p.empName}</p>
                                <p class="text-xs text-slate-400 font-bold">${p.dept} · ${_t('Reviewer:','المقيم:')} ${p.reviewer}</p>
                            </div>
                        </div>
                        <div class="flex-1 space-y-1.5">
                            ${[['KPI',p.kpiScore],['Attitude',p.attitudeScore],['Teamwork',p.teamworkScore]].map(([l,v])=>`
                                <div class="flex items-center gap-2">
                                    <span class="text-[9px] font-black uppercase text-slate-400 w-16">${l}</span>
                                    <div class="flex-1 kpi-bar"><div class="kpi-bar-fill" style="width:${parseFloat(v)/5*100}%;background:${scoreColor(v)}"></div></div>
                                    <span class="text-[10px] font-black w-6 text-right" style="color:${scoreColor(v)}">${v}</span>
                                </div>
                            `).join('')}
                        </div>
                        <div class="flex flex-col items-end gap-2">
                            ${badgeHtml(p.status)}
                            ${p.status!=='Completed'?`<button onclick="const pr=state.data.performance.find(x=>x.id==='${p.id}'); if(pr)pr.status='Completed'; pushNotify('Review completed for ${p.empName}'); render();" class="action-btn text-white text-[9px]" style="background:${HR_COLOR}">${_t('Mark Done','إتمام')}</button>`:''}
                        </div>
                    </div>
                    <div class="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800">
                        <div class="grid grid-cols-2 gap-4 text-xs">
                            <div><p class="font-black text-slate-400 uppercase mb-1">${_t('Strengths','نقاط القوة')}</p><p class="text-slate-600 dark:text-slate-300">${p.strengths}</p></div>
                            <div><p class="font-black text-slate-400 uppercase mb-1">${_t('Areas to Improve','مجالات التحسين')}</p><p class="text-slate-600 dark:text-slate-300">${p.improvements}</p></div>
                        </div>
                        <p class="text-xs text-slate-400 italic mt-3">"${p.managerComment}"</p>
                    </div>
                </div>
            `).join('')}
        </div>
    `;

    return `
    <div class="fade-in space-y-6">
        <div class="flex flex-col sm:flex-row justify-between sm:items-center gap-3 md:gap-4">
            <div>
                <h2 class="text-xl md:text-3xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${_t('Performance Reviews','تقييمات الأداء')}</h2>
                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">${hr.performancePeriod}</p>
            </div>
            <div class="flex gap-3">
                <select onchange="state.hr.performancePeriod=this.value; render();" class="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-4 py-2.5 rounded-2xl text-xs font-bold outline-none shadow-sm">
                    ${['Q1 2025','Q4 2024','Q3 2024','Annual 2024'].map(p=>`<option ${hr.performancePeriod===p?'selected':''}>${p}</option>`).join('')}
                </select>
                <button onclick="state.isModalOpen=true; state.modalType='new_review'; render();" class="bg-mantiq-navy dark:bg-white text-white dark:text-mantiq-navy px-7 py-2.5 rounded-2xl font-black text-xs shadow-xl flex items-center gap-2"><i data-lucide="plus" size="14"></i>${_t('New Review','تقييم جديد')}</button>
            </div>
        </div>
        ${reviewsTab}
    </div>`;
}

// ═══════════════════════════════════════════════════════════════
// PAGE: TRAINING
// ═══════════════════════════════════════════════════════════════
function renderTraining() {
    const hr = state.hr;
    const courses = state.data.training;
    const totalCost = courses.reduce((s,t)=>s+t.cost,0);
    const totalHours = courses.reduce((s,t)=>s+t.hours*t.enrollees,0);

    return `
    <div class="fade-in space-y-6">
        <div class="flex flex-col sm:flex-row justify-between sm:items-center gap-3 md:gap-4">
            <div>
                <h2 class="text-xl md:text-3xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${_t('Training & Development','التدريب والتطوير')}</h2>
                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">${courses.length} ${_t('programs','برنامج')} · ${formatCurrency(totalCost)} ${_t('total budget','إجمالي الميزانية')}</p>
            </div>
            <button onclick="state.isModalOpen=true; state.modalType='add_training'; render();" class="bg-mantiq-navy dark:bg-white text-white dark:text-mantiq-navy px-7 py-2.5 rounded-2xl font-black text-xs shadow-xl flex items-center gap-2 self-start">
                <i data-lucide="plus" size="14"></i>${_t('Add Course','إضافة دورة')}
            </button>
        </div>

        <!-- Summary cards -->
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
            ${[
                {label:_t('Total Courses','إجمالي الدورات'),      val:courses.length,           color:'#a78bfa', icon:'book-open'},
                {label:_t('Completed','مكتملة'),                   val:courses.filter(t=>t.status==='Completed').length, color:'#34d399', icon:'check-circle'},
                {label:_t('In Progress','جارية'),                  val:courses.filter(t=>t.status==='In Progress').length, color:'#38bdf8', icon:'play-circle'},
                {label:_t('Training Budget Used','ميزانية التدريب'), val:formatCurrency(totalCost), color:'#fb923c', icon:'dollar-sign'},
            ].map(s=>`
                <div class="stat-card bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                    <div class="flex items-center gap-3 mb-3"><div class="p-2 rounded-xl" style="background:${s.color}20;color:${s.color}"><i data-lucide="${s.icon}" size="18"></i></div></div>
                    <p class="text-2xl font-black text-mantiq-navy dark:text-white mb-1">${s.val}</p>
                    <p class="text-[9px] font-black uppercase text-slate-400">${s.label}</p>
                </div>
            `).join('')}
        </div>

        <!-- Course cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
            ${courses.map(t=>{
                const completionPct = t.enrollees>0 ? Math.round((t.completed/t.enrollees)*100) : 0;
                const statusColor = t.status==='Completed'?'#34d399':t.status==='In Progress'?'#38bdf8':'#94a3b8';
                return `
                <div class="card-hover bg-white dark:bg-slate-900 p-7 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                    <div class="flex items-start justify-between mb-4">
                        <div class="flex-1">
                            <div class="flex items-center gap-2 mb-1">
                                ${badgeHtml(t.status)}
                                ${t.cert?`<span class="badge badge-amber">Cert</span>`:''}
                                <span class="badge badge-slate">${t.mode}</span>
                            </div>
                            <h4 class="font-black text-base text-mantiq-navy dark:text-white mt-2">${t.name}</h4>
                            <p class="text-xs text-slate-400 font-bold">${t.provider}</p>
                        </div>
                        <div class="text-right flex-shrink-0">
                            <p class="text-xl font-black" style="color:${statusColor}">${completionPct}%</p>
                            <p class="text-[9px] text-slate-400 uppercase">${_t('Completion','إتمام')}</p>
                        </div>
                    </div>
                    <div class="kpi-bar mb-4"><div class="kpi-bar-fill" style="width:${completionPct}%;background:${statusColor}"></div></div>
                    <div class="grid grid-cols-3 gap-3 text-center pt-4 border-t border-slate-100 dark:border-slate-800">
                        <div><p class="text-sm font-black text-mantiq-navy dark:text-white">${t.enrollees}</p><p class="text-[8px] uppercase text-slate-400">${_t('Enrolled','مسجلون')}</p></div>
                        <div><p class="text-sm font-black text-mantiq-navy dark:text-white">${t.hours}h</p><p class="text-[8px] uppercase text-slate-400">${_t('Duration','المدة')}</p></div>
                        <div><p class="text-sm font-black ${t.cost>0?'text-amber-500':'text-emerald-500'}">${t.cost>0?formatCurrency(t.cost):_t('Free','مجاني')}</p><p class="text-[8px] uppercase text-slate-400">${_t('Cost','التكلفة')}</p></div>
                    </div>
                    <div class="flex justify-between items-center mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-[9px] text-slate-400 font-bold">
                        <span>${t.startDate} → ${t.endDate}</span>
                        <button onclick="pushNotify('${_t('Opening enrollment list...','فتح قائمة المسجلين...')}')" class="text-purple-500 font-black hover:underline">${_t('View Enrollees','عرض المسجلين')}</button>
                    </div>
                </div>`;
            }).join('')}
        </div>
    </div>`;
}

// ═══════════════════════════════════════════════════════════════
// PAGE: HR REPORTS
// ═══════════════════════════════════════════════════════════════
function renderReports() {
    const r = state.data.hrReports;
    const metrics = [
        {label:_t('Total Headcount','إجمالي الموظفين'),         val:r.headcount.current,   target:r.headcount.target, unit:'',    color:'#a78bfa'},
        {label:_t('Monthly Payroll Cost','تكلفة الرواتب'),      val:'1.85M',                 target:'2M',               unit:' EGP',color:'#38bdf8'},
        {label:_t('Turnover Rate','معدل الدوران'),               val:r.turnover.rate,         target:'< 10%',            unit:'',    color:'#f87171'},
        {label:_t('Time to Hire','وقت التوظيف'),                 val:r.timeToHire,            target:'< 21 days',        unit:'',    color:'#fb923c'},
        {label:_t('Offer Acceptance','قبول العروض'),             val:r.offerAcceptance,       target:'> 80%',            unit:'',    color:'#34d399'},
        {label:_t('Avg Training Hrs/Employee','متوسط ساعات التدريب'), val:r.trainingHoursAvg, target:'16h',              unit:'h',   color:'#818cf8'},
        {label:_t('Absenteeism Rate','معدل الغياب'),             val:r.absenteeism,           target:'< 5%',             unit:'',    color:'#fbbf24'},
        {label:_t('Open Positions','وظائف شاغرة'),              val:r.openPositions,         target:'0',                unit:'',    color:'#f472b6'},
    ];

    return `
    <div class="fade-in space-y-8">
        <h2 class="text-xl md:text-3xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${_t('HR Reports & KPIs','تقارير ومؤشرات الموارد البشرية')}</h2>

        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
            ${metrics.map(m=>`
                <div class="stat-card bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                    <p class="text-[9px] font-black uppercase text-slate-400 mb-2">${m.label}</p>
                    <p class="text-2xl font-black mb-1" style="color:${m.color}">${m.val}${m.unit}</p>
                    <p class="text-[9px] text-slate-400">${_t('Target:','الهدف:')} ${m.target}</p>
                </div>
            `).join('')}
        </div>

        <!-- Analytics charts for reports -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
                <h4 class="font-black text-xs uppercase tracking-widest text-slate-500 mb-5">${_t('Headcount Trend','اتجاه عدد الموظفين')}</h4>
                <canvas id="ch-headcount-r" data-chart></canvas>
            </div>
            <div class="bg-white dark:bg-slate-900 rounded-[2rem] p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
                <h4 class="font-black text-xs uppercase tracking-widest text-slate-500 mb-5">${_t('Payroll Cost (K EGP)','تكلفة الرواتب (ألف ج.م)')}</h4>
                <canvas id="ch-payroll-r" data-chart></canvas>
            </div>
        </div>

        <!-- Dept headcount table -->
        <div class="bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
            <h3 class="font-black text-sm uppercase tracking-widest text-slate-500 mb-6">${_t('Department Breakdown','تفصيل الأقسام')}</h3>
            <div class="space-y-4">
                ${Object.entries(r.headcount.byDept).map(([dept,count])=>{
                    const pct = Math.round((count/r.headcount.current)*100);
                    const dc = DEPT_COLORS[dept]||HR_COLOR;
                    return `
                    <div>
                        <div class="flex justify-between mb-1.5">
                            <div class="flex items-center gap-2">
                                <div class="w-3 h-3 rounded-full" style="background:${dc}"></div>
                                <span class="text-sm font-black text-mantiq-navy dark:text-white">${dept}</span>
                            </div>
                            <div class="flex items-center gap-3">
                                <span class="text-xs text-slate-400 font-bold">${count} ${_t('employees','موظف')}</span>
                                <span class="text-xs font-black" style="color:${dc}">${pct}%</span>
                            </div>
                        </div>
                        <div class="kpi-bar"><div class="kpi-bar-fill" style="width:${pct}%;background:${dc}"></div></div>
                    </div>`;
                }).join('')}
            </div>
        </div>

        <div class="flex gap-4">
            <button onclick="pushNotify('${_t('Generating HR report PDF...','إنشاء تقرير HR PDF...')}')" class="flex items-center gap-2 px-8 py-4 rounded-2xl font-black text-sm text-white" style="background:${HR_COLOR}">
                <i data-lucide="file-down" size="16"></i>${_t('Export Full Report','تصدير التقرير الكامل')}
            </button>
            <button onclick="pushNotify('${_t('Sending report to management...','إرسال التقرير للإدارة...')}')" class="flex items-center gap-2 px-8 py-4 rounded-2xl font-black text-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 shadow-sm">
                <i data-lucide="send" size="16"></i>${_t('Share with Management','مشاركة مع الإدارة')}
            </button>
        </div>
    </div>`;
}

// ═══════════════════════════════════════════════════════════════
// PAGE: SETTINGS
// ═══════════════════════════════════════════════════════════════
function renderSettings() {
    const s = state.data.hrSettings;
    const hr = state.hr;

    const policiesTab = `
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <!-- Working Hours -->
            <div class="bg-white dark:bg-slate-900 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                <h3 class="font-black text-sm uppercase tracking-widest text-slate-400 mb-6 flex items-center gap-2"><i data-lucide="clock" size="14"></i>${_t('Working Hours','ساعات العمل')}</h3>
                <div class="space-y-4">
                    <div class="flex gap-4">
                        <div class="flex-1"><label class="text-[9px] font-black uppercase text-slate-400 mb-1 block">${_t('Start Time','وقت البداية')}</label>
                            <input type="time" value="${s.workingHours.start}" onchange="state.data.hrSettings.workingHours.start=this.value; pushNotify('${_t('Saved.','تم الحفظ.')}');" class="w-full bg-slate-50 dark:bg-slate-800 px-4 py-3 rounded-xl text-sm font-bold outline-none" /></div>
                        <div class="flex-1"><label class="text-[9px] font-black uppercase text-slate-400 mb-1 block">${_t('End Time','وقت النهاية')}</label>
                            <input type="time" value="${s.workingHours.end}" onchange="state.data.hrSettings.workingHours.end=this.value; pushNotify('${_t('Saved.','تم الحفظ.')}');" class="w-full bg-slate-50 dark:bg-slate-800 px-4 py-3 rounded-xl text-sm font-bold outline-none" /></div>
                    </div>
                    <div class="flex flex-wrap gap-2">
                        ${['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(day=>`
                            <button onclick="const idx=state.data.hrSettings.workingHours.days.indexOf('${day}'); if(idx>-1)state.data.hrSettings.workingHours.days.splice(idx,1); else state.data.hrSettings.workingHours.days.push('${day}'); render();"
                                class="px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${s.workingHours.days.includes(day)?'text-white':'bg-slate-100 dark:bg-slate-800 text-slate-500'}"
                                style="${s.workingHours.days.includes(day)?`background:${HR_COLOR}`:''}">
                                ${day}
                            </button>
                        `).join('')}
                    </div>
                </div>
            </div>
            <!-- Leave Policy -->
            <div class="bg-white dark:bg-slate-900 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                <h3 class="font-black text-sm uppercase tracking-widest text-slate-400 mb-6 flex items-center gap-2"><i data-lucide="calendar" size="14"></i>${_t('Leave Policy','سياسة الإجازات')}</h3>
                <div class="space-y-3">
                    ${[
                        {key:'annual',        label:_t('Annual Leave Days','أيام الإجازة السنوية'), suffix:_t('days','أيام')},
                        {key:'sick',          label:_t('Sick Leave Days','أيام الإجازة المرضية'),   suffix:_t('days','أيام')},
                        {key:'emergency',     label:_t('Emergency Leave Days','أيام الطوارئ'),       suffix:_t('days','أيام')},
                        {key:'carryover',     label:_t('Max Carry-over Days','أقصى أيام ترحيل'),     suffix:_t('days','أيام')},
                    ].map(f=>`
                        <div class="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                            <span class="text-xs font-bold text-slate-600 dark:text-slate-300">${f.label}</span>
                            <div class="flex items-center gap-2">
                                <input type="number" value="${s.leavePolicy[f.key]}" onchange="state.data.hrSettings.leavePolicy['${f.key}']=parseInt(this.value); pushNotify('${_t('Policy updated.','تم تحديث السياسة.')}');" class="w-16 bg-white dark:bg-slate-700 px-2 py-1.5 rounded-lg text-xs font-black text-center outline-none border border-slate-200 dark:border-slate-600" />
                                <span class="text-[9px] text-slate-400">${f.suffix}</span>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
            <!-- Tax Bands -->
            <div class="bg-white dark:bg-slate-900 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                <h3 class="font-black text-sm uppercase tracking-widest text-slate-400 mb-6 flex items-center gap-2"><i data-lucide="percent" size="14"></i>${_t('Tax & Social Insurance','الضرائب والتأمينات')}</h3>
                <div class="space-y-3 mb-4">
                    <div class="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                        <span class="text-xs font-bold text-slate-600 dark:text-slate-300">${_t('Social Insurance Rate','نسبة التأمين الاجتماعي')}</span>
                        <span class="text-sm font-black text-mantiq-navy dark:text-white">${s.socialInsurance}</span>
                    </div>
                    <div class="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                        <span class="text-xs font-bold text-slate-600 dark:text-slate-300">${_t('Overtime Multiplier','معامل الإضافي')}</span>
                        <span class="text-sm font-black text-mantiq-navy dark:text-white">${s.overtimeRate}×</span>
                    </div>
                </div>
                <p class="text-[9px] font-black uppercase text-slate-400 mb-3">${_t('Income Tax Bands','شرائح ضريبة الدخل')}</p>
                ${s.taxBands.map(b=>`
                    <div class="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl mb-2">
                        <span class="text-xs font-bold text-slate-500">${b.from.toLocaleString()} – ${b.to===Infinity?'∞':b.to.toLocaleString()} EGP</span>
                        <span class="text-sm font-black text-amber-500">${b.rate}</span>
                    </div>
                `).join('')}
            </div>
            <!-- Departments & Roles -->
            <div class="bg-white dark:bg-slate-900 p-8 rounded-[2rem] border border-slate-200 dark:border-slate-800 shadow-sm">
                <h3 class="font-black text-sm uppercase tracking-widest text-slate-400 mb-6 flex items-center gap-2"><i data-lucide="shield" size="14"></i>${_t('Access Roles','صلاحيات الوصول')}</h3>
                <div class="space-y-2">
                    ${s.roles.map((role,i)=>`
                        <div class="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl">
                            <div class="flex items-center gap-2">
                                <div class="w-2 h-2 rounded-full" style="background:${['#34d399','#a78bfa','#38bdf8','#fb923c','#94a3b8','#e2e8f0'][i]||HR_COLOR}"></div>
                                <span class="text-sm font-bold text-mantiq-navy dark:text-white">${role}</span>
                            </div>
                            <span class="text-[9px] font-black uppercase text-slate-400">${['Full Access','HR Module','Dept Only','Team Only','Read Profile','Read Only'][i]||'Custom'}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
        </div>
    `;

    return `
    <div class="fade-in space-y-6">
        <h2 class="text-xl md:text-3xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${_t('HR System Settings','إعدادات نظام الموارد البشرية')}</h2>
        ${policiesTab}
    </div>`;
}


function renderHRModal() {
    const type = state.modalType;
    const empOptions = state.data.employees.map(e=>`<option value="${e.id}">${e.name} (${e.dept})</option>`).join('');

    const forms = {
        add_employee: {
            title: _t('Add New Employee','إضافة موظف جديد'),
            fields: [
                {key:'name',label:_t('Full Name','الاسم الكامل'),type:'text',required:true},
                {key:'jobTitle',label:_t('Job Title','المنصب'),type:'text',required:true},
                {key:'dept',label:_t('Department','القسم'),type:'select',options:state.data.hrSettings.departments},
                {key:'email',label:_t('Work Email','البريد الوظيفي'),type:'email',required:true},
                {key:'phone',label:_t('Phone','الهاتف'),type:'text'},
                {key:'salary',label:_t('Base Salary (EGP)','الراتب الأساسي (ج.م)'),type:'number',required:true},
                {key:'contractType',label:_t('Contract Type','نوع العقد'),type:'select',options:['Full-Time','Part-Time','Contractor','Internship']},
                {key:'hireDate',label:_t('Hire Date','تاريخ التعيين'),type:'date',required:true},
                {key:'nationalId',label:_t('National ID','الرقم القومي'),type:'text'},
                {key:'manager',label:_t('Reports To (Manager)','المدير المسؤول'),type:'text'},
            ]
        },
        request_leave: {
            title: _t('Leave Request','طلب إجازة'),
            fields: [
                {key:'empId',label:_t('Employee','الموظف'),type:'select_emp'},
                {key:'type',label:_t('Leave Type','نوع الإجازة'),type:'select',options:['Annual','Sick','Emergency','Maternity/Paternity','Unpaid']},
                {key:'startDate',label:_t('Start Date','تاريخ البداية'),type:'date',required:true},
                {key:'endDate',label:_t('End Date','تاريخ النهاية'),type:'date',required:true},
                {key:'reason',label:_t('Reason','السبب'),type:'text',required:true},
                {key:'comment',label:_t('HR Comment (optional)','ملاحظة HR (اختياري)'),type:'text'},
            ]
        },
        add_attendance: {
            title: _t('Manual Attendance Entry','إدخال حضور يدوي'),
            fields: [
                {key:'empId',label:_t('Employee','الموظف'),type:'select_emp'},
                {key:'date',label:_t('Date','التاريخ'),type:'date',required:true},
                {key:'checkIn',label:_t('Check In Time','وقت الدخول'),type:'time'},
                {key:'checkOut',label:_t('Check Out Time','وقت الخروج'),type:'time'},
                {key:'note',label:_t('Note','ملاحظة'),type:'text'},
            ]
        },
        add_applicant: {
            title: _t('Add Applicant','إضافة متقدم'),
            fields: [
                {key:'name',label:_t('Full Name','الاسم الكامل'),type:'text',required:true},
                {key:'position',label:_t('Applied Position','الوظيفة المتقدم لها'),type:'text',required:true},
                {key:'dept',label:_t('Department','القسم'),type:'select',options:state.data.hrSettings.departments},
                {key:'source',label:_t('Source','المصدر'),type:'select',options:['LinkedIn','Indeed','Referral','Company Website','Wuzzuf','Forasna']},
                {key:'email',label:_t('Email','البريد'),type:'email'},
                {key:'phone',label:_t('Phone','الهاتف'),type:'text'},
                {key:'experience',label:_t('Years of Experience','سنوات الخبرة'),type:'text'},
                {key:'salary_expect',label:_t('Salary Expectation','توقعات الراتب'),type:'text'},
            ]
        },
        new_review: {
            title: _t('New Performance Review','تقييم أداء جديد'),
            fields: [
                {key:'empId',label:_t('Employee','الموظف'),type:'select_emp'},
                {key:'period',label:_t('Review Period','فترة التقييم'),type:'select',options:['Q1 2025','Q4 2024','Q3 2024','Annual 2024']},
                {key:'kpiScore',label:_t('KPI Score (1-5)','نقاط KPI (1-5)'),type:'number'},
                {key:'attitudeScore',label:_t('Attitude Score (1-5)','الموقف (1-5)'),type:'number'},
                {key:'teamworkScore',label:_t('Teamwork Score (1-5)','العمل الجماعي (1-5)'),type:'number'},
                {key:'communicationScore',label:_t('Communication Score (1-5)','التواصل (1-5)'),type:'number'},
                {key:'strengths',label:_t('Strengths','نقاط القوة'),type:'text'},
                {key:'improvements',label:_t('Areas to Improve','مجالات التطوير'),type:'text'},
                {key:'managerComment',label:_t("Manager's Comment","تعليق المدير"),type:'text'},
            ]
        },
        add_contract: {
            title: _t('New Contract','عقد جديد'),
            fields: [
                {key:'empId',label:_t('Employee','الموظف'),type:'select_emp'},
                {key:'type',label:_t('Contract Type','نوع العقد'),type:'select',options:['Full-Time','Part-Time','Contractor','Internship']},
                {key:'startDate',label:_t('Start Date','تاريخ البداية'),type:'date',required:true},
                {key:'endDate',label:_t('End Date (leave blank if permanent)','تاريخ النهاية (اتركه فارغًا إذا كان دائمًا)'),type:'date'},
                {key:'noticePeriod',label:_t('Notice Period','فترة الإشعار'),type:'select',options:['7 Days','14 Days','30 Days','60 Days','90 Days']},
                {key:'documents',label:_t('Document Notes','ملاحظات المستندات'),type:'text'},
            ]
        },
        add_training: {
            title: _t('Add Training Course','إضافة دورة تدريبية'),
            fields: [
                {key:'name',label:_t('Course Name','اسم الدورة'),type:'text',required:true},
                {key:'provider',label:_t('Provider','المزود'),type:'text',required:true},
                {key:'type',label:_t('Type','النوع'),type:'select',options:['Internal','External']},
                {key:'mode',label:_t('Mode','طريقة التنفيذ'),type:'select',options:['In-Person','Online','Blended']},
                {key:'hours',label:_t('Duration (hours)','المدة (ساعات)'),type:'number'},
                {key:'cost',label:_t('Cost (EGP)','التكلفة (ج.م)'),type:'number'},
                {key:'startDate',label:_t('Start Date','تاريخ البداية'),type:'date'},
                {key:'endDate',label:_t('End Date','تاريخ النهاية'),type:'date'},
            ]
        },
    };

    const form = forms[type] || forms.add_employee;

    const fieldHtml = form.fields.map(f=>`
        <div class="flex flex-col gap-1.5">
            <label class="text-[9px] font-black uppercase tracking-widest text-slate-400">${f.label}${f.required?'<span class="text-rose-400 ml-0.5">*</span>':''}</label>
            ${f.type==='select_emp'
                ? `<select id="mf-${f.key}" class="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 text-sm font-bold outline-none focus:ring-2 focus:ring-purple-400"><option value="">${_t('Select employee...','اختر موظفًا...')}</option>${empOptions}</select>`
                : f.type==='select'
                ? `<select id="mf-${f.key}" class="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 text-sm font-bold outline-none focus:ring-2 focus:ring-purple-400">${f.options.map(o=>`<option>${o}</option>`).join('')}</select>`
                : `<input id="mf-${f.key}" type="${f.type||'text'}" placeholder="${f.label}" class="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-3 text-sm font-bold outline-none focus:ring-2 focus:ring-purple-400" />`
            }
        </div>
    `).join('');

    const handleSave = `
        const formData = {};
        ${form.fields.map(f=>`formData['${f.key}'] = document.getElementById('mf-${f.key}')?.value || '';`).join('\n')}
        ${type==='add_employee' ? `
            state.data.employees.push({
                id:'EMP-'+String(1001+state.data.employees.length).padStart(4,'0'),
                name:formData.name||'New Employee',
                firstName:(formData.name||'New').split(' ')[0],
                avatar:(formData.name||'NE').slice(0,2).toUpperCase(),
                jobTitle:formData.jobTitle||'—',
                dept:formData.dept||'HR',
                manager:formData.manager||'—',
                email:formData.email||'—',
                phone:formData.phone||'—',
                mobile:'—',
                hireDate:formData.hireDate||new Date().toISOString().slice(0,10),
                contractType:formData.contractType||'Full-Time',
                contractEnd:null,
                salary:parseInt(formData.salary)||0,
                allowances:0,transportAllowance:0,mobileAllowance:0,deductions:0,
                socialInsurance:Math.round(parseInt(formData.salary||0)*0.11),
                incomeTax:0,
                netSalary:parseInt(formData.salary||0)*0.89,
                status:'Active',
                leaveBalance:{Annual:21,Sick:10,Emergency:3},
                nationality:'Egyptian',nationalId:formData.nationalId||'—',
                address:'—',education:'—',
                lastReview:'—',performanceScore:'—',notes:'',photo:null,
                probationEnd:'—',emergencyContact:'—',emergencyPhone:'—',startDate:formData.hireDate,
            });
            pushNotify('${_t('Employee added successfully.','تم إضافة الموظف بنجاح.')}', 'success');
        ` : type==='request_leave' ? `
            const empL = state.data.employees.find(e=>e.id===formData.empId);
            if(empL){
                const start=new Date(formData.startDate), end=new Date(formData.endDate);
                const days=Math.max(1,Math.ceil((end-start)/(1000*60*60*24))+1);
                state.data.leaves.push({
                    id:'LV-'+String(1001+state.data.leaves.length).padStart(4,'0'),
                    empId:empL.id, empName:empL.name, dept:empL.dept,
                    type:formData.type||'Annual',
                    startDate:formData.startDate,endDate:formData.endDate,
                    days, reason:formData.reason||'—',
                    status:'Pending', appliedDate:new Date().toISOString().slice(0,10),
                    approvedBy:null, hrApproved:false, comment:formData.comment||''
                });
                pushNotify('${_t('Leave request submitted.','تم تقديم طلب الإجازة.')}', 'success');
            } else { pushNotify('${_t('Please select an employee.','الرجاء اختيار موظف.')}', 'error'); return; }
        ` : type==='add_applicant' ? `
            state.data.recruitment.push({
                id:'APP-'+String(4001+state.data.recruitment.length).padStart(4,'0'),
                name:formData.name||'New Applicant',
                position:formData.position||'—',
                dept:formData.dept||'HR',
                source:formData.source||'Manual',
                stage:'applied',
                appliedDate:new Date().toISOString().slice(0,10),
                experience:formData.experience||'—',
                salary_expect:formData.salary_expect||'—',
                score:50, interviewer:'—', interviewDate:null, notes:'',
                email:formData.email||'—', phone:formData.phone||'—',
            });
            pushNotify('${_t('Applicant added.','تم إضافة المتقدم.')}', 'success');
        ` : type==='new_review' ? `
            const empR = state.data.employees.find(e=>e.id===formData.empId);
            if(empR){
                const scores=[parseFloat(formData.kpiScore||3),parseFloat(formData.attitudeScore||3),parseFloat(formData.teamworkScore||3),parseFloat(formData.communicationScore||3),3];
                const overall=(scores.reduce((a,b)=>a+b,0)/5).toFixed(1);
                state.data.performance.push({
                    id:'PER-'+String(5001+state.data.performance.length).padStart(4,'0'),
                    empId:empR.id,empName:empR.name,dept:empR.dept,
                    period:formData.period||'Q1 2025',
                    reviewer:state.data.hrSettings.roles[1],
                    kpiScore:formData.kpiScore||'3.0',
                    attitudeScore:formData.attitudeScore||'3.0',
                    teamworkScore:formData.teamworkScore||'3.0',
                    communicationScore:formData.communicationScore||'3.0',
                    initiativeScore:'3.0',
                    overallScore:overall,
                    kpiDetails:[],
                    strengths:formData.strengths||'—',
                    improvements:formData.improvements||'—',
                    managerComment:formData.managerComment||'—',
                    status:'Completed',
                    submitDate:new Date().toISOString().slice(0,10),
                });
                pushNotify('${_t('Performance review saved.','تم حفظ التقييم.')}', 'success');
            }
        ` : type==='add_training' ? `
            state.data.training.push({
                id:'TRN-'+String(100+state.data.training.length).padStart(3,'0'),
                name:formData.name||'New Course',
                provider:formData.provider||'—',
                type:formData.type||'Internal',
                mode:formData.mode||'Online',
                enrollees:0, completed:0,
                hours:parseInt(formData.hours||0),
                cost:parseInt(formData.cost||0),
                startDate:formData.startDate||'—',
                endDate:formData.endDate||'—',
                status:'Scheduled',
                cert:false
            });
            pushNotify('${_t('Course added.','تم إضافة الدورة.')}', 'success');
        ` : `pushNotify('${_t('Saved.','تم الحفظ.')}', 'success');`}
        state.isModalOpen=false; state.modalType=null; render();
    `;

    return `
        <div class="fixed inset-0 z-[101] flex items-end sm:items-center justify-center p-0 sm:p-4 modal-overlay fade-in" onclick="if(event.target===this){state.isModalOpen=false;state.modalType=null;render();}">
            <div class="bg-white dark:bg-slate-900 w-full sm:max-w-xl rounded-t-[2rem] sm:rounded-[2.5rem] p-5 sm:p-10 border border-slate-200 dark:border-slate-800 shadow-2xl max-h-[92vh] overflow-y-auto custom-scrollbar" onclick="event.stopPropagation()">
                <div class="flex justify-between items-start mb-8">
                    <div>
                        <h2 class="text-xl font-black text-mantiq-navy dark:text-white uppercase tracking-tighter">${form.title}</h2>
                        <p class="text-[10px] text-slate-400 font-bold uppercase mt-1">MANTIQ HR System</p>
                    </div>
                    <button onclick="state.isModalOpen=false; state.modalType=null; render();" class="text-slate-400 hover:text-rose-500 p-2 transition-colors"><i data-lucide="x" size="22"></i></button>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                    ${fieldHtml}
                </div>
                <div class="flex gap-3">
                    <button onclick="state.isModalOpen=false; state.modalType=null; render();" class="flex-1 py-4 rounded-2xl bg-slate-100 dark:bg-slate-800 font-black text-sm uppercase text-slate-600 dark:text-slate-300">${_t('Cancel','إلغاء')}</button>
                    <button onclick="${handleSave}" class="flex-1 py-4 rounded-2xl font-black text-sm uppercase text-white shadow-xl" style="background:${HR_COLOR}">${_t('Save','حفظ')}</button>
                </div>
            </div>
        </div>
    `;
}



window.addEventListener('contextmenu', e => { e.preventDefault(); pushNotify(ut('restricted')); });
// Auto-init when script is ready
initData(); initHRData(); render();
